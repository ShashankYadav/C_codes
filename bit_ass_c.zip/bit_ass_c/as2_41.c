#include<stdio.h>
int main()
{
	int n,x,y;
	while(scanf("%d",&n)!=EOF)
	{
		int i,j,temp,p1=0,p2=0;
		int a[n],b[n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++)
		{
			b[i]=a[i];
		}
		for(i=1;i<n;i++)
		{
			temp=a[i];
			j=i-1;
			while(temp<a[j] && j>=0)
			{
				a[j+1]=a[j];
				j=j-1;
			}
			a[j+1]=temp;

		}
		
		for(i=0;i<n;i++)
		{
			if(a[i]!=b[i])
			{
				p1=i;
				break;
			}
		}
		for(i=n-1;i>0;i--)
		{
			if(a[i]!=b[i])
			{
				p2=i;
				break;
			}
		}

		printf("%d %d\n",p1,p2);
	}
	
	return 0;
}
