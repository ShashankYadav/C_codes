#include<stdio.h>
int main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		unsigned int x,y,temp,key,mask,b,k,m=31;
		b=1<<m;
		scanf("%u %u",&x,&key);
		y=x;
		for(k=31;k>(31-key);k--)
		{
			mask=y&b;
			if(mask>0)
				temp=1;
			else
				temp=0;
			y=y<<1;
			y=y|temp;
		}
		printf("%u\n",y);
	}
	return 0;
}
