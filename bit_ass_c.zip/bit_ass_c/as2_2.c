#include <stdio.h>
int main()
{
	unsigned int n1,n2,i,j,mask1=0,mask2=0;
	while(scanf("%u %u %u %u",&n1,&n2,&i,&j)!=EOF)
	{
		mask1=~0;
		if(j-i+1==32)
		{	
			mask2=0;
			mask1=~0;
		}
		else
		{	
			mask1=mask1>>(j-i+1);
			mask1=mask1<<(j-i+1);
			mask1=~mask1;
			mask1=mask1<<i;
			printf("mask1 :%u\n",mask1);
			mask2=~mask1;
			printf("mask2 :%u\n",mask2);
		}
		n1=mask2&n1;
		n2=mask1&n2;
		n1=n1|n2;
		printf("%u\n",n1);
	}
	return 0;
}
