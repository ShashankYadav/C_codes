#include<stdio.h>
int main()
{
	int a[10],b[10],i,num1=0,num2=0,flag=0;
	char c1[100000],c2[100000];
	
		while(scanf("%s %s",c1,c2)!=EOF) 
		{
			for(i=0;i<10;i++)
			{
				a[i]=0;
				b[i]=0;
			}
			flag=0;
			for(i=0;c1[i]!='\0';i++)
			{
				num1=(int)c1[i]-48;
				//printf("%num1 is d\n",num1);
				a[num1]++;
			
			}
			for(i=0;c2[i]!='\0';i++)
			{
				num2=(int)c2[i]-48;
				b[num2]++;
			}

				
			for(i=0;i<10;i++)
			{
				if(a[i]!=b[i])
				{
					flag=1;
				}
			}
			if(flag==0)
			{
				printf("YES\n");
				flag=0;
			}
			else
			{
				printf("NO\n");
				flag=0;
			}

		}
		
	return 0;
}
