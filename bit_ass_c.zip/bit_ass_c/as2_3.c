#include<stdio.h>
int main()
{
	int n,a[100],x,y,p1,p2,i,j;
	while(scanf("%d %d %d",&n,&x,&y)!=EOF)
	{
		p2=n;
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++)
		{
			if(a[i]==x)
			{
				for(j=0;j<n;j++)
				{
					if(a[j]==y)
					{
						if(j>i)
						{
							p1=j-i;
						}
						else
						{
							p1=i-j;
						}
						if(p1<p2)
						{
							p2=p1;
						}
					}
				}
			}
		}
		printf("%d\n",p2);
	}
	return 0;
}
