#include<stdio.h>
int main()
{
	int i,j,n,min,max,flag=0,p1=0;
	while(scanf("%d",&n)!=EOF)
	{
		int p2=0;
		int a[n];
		for(i=0;i<n;i++)
		{	
			scanf("%d",&a[i]);
		}
		min=a[0];max=a[n-1];
		for(i=0;i<n;i++)
		{
			min=a[i];
			for(j=i+1;j<n;j++)
			{
				if(a[j]<min)
				{	
					p1=i;
					flag=1;
					break;
				}
			
			}
			if(flag==1)
				break;

		}
		flag=0;
		for(i=n-1;i>=0;i--)
		{
			max=a[i];
			for(j=i-1;j>=0;j--)
			{
				if((a[j])>max)
				{
					p2=i;
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				break;
			}
		}
		printf("%d %d",p1,p2);
	}
		return 0;
}
