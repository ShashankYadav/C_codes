#include<stdio.h>
int main()
{
	int j,i,n,gcd,ca,cb,move1,move2,sum;
	int min,max,r;
	scanf("%d",&n);
	int a[n],b[n],c[n];
	for(i=0;i<n;i++)
	{
		scanf("%d %d %d",&a[i],&b[i],&c[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]>b[i])
		{
			min=b[i];
			max=a[i];
		}
		else
		{
			min=a[i];
			max=b[i];
		}
		for(j=min;j>0;j--)
		{
			if(a[i]%j==0&&b[i]%j==0)
			{
				gcd=j;
				break;
			}
		}
		if(c[i]>a[i]&&c[i]>b[i])
		{
			printf("-1\n");
			continue;
		}
		else if(c[i]==a[i]||c[i]==b[i])
		{
			printf("1\n");
			continue;
		}
		else if(c[i]==0)
		{
			printf("0\n");
			continue;
		}
		else if(c[i]%gcd!=0)
		{
			printf("-1\n");
			continue;
		}
		else if(c[i]%gcd==0)
		{
			ca=0;
			cb=0;
			move1=0;
			move2=0;
			while((ca!=c[i])&&(cb!=c[i]))
			{
				if(ca==0)
				{
					ca=a[i];
					move1++;

				}
				else if(cb==b[i])
				{
					cb=0;
					move1++;
				}
				else
				{
					sum=ca+cb;
					if(b[i]>sum)
					{
						cb=sum;
					}
					else
					{
						cb=b[i];
					}
					ca=sum-cb;
					move1++;
				}
			}

			ca=0;
			cb=0;
			while(ca!=c[i]&&cb!=c[i])
			{

				if(cb==0)
				{
					cb=b[i];
					move2++;
				}
				if(ca==a[i])
				{
					ca=0;
					move2++;
				}
				else
				{
					sum=ca+cb;
					if(sum>a[i])
					{
						ca=a[i];
					}
					else
					{
						ca=sum;
					}
					cb=sum-ca;
					move2++;
				}
				
			}
			if(move1>move2)
			{
				printf("%d\n",move2);
			}
			else
			{
				printf("%d\n",move1);
			}
		}
	}
	return 0;
}
