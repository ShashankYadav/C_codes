#include<stdio.h>
char d[2000];
/*void initd()
{
	int i;
	for(i=0;i<2000;i++)
	{
		d[i]='\0';
	}
}*/
void decode(char *s)
{
	//printf("given:%s\n",s);
	int i,j=0,pos=0;
	for(i=0;s[i]!='\0';i++)
	{
		if(i%2==0)
		{
			//printf("pos:%d i:%d times%c\n",pos,i,s[i]);
			for(j=pos;j<pos+(int)s[i]-'0';j++)
			{
				//printf("%d\n",j);
				d[j]=s[i+1];
			}
			pos=pos+(int)s[i]-'0';
		}
return;	
	}
	//printf("decoded:%s\n",d);
	//printf("decoded\n");
	/*for(i=0;d[i]!='\0';i++)
	{
		printf("%c",d[i]);
	}
	printf("\n");*/
}
/*void encode(char *s)
{
	printf("string in encode:%s",s);
	int i,j,counter=1;
	for(i=0;;i++)
	{
		if(s[i]=='\0')
		{
			break;
		}
		//printf("s[i]:%c s[i+1]:%c\n",s[i],s[i+1]);
		if(s[i+1]==s[i])
		{
			counter++;
		}
		else
		{
			e[j++]=counter+48;
			//printf("%c\n",e[j-1]);
			e[j++]=s[i];
			//printf("%c\n",e[j-1]);
			counter=1;
		}
	}
	printf("%s\n",e);
}*/
int main()
{
	char c;
	char s1[100],s2[100];
       
//	scanf("%s",s1);
	while(scanf("%s %c %s",s1,&c,s2)!=EOF)
	{
	char n1[2000], n2[2000];
	long long int num1=0,num2=0,ans;
	int i=0,j=0;
	char e[2000];
	printf("look here %s %c %s\n",s1,c,s2);
	decode(s1);
	//initd();
	printf("see this n1:%s\n",d);
	for(i=0;d[i]!='\0';i++)
	{
		num1=(num1*10)+((int)d[i]-'0');
	}
	/*for(i=0;d[i]!='\0';i++)
	{
		printf("d[i]\n");
		n1[i]=d[i];
	}
	printf("local array:%s\n",n1);*/
	decode(s2);
	for(i=0;d[i]!='\0';i++)
	{
		num2=(num2*10)+((int)d[i]-'0');
	}
	printf("n2:%s\n",d);
	/*for(i=0;d[i]!='\0';i++)
	{
		n2[i]=d[i];
	}
	printf("local array:%s\n",n2);*/
	
	
	printf("number 1:%lld number 2:%lld\n",num1,num2);
	if(c=='+')
	{
		ans=num1+num2;
	}
	else if(c=='-')
	{
		ans=num1-num2;
	}
	else if(c=='*')
	{
		ans=num1*num2;
	}
	else if(c=='/')
	{
		ans=num1/num2;
	}
	printf("answer:%lld\n",ans);
	int n,len=0;
	char an[2000];
	n=ans;
	while(n>0)
	{
		n=n/10;
		len++;
	}
	printf("length:%d\n",len);
	/*for(i=len-1;i>=0;i--)
	{
		printf("%c\n",(char)ans%10);
		an[i]=(char)ans%10;
		ans=ans/10;
	}*/
	sprintf(an,"%lld",ans);
	printf("ans in string:%s\n",an);
	int counter=1;
	for(i=0;;i++)
	{
		if(an[i]=='\0')
		{
			break;
		}
		//printf("s[i]:%c s[i+1]:%c\n",s[i],s[i+1]);
		if(an[i+1]==an[i])
		{
			counter++;
		}
		else
		{
			e[j++]=counter+48;
			//printf("%c\n",e[j-1]);
			e[j++]=an[i];
			//printf("%c\n",e[j-1]);
			counter=1;
		}
	}
	printf("%s %c %s = %s\n",s1,c,s2,e);
	}
	return 0;
}
