#include<stdio.h>
int main()
{
	char c,c1;
	int flag=0,coms=0,comc=0,counter=0,prev=0;
	while(scanf("%c",&c)!=EOF)
	{
		//printf("%c coms:%d comc:%d flag:%d\n",c,coms,comc,flag);
		if(c=='"')
		{
			if(flag==0)
			{
				flag=1;
			}
			else if(flag==1)
			{
				flag=0;
			}
		}
		if(flag==0)
		{
			if(c=='/')
			{
				c1=c;
				scanf("%c",&c);
				if(c=='/')
				{
					printf("%c%c",c,c1);
					continue;
				}
				if(c=='*')
				{
					coms++;
					//printf("e at /*");
					//scanf("%c",&c);
					continue;
				}
				else
				{
					//printf("e at / not *");
					printf("%c",c1);
					//scanf("%c",&c);
					continue;
				}
			}
			if(c=='*')
			{
				c1=c;
				//printf("\nentered at *\n");
				scanf("%c",&c);
				if(c=='/')
				{
					if(coms<=comc)
					{
						//comc++;
						//printf("comc=%d\n",comc);
						//printf("e at */");
						printf("%c",c1);
						printf("%c",c);
						//scanf("%c",&c);
						continue;
					
					}
					else
					{
						comc++;
						//scanf("%c",&c);
						continue;
					}

				}
				else
				{
					//printf("e at * not /");
					printf("%c",c1);
					printf("%c",c);
					//scanf("%c",&c);
					continue;
				}
			}
		}
		
		if(coms>comc)
		{
			//printf("\nentered at coms>comc\n");
			//scanf("%c",&c);
			continue;
		}
		if(coms<=comc||flag==1)
		{
			//printf("\nentered at last case\n");
			printf("%c",c);
			//scanf("%c",&c);
			//printf("\nnext c<%c> coms:%d comc:%d flag:%d\n",c,coms,comc,flag);
		}
		
	}
	return 0;
}
