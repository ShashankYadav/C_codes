#include<stdio.h>
#include<math.h>
int a[100][100],f[100],b[100];
int r,c;
void bin(int w)
{
	int x,i = 0,v = 0;
	for(x=0;x<c;x++)
	{
		f[x]=0;
		b[x]=0;
	}
	/*if(w==0)
	{
		return ;
	}
	if(w==1)
	{
		b[c-1]=1;
		return;
	}*/
	while (w != 0) 
	{
		v = (w % 2) * (int) pow(10,i) + v;
		f[i]=w%2;
		w = w / 2;
		i = i + 1;
	}
	/*for(x=0;x<c;x++)
	{
	printf("%d ",f[x]);
	}
	printf("\n");*/
	for(x=0;x<c;x++)
	{
		b[x]=f[c-x-1];
	}
	/*printf("bin from fn:");
	for(x=0;x<c;x++)
	{
		printf("%d ",b[x]);
	}
	printf("\n");*/
	return ;
}
void pressbut(int i,int j)
{
	//printf("pressing a[%d][%d]=%d\n",i,j,a[i][j]);
	a[i][j]=1-a[i][j];
	//printf("new a[i][j]=:%d:\n",a[i][j]);
	if(i>0){a[i-1][j]=1-a[i-1][j];
	//printf("new value ofa[i-1][j]=%d\n",a[i-1][j]);
	}
	if(i<r-1){a[i+1][j]=1-a[i+1][j];
	//printf("new value ofa[i+1][j]=%d\n",a[i+1][j]);
	}
	if(j>0){a[i][j-1]=1-a[i][j-1];
	//printf("new value ofa[i][j-1]=%d\n",a[i][j-1]);
	}
	if(j<c-1){a[i][j+1]=1-a[i][j+1];
	//printf("new value ofa[i][j+1]=%d\n",a[i-1][j+1]);
	}
}
int pr1()
{
	//printf("pr1 active\n");
	int i,add=0;
	for(i=0;i<c;i++)
	{
		if(b[i]==1)
		{
			pressbut(0,i);
			add++;
		}
	}
	return add;
}
int prr(int q)
{
	//printf("prr active q is:%d\n",q);
	int i,add=0;
	for(i=0;i<c;i++)
	{
		if(a[q-1][i]==0)
		{
			pressbut(q,i);
			add++;
		}
	}
	return add;
}
int check()
{
	int i,j,flag=0;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			if(a[i][j]!=1)
			{
				flag=1;
				break;
			}
		}
	}
	if(flag==1)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int i,j,count=0,min=100000,press=0,flag=0;
		int copy[100][100];
		r=0;
		c=0;
		char s[100];
		for(i=0;i<100;i++)
		{
			b[i]=0;
			f[i]=0;
		}
		for(i=0;i<100;i++)
		{
			for(j=0;j<100;j++)
			{
				a[i][j]=0;
			}
		}
		scanf("%d%d",&r,&c);
		//printf("r:%d c:%d\n",r,c);
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				a[i][j]=0;
			}
		}
		for(i=0;i<r;i++)
		{
			scanf("%s",s);
			for(j=0;j<c;j++)
			{
				if(s[j]=='X')
				{
					a[i][j]=1;
				}
				else if(s[j]=='.')
				{
					a[i][j]=0;
				}
			copy[i][j]=a[i][j];
			}
		}
		while(1)
		{
			//printf("count:%d\n",count);
			press=0;
			if(count==pow(2,c))
			{
				break;
			}
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					a[i][j]=copy[i][j];
				}
			}
			bin(count);
			/*printf("binary:");
			for(i=0;i<c;i++)
			{
				printf("%d ",b[i]);
			}
			printf("\n");*/
			press+=pr1();
			for(i=1;i<r;i++)
			{
				press+=prr(i);
			}
			flag=check();
			/*printf("array\n");
			for(i=0;i<r;i++)
			{
				for(j=0;j<c;j++)
				{
					printf("%d ",a[i][j]);
				}
				printf("\n");
			}
			printf("flag:%d press:%d\n",flag,press);*/
			if(flag==1)
			{
				if(min>press)
				{
					min=press;
				}
			}
			
			count++;
		}
		if(min==100000)
		{
			min=-1;
		}
		printf("%d\n",min);
			/*for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				printf("%d ",a[i][j]);
			}
			printf("\n");
		}*/


	}
	return 0;
}
