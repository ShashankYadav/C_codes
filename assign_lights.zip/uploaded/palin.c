#include<stdio.h>
#include<string.h>
int max=0;
void check(char *a,int start,int end)
{
	int i,n;
	n=(end-start+1)/2;
	for(i=0;i<n;i++)
	{
		if(a[start+i]!=a[end-i])
		{
			return;
		}
	}
	if(end-start+1>max)
	{
		max=end-start+1;
	}
}

int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		char s[2000],rev[2000];
		int len,i,j,flag[2000];
		max=0;
		scanf("%s",s);
		len=strlen(s);
		for(i=0;i<len;i++)
		{
			for(j=len-1;j>0;j--)
			{
				if(s[i]==s[j])
				{
					check(s,i,j);
				}
			}
		}
		printf("%d\n",max);
	}
	return 0;
}
