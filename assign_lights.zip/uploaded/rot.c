#include<stdio.h>
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		char s[2000],new[2000],temp[2000];
		int rot,shift,i,flag[2000],len=0,x=0,countvow=0;
		scanf("%s",s);
		scanf("%d",&rot);
		for(i=0;s[i]!='\0';i++)
		{
			if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u'||s[i]=='A'||s[i]=='E'||s[i]=='I'||s[i]=='O'||s[i]=='U')
			{
				flag[i]=1;
				countvow++;
			}
			else
			{
				flag[i]=0;
			}
			len++;
		}
		/*for(i=0;i<len;i++)
		{
			printf("%d",flag[i]);
		}
		printf("\n");*/
		for(i=0;i<len;i++)
		{
			if(flag[i]==0)
			{
				new[x]=s[i];
				x++;
			}
		}
		if(x==0)
		{
			printf("%s\n",s);
			continue;
		}
		shift=rot%x;
		//printf("consonant string:%s no of consonants:%d actual shift:%d\n",new,x,shift);
		for(i=0;i<x;i++)
		{
			if((i+shift)>x-1)
			{
					temp[(i+shift)%x]=new[i];
			}
			else
			{
				temp[i+shift]=new[i];
			}
		}
		//printf("rotated string:%s\n",temp);
		x=0;
		for(i=0;i<len;i++)
		{
			if(flag[i]==0)
			{
				s[i]=temp[x];
				//printf("%c is copied to position %d\n",temp[x],i);
				x++;
			}
		}
		printf("%s\n",s);
	}
	return 0;
}
