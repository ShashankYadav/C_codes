#include<stdio.h>
#include<string.h>
int a[100],count=0;
void step(int start,int prevsum,const int n)
{
	int i,s=0;
	/*printf("n in  function:%d\n",n);
	for(i=0;i<n;i++)
	{
		printf("%d",a[i]);
	}
	printf("\n");*/
	//printf("start:%d prevsum:%d size:%d\n",start,prevsum,n);
	if(start==n)
	{
		//printf("count added by 1\n");
		count++;
		return;
	}
	for(i=start;i<n;i++)
	{
		s=s+a[i];
		//printf("%d\n",s);
		if(s>=prevsum)
		{
			step(i+1,s,n);
		}
	}
}
int main()
{
	char s[30];
	int counter=0;
	while(scanf("%s",s)!=EOF)
	{
		int n;
		counter++;
		count=0;
		int i;
		if(strcmp(s,"input")==0)
		{
			continue;
		}
		else if(strcmp(s,"bye")==0)
		{
			break;
		}
		n=strlen(s);
		//printf("string length:%d\n",n);
		for(i=0;i<n;i++)
		{
			a[i]=s[i]-'0';
		}
		step(0,0,n);
		printf("%d. %d\n",counter,count);
	}
	return 0;
}
