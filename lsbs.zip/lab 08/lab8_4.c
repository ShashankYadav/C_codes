#include<stdio.h>
int main()
{
	int counter=0,diff=0,i,n,sum=0,min=1000000;
	scanf("%d",&n);
	int a[n],b[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		sum=sum+a[i];
		b[i]=sum;
		printf("%d\n",b[i]);
	}
	while(1)
	{
		if(diff==0)
		{
			if(b[counter]<min);
			{
				min=b[counter];
			}
		}
		else if((b[counter+diff]-b[counter])<min&&(counter+diff)<n)
		{
			min=b[counter+diff]-b[counter];
			printf("min %d",min);
		}

		if(counter==n)
		{
			diff++;
			counter=0;
		}
		if(diff>n)
			break;
		counter++;
	}
	return 0;
}
