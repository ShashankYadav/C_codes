#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int len,a[n],x,i,j,k=0,temp,min=10000000,b[n],flag;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		min=a[i];
		for(j=i+1;j<n;j++)
		{
			if(min>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				min=a[j];
			}
		}
	}
	for(i=0;i<n;i++)
	{
		flag=0;
		for(j=0;j<k;j++)
		{
			if(b[j]==a[i])
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			b[k]=a[i];
			k++;
		}
	}
	for(i=0;i<k;i++)
		printf("%d ",b[i]);
	return 0;
}
