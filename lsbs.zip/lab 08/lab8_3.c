#include<stdio.h>
int main()
{
	char ch;
	int i,count[10]={0};
	while(1)
	{
		scanf("%c",&ch);
		if(ch=='\n')
			break;
		count[ch-'0']++;
	}
	for(i=0;i<10;i++)
		printf("%d===========>>>>>%d\n",i,count[i]);
	return 0;
}
