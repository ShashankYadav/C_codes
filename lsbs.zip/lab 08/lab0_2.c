#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int firstmax,secondmax;
	scanf("%d",&firstmax);
	scanf("%d",&secondmax);
	int temp;
	if(secondmax>firstmax)
	{
		temp=firstmax;
		firstmax=secondmax;
		secondmax=temp;
	}
	int i,t;
	for(i=2;i<n;i++)
	{
		scanf("%d",&t);
		if(t>firstmax)
		{
			secondmax=firstmax;
			firstmax=t;
		}
		else if(t>secondmax)
		{
			secondmax=t;
		}
	}
	printf("firstmax is %d and secondmax is %d\n",firstmax,secondmax);
	return 0;
}
