#include<stdio.h>
int main()
{
	int n,i,j,cost,edge=0;
	scanf("%d",&n);
	int a,b;
	int c[n][n],d[n];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			c[i][j]=0;
		}
	}
	for(i=0;i<n;i++)
	{
		if(i-1>=0)
		{
			edge++;
		}
		if(i-2>=0)
		{
			edge++;
		}
	}
	for(i=0;i<edge;i++)
	{
		scanf("%d%d%d",&a,&b,&cost);
		c[b-1][a-1]=cost;
		
	}
	
	d[0]=0;
	d[1] = c[1][0];
	for(i=2;i<n;i++)
	{

		if(d[i-1]+c[i][i-1]>d[i-2]+c[i][i-2])
		{
			d[i]=d[i-2]+c[i][i-2];
		}
		else
		{
			d[i]=d[i-1]+c[i][i-1];
		}
	}
	
	printf("%d",d[n-1]);
	return 0;
}
