#include<stdio.h>
int main()
{
	int i,j,a[4][4],b[2][2],c[2][2],d[2][2],e[2][2];
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
	
			scanf("%d",&a[i][j]);
			if(i<2&&j<2)
			{
				b[i][j]=a[i][j];
			}
			else if(i<2&&j>1)
			{
				c[i][j-2]=a[i][j];
			}
			else if(i>1&&j<2)
			{
				d[i-2][j]=a[i][j];
			}
			else if(i>1&&j>1)
			{
				e[i-2][j-2]=a[i][j];
			}
		}
	}
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{


	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			s1+=b[i][j];
			s2+=c[i][j];
			s3+=d[i][j];
			s4+=e[i][j];
		}
	}
	if(s1==s2&&s2==s3&&s3==s4&&sr==sc&&sc==s1)
	{
		printf("YES\n");
	}
	else
		printf("NO\n");
	/*for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			printf("%d ",c[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			printf("%d ",d[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			printf("%d ",e[i][j]);
		}
		printf("\n");
	}
	printf("\n");*/
	return 0;
}
