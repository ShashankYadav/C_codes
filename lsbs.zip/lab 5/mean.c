#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("input.txt","r");
	if(fp==NULL)
		return 0;
	double m,n=0;
	double i,sum=0,sum2=0,mean,var;
	while(!(feof(fp)))
	{
	 	
		fscanf(fp,"%lf",&i);
		sum+=i;
		sum2+=i*i;
		n++;
	}
		
		mean=sum/n;
		var=(sum2/n)-(mean*mean);
		printf("%lf %lf\n",mean,var);
	
	fclose(fp);
	return 0;
}
