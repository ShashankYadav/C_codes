#include<stdio.h>
int main()
{
	int a[100],b[100],n,i,min,j,temp,mode,ch,pos=0;
	float mean=0,median=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&ch);
	switch(ch)
	{
		case 1: 
			for(i=0;i<n;i++)
			{
				mean+=a[i];
			}
			mean=mean/n;
			printf("%f\n",mean);
			break;
		case 2:
			for(i=0;i<n;i++)
			{
				min=a[i];
				for(j=1;j<n;j++)
				{
					if(a[j]<min)
					{
						temp=a[i];
						a[i]=a[j];
						a[j]=temp;
					}
				}
			}
			if(n%2==0)
			{
				median=a[n/2];
			}
			else
			{
				median=(a[n/2]+a[(n/2)+1])/2;
			}
			printf("%f\n",median);
			break;
		case 3:
			for(i=0;i<n;i++)
			{
				b[i]=0;
			}
			for(i=0;i<n;i++)
			{
				temp=a[i];
				for(j=0;j<n;j++)
				{
					if(temp==a[j])
					{
						b[i]++;
					}
				}
			}
			
			
				mode=b[0];
				for(i=1;i<n;i++)
				{
					if(b[i]>mode)
					{
						mode=b[i];
						pos=i;

					}
				}
				printf("%d\n",a[pos]);
				
			
			break;
	}
	return 0;
}
