#include<stdio.h>
int main()
{
	long int fact=1,i=0,n=0;
	scanf("%d",&n);
	if(n<0)
		printf("invalid input");
	else
	{
		for(i=n;i>0;i--)
			fact*=i;
		printf("%d",fact);
	}
	return 0;
}
