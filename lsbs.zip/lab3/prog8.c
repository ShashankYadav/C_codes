#include<stdio.h>
int main()
{
	int sample=1;
	scanf("%d",&sample);
	while(sample>0)
	{
		int num2=1,num=1,diff=0,n=0;
		scanf("%d",&n);
		while(num*2<n)
		{
			num*=2;
		}
		num2=num*2;
		if((n-num)<(-(n-num2)))
			diff=n-num;
		else
			diff=-(n-num2);
		printf("%d",diff);
		sample--;
	}
	return 0;
}
