#include<stdio.h>
int main()
{
	int sample=1;
	scanf("%d\b",&sample);
	while(sample>0)
	{
		char num;
		int c0=0,c1=0,c2=0,c3=0,c4=0,c5=0,c6=0,c7=0,c8=0,c9=0,counter=0;
		scanf("%c",&num);
		counter++;
		while(num!='#')
		{
			if(num=='0')
				c0++;
			else if(num=='1')
				c1++;
			else if(num=='2')
				c2++;
			else if(num=='3')
				c3++;
			else if(num=='4')
				c4++;
			else if(num=='5')
				c5++;
			else if(num=='6')
				c6++;
			else if(num=='7')
				c7++;
			else if(num=='8')
				c8++;
			else if(num=='9')
				c9++;
			else if(num!='#'&&num!='\n'&&(num<'0'||num>'9'))
			{
				printf("invalid input");
				return 0;
			}
			
			scanf("%c",&num);
			counter++;
		}
		if(counter<101)
			printf("%d %d %d %d %d %d %d %d %d %d\n",c0,c1,c2,c3,c4,c5,c6,c7,c8,c9);
		else
			printf("number greater than 10^100");
		sample--;
	}
	return 0;
}
