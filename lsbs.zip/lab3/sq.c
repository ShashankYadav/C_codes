#include<stdio.h>
int main()
{
	int n=0,sum=0;
	scanf("%d",&n);
	if(n<0)
	{
		n=0-n;
	}
	while(n>0)
	{	
		sum+=(n%10)*(n%10);
		n=n/10;
	}
	printf("%d",sum);
	return 0;
}
