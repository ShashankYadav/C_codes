#include<stdio.h>
int main()
{
	int n=0,i=0,sum=4,a=1,b=3;
	scanf("%d",&n);
	if(n<=0)
	{
		printf("invalid input");
		return 0;
	}
		
	if(n==1)
		printf("%d",a);
	else if(n==2)
		printf("%d",b);
	else
	{
		for(i=0;i<n-3;i++)
		{
			a=b;
			b=sum;
			sum=a+b;
		}	
		printf("%d",sum);
	}
	return 0;
}
