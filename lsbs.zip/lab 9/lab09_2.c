#include<stdio.h>
int main()
{
	int i,j,m,n;
	scanf("%d %d",&m,&n);
	int a[m][n],b[m][n],c[m][n],sr=0,sc=0;
	float mean=0,var[m][n];
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		sr=0;
		sc=0;
		for(j=0;j<n;j++)
		{
			sr+=a[i][j];
			b[i][j]=sr;
			sc+=a[j][i];
			c[j][i]=sc;
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",c[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<m;i++)
	{
		mean+=b[i][n-1];
	}
	printf("\n");
	mean=mean/(m*n);
	printf("%f\n",mean);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			var[i][j]=(a[i][j]-mean)*(a[i][j]-mean);
			printf("%f ",var[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	return 0;
}

