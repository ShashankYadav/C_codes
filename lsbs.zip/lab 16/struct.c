#include<stdio.h>
#include<string.h>
struct stu
{
	char name[20];
	int rno,marks1,marks2;
};
typedef struct stu stud; 
int main()
{
	int i;
	double mean1,mean2;
	struct stu st[100];
	for(i=0;i<5;i++)
	{
		scanf("%s",st[i].name);
		scanf("%d%d%d",&st[i].rno,&st[i].marks1,&st[i].marks2);
		mean1+=st[i].marks1;
		mean2+=st[i].marks2;
	}
	mean1=mean1/5;
	mean2=mean2/5;
	for(i=0;i<5;i++)
	{
		printf("%s",st[i].name);
		printf(" %d %d %d\n",st[i].rno,st[i].marks1,st[i].marks2);
	}
	printf("mean for sub1:%lf mean for sub2:%lf\n",mean1,mean2); 
	return 0;
}
