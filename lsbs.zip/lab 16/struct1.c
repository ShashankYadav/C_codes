#include<stdio.h>
#include<stdlib.h>
struct stu
{
	char name[20];
	int rno,marks1,marks2;
};
typedef struct stu stud;
int main()
{
	stud *s;
	s=(stud*)malloc(sizeof(stud));
	scanf("%s",s->name);
	scanf("%d%d%d",&s->rno,&s->marks1,&s->marks2);
	printf("%s %d %d %d\n",s->name,s->rno,s->marks1,s->marks2);
	return 0;
}
