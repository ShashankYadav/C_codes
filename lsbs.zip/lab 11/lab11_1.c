#include<stdio.h>
int main()
{
	int n,i,j,max;
	scanf("%d",&n);
	int a[n],cum[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	cum[0]=a[0];
	for(i=1;i<n;i++)
	{
		cum[i]=cum[i-1]+a[i];
	}
	max=-1000000000;
	for(i=n-1;i>0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(cum[i]-cum[j]>max)
			{
				max=cum[i]-cum[j];
			}
		}
	}
	for(i=0;i<n;i++)
	{
		if(max<cum[i])
		{
			max=cum[i];
		}
	}
	printf("%d\n",max);
	return 0;
}
