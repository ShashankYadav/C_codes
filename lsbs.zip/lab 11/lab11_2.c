#include<stdio.h>
int main()
{
	int i,n,temp,shift;
	scanf("%d%d",&n,&shift);
	shift=shift%n;
	int a[n],b[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if((i+shift)>n-1)
		{
			b[(i+shift)%n]=a[i];
		}
		else
		{
			b[i+shift]=a[i];
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",b[i]);
	}
	printf("\n");
	return 0;
}
