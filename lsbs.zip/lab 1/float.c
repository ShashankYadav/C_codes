#include<stdio.h>
int main()
{
 float a=5.0,b=2.0,sum=a+b;
 printf("BOTH FLOAT\n");
 printf("%f + %f=",a,b);
 printf("%f\n",sum);
 printf("enter the value of a\n");
 scanf("%f",&a);
 printf("enter the value of b\n");
 scanf("%f",&b);
 sum=a+b;
 printf("sum=%f\n",sum);
 printf("\n\nONE FLOAT ONE INT\n");
 float x=3.0;
 int y=2;
 double div=x/y;
 printf("div=%.20lf\n",div);
 return 0;
}
