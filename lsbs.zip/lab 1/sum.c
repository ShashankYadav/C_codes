#include<stdio.h>
int main()
{
 int a=5,b=4,sum=a+b,product=a*b,diff=a-b,div=a/b,ch;
 printf("a=%d\tb=%d\tsum=%d\tdiff=%d\tproduct=%d\tdiv=%d\n",a,b,sum,diff,product,div);
 printf("1.give direct ans 2.show the variables operated\ngive your choice:");
 scanf("%d",&ch);
 switch( ch )
 {
 case 1: printf("Enter the value of a\n");
 	 scanf("%d",&a);
	 printf("Enter the value of b\n");
	 scanf("%d",&b);
	 sum=a+b;
	 product=a*b;
	 diff=a-b;
	 div=a/b;
	 printf("a=%d\nb=%d\nsum=%d\ndiff=%d\nproduct=%d\ndiv=%d\n",a,b,sum,diff,product,div);break;

 case 2: printf("Enter the value of a\n");
 	 scanf("%d",&a);
	 printf("Enter the value of b\n");
	 scanf("%d",&b);
         printf("%d + %d\n",a,b);
         sum=a+b;
         printf("sum=%d\n",sum);
         printf("%d - %d\n",a,b);
	 diff=a-b;
         printf("difference=%d\n",diff);
         printf("%d x %d\n",a,b);
	 product=a*b;
         printf("product=%d\n",product);break;
 
}
 return 0;
} 
