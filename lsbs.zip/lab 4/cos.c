#include<stdio.h>
#include<math.h>
int main()
{
	int n=0;
	double i,x=0,t=1,l=0;
	scanf("%lf %d",&x,&n);
	for(i=1;i<n;i++)
	{
		t+=t*(-((x*x)/((2*i)*((2*i)-1))));
	}
	printf("\n%lf",t);
	l=cos(x);
	printf("\ncos x is %lf",l);
	return 0;
}
