#include<stdio.h>
#include<math.h>
int main()
{
	int n=0,j=0,sign=1;
	float i;
	float comp=0,k;
	double x=0,t1=1,lo=0,t2=0;
	scanf("%lf",&x);
	t1 =x;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{	
		t2=(x*sign)/(i+1);
		printf(" x is %lf and t2 = %lf\n",x,t2);
		lo+=t2;
		printf("lo = %lf\n",lo);
		sign*=-1;
		x*=x;
	}
	k=1+t1;
	comp=log(k);
	printf("%lf",lo);
	printf("\nthe math.h log gives %f",comp);
	return 0;
}
