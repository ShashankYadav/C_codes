#include<stdio.h>
int main()
{
	float n=0,r=0,c=0,fact1=1,fact2=1;
	scanf("%f",&n);
	c=n;
	scanf("%f",&r);
        
	if((n-r)>r)
	{
		while(c>(n-r))fact1*=(c--);
		c=r;
		while(c>0)fact2*=(c--);
		printf("%f",fact1/fact2);
	}
	else if(r>(n-r))
	{
		while(c>r)fact1*=(c--);
		c=n-r;
		while(c>0)fact2*=(c--);
		printf("%f",fact1/fact2);
	}
return 0;
}
