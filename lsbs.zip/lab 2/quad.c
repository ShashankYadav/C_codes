#include<stdio.h>
#include<math.h>
int main()
{
        float a=0,b=0,c=0,r1=0,r2=0;
	scanf("%f",&a);
	scanf("%f",&b);
	scanf("%f",&c);
	if(b*b-4*a*c>0)
	{
		r1=(-b+sqrt(b*b-4*a*c))/2*a;
                r2=(-b-sqrt(b*b-4*a*c))/2*a;
		printf("%f\n",r1);
		printf("%f\n",r2);
	}
	else if(b*b-4*a*c==0)
	{
		r1=(-b+sqrt(b*b-4*a*c))/2*a;
		printf("%f\n",r1);
	}
	else
	{
		printf("no real roots");
	}	
        
	/*int i=-1000;
	for(i=-1000;i<1000;i++)
	{
		if(a*i*i+b*i+c==0)
		{
			printf("%d ",i);
		}
	}*/
	
	return 0;
}
