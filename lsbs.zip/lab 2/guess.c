#include<stdio.h>
#include<stdlib.h>
int main()
{
	
	int guess=5,ch=0,ans=1;
	guess=rand()%6;
        while(ans==1)
	{
		printf("enter your guess number\n");
		scanf("%d",&ch);
	        if(ch<5)
	        {
		      printf("answer is greater\n");
	        }
	        else if(ch>5)
	        { 
		      printf("answer is lesser\n");
	        }
	        else
	        {
		      printf("number is right\n");
	        }
		printf("want to try again(0 or 1)\n");
		scanf("%d",&ans);
	}	
}	
