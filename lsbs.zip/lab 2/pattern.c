#include<stdio.h>
int main()
{
	int i=1,j=0;
	for(i=0;i<5;i=i+1)
	{
		for(j=1;j<=i+1;j=j+1)
		{
			printf("%d",j);
		}
		
			printf("\n");
	}
return 0;
}

