#include<stdio.h>
int main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		int num,l,m=31,j;
		unsigned int x,y;
		x=1<<m;
		scanf("%d",&num);
		for(j=32;j>0;j--)
		{
			y=num&x;
			if(y>0)
				l=1;
			else
				l=0;
			num=num<<1;
			printf("%d",l);
		}
		printf("\n");
	}
	return 0;
}
