#include<stdio.h>
int main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		char c1;
		int i=0,j=0,counter=2;
		scanf("%c",&c1);
		counter--;
		while(c1!='\n'||counter>0)
		{
			if(c1=='\n')
			{
				scanf("%c",&c1);
			}
			j=(int)c1;
			i=i|j;
			if(c1==' ')
			{
				i=i<<8;
				counter--;
			}
				scanf("%c",&c1);
		}
		printf("%d\n",i);
	}
	return 0;
}
