#include<stdio.h>
int main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		int i,j,p,num,counter=4;
		char c;
		/*mask making
		
		p=~0;
		p=p<<8;
		p=~p;*/
		
		scanf("%d",&num);
		while(counter>0)
		{
			/*j=num&p;
			c=(char)j;*/
			c=num;
			printf("%c ",c);
			num=num>>8;
			counter--;
		}
	}
	return 0;
}
