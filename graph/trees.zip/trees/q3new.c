#include<stdio.h>
typedef struct student{
	int data;
	int col;
	int hash;
	int flag;
	int sub[1000]; 
	//int sub[1000];
}stud;
int main()
{
	stud a1[31];
	int i,j,h=0;
	for(i=0;i<31;i++)
	{
		a1[i].flag=0;
		a1[i].col=1;
	}
	for(i=0;i<31;i++)
	{
		for(j=0;j<1000;j++)
		{
			a1[i].sub[j]=-1;
		}
	}

	int num[25];
	int collisions=0;
	int extra[25];
	for(i=0;i<25;i++)
		scanf("%d",&num[i]);
	int a,b,p,m;
	scanf("%d %d %d %d",&a,&b,&p,&m);
	int hvalue;
	int hx;
	for(i=0;i<25;i++)
	{
		hvalue=((a*num[i]+b)%p)%m;
		//printf("hashval of %d is %d\n",num[i],hvalue);
		if(a1[hvalue].flag==0)
		{
		a1[hvalue].data=num[i];
		a1[hvalue].flag=1;
		a1[hvalue].hash=hvalue;
		}
		else
		{
			a1[hvalue].col++;
			extra[h++]=num[i];
			collisions++;
		}
	}
/*	for(i=0;i<31;i++)
		if(a1[i].flag==1)
			printf("...%d %d col= %d flag=%d\n",i,a1[i].data,a1[i].col,a1[i].flag);
*/	int size;
	int h1;
	for(i=0;i<h;i++)
	{
		  hvalue=((a*extra[i]+b)%p)%m;
		   if(a1[hvalue].col!=0)
		   {
			   size=(a1[hvalue].col)*(a1[hvalue].col);
			//   printf("size=%d\n",size);
			   hx=((a*extra[i]+b)%p)%size;
			   h1=((a*(a1[hvalue].data)+b)%p)%size;
			  // printf("####...hx(ext)= %d h1= %d\n",hx,h1);
			   a1[hvalue].sub[h1]=a1[hvalue].data;
			   a1[hvalue].sub[hx]=extra[i];
			   //a1[havlue].sub[hx+1]
		   }
	}
	for(i=0;i<31;i++)
	{
		if(a1[i].col>1)
		{
			for(j=625;j>=0;j--)
			{
				if(a1[i].sub[j-1]!=-1)
				{
					a1[i].sub[j]=9999;
					break;
				}
			}
		}
	}


/*	for(i=0;i<100;i++)
	{
		if(a1[9].sub[i]!=-1)
			printf("...........%d %d\n",i,a1[9].sub[i]);
	}*/
	//printf("\n\n");
	for(i=0;i<31;i++)
	{
		if(a1[i].flag==1)
		{
			if(a1[i].col==1)
				printf("%d %d\n",i,a1[i].data);
			else
			{
				int s=((a1[i].col)*(a1[i].col));
				printf("%d %d\n",i,s);
				for(j=0;j<=s;j++)
				{
					if(a1[i].sub[j]!=-1 && a1[i].sub[j+1]!=9999)
						printf("%d %d ",j,a1[i].sub[j]);
					else if(a1[i].sub[j]!=-1 && a1[i].sub[j+1]==9999)
					{
						printf("%d %d\n",j,a1[i].sub[j]);
						break;
					}
				}
			}
		}
	}
	return 0;
}



