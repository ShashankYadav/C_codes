#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void insert(stud **,int);
void print(stud *);
void print1(stud*);
void insert1(stud*,stud *);
int count=0;
int max=0;
int maxdepth(stud *,int);
int main()
{
	int n;
	scanf("%d",&n);
	int i,j,var;
	stud *start;
	start=(stud*)malloc(sizeof(stud*));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	//printf("** %d **\n",count);
	print(start);
	printf("** %d **\n",count);
	printf("\n");
	print1(start);

	int c1=0;
	int c2;
	c2=maxdepth(start,c1);
	printf("maxdepth=%d\n",c2);
	return 0;
}
void insert(stud **start,int d)
{
	if((*start)==NULL)
	{
		(*start)=(stud*)malloc(sizeof(stud));
		(*start)->next=NULL;
		(*start)->pre=NULL;
		(*start)->data=d;
		return;
	}
	else
	{
		if((*start)->data>d)
			insert(&((*start)->pre),d);
		else
			insert(&((*start)->next),d);
		return;
	}
	return;
}
void print(stud *start)
{
//int i=1;
	if(start!=NULL)
	{
	print(start->pre);
	//printf("%d ",start->data);
	count++;
	print(start->next);
	}
}
void print1(stud* start)
{
	stud *q;
	//stud *point=start;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=start->data;
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	int i=1;
	while(q->next)
	{
		rem=q->next->extra;
		q->next=q->next->next;
		printf("*%d* %d\n",i++,rem->data);
		//free(rem);
		//if(i==3)
		//break;
		if(rem->pre)
		{
			insert1(q,rem->pre);
			printf("               %d.  rem->pre=%d\n",i,rem->pre->data);
		//	start=start->pre;
		}
		if(rem->next)
		{
			insert1(q,rem->next);
			printf("               %d.  rem-next=%d\n",i,rem->next->data);
		//	start=start->next;
		}
		//printf("hello\n");
	}
}
void insert1(stud *start,stud *sample)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=sample->data;
	start->extra=sample;
	start->next=NULL;
}
int maxdepth(stud* start,int c1)
{
	if(start)
	{
		c1++;
		if(start->pre==NULL && c1>max)
		        max=c1;
		maxdepth(start->pre,c1);
		maxdepth(start->next,c1);
		//if(start->next==NULL && c1>max)
		//	max=c1;
	}
	return max;
}	


