#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	char name[9];
	int scope;
	int hash;
	int flag;
}stud;
int minid;
int length;
int main()
{
	char a[10];
	while(scanf("%s",a)!=EOF)
	{
		int ds=-1,ms=-1,ps=-1;
		int x=-1;
		stud arr[50];
		int br[20];
		int b_open=0;
		int b_close=0;
		int h=0;
		int k=0;
		while(1)
		{
			int z1;
			z1=strcmp(a,"DONE");
			if(z1==0)
			{//	printf("%d\n",z1);
				break;}
		//printf("%s\n",a);
		int r1=strcmp(a,"{");
		if(r1==0)
		{
			//ps=ms+1;
			ms=ms+1;
			br[h++]=ms;
			ds++;
			b_open++;
		//	printf("ms is %d\n",ms);
		}
		int r2=strcmp(a,"}");
		if(r2==0)
		{
			b_close++;
			ds--;
		}
		
		if(r1!=0 && r2!=0 && x==1)
		{
			ps=ms;
			strcpy(arr[k].name,a);
			arr[k].scope=ps;
			arr[k].flag=0;
			int len=strlen(a);
			int z;
			for(z=len;z<8;z++)
				a[z]='\0';
		
			arr[k++].hash=(a[0]*27 + a[1]*53 + a[2]*11 + a[3]*23 + a[4]*31 + a[5]*7 + a[6]*29 + a[7]*13)%37;
			x=-1;
			//printf("%s %d\n",a,ps);
		}
		else if(r1!=0 && r2!=0 && x==0)
		{
			ps=br[h-(b_open-b_close)-1];
			strcpy(arr[k].name,a);
			arr[k].scope=ps;
			arr[k].flag=0;
			int len=strlen(a);
			int z;
			for(z=len;z<8;z++)
				a[z]='\0';
			arr[k++].hash=(a[0]*27 + a[1]*53 + a[2]*11 + a[3]*23 + a[4]*31 + a[5]*7 + a[6]*29 + a[7]*13)%37;
			x=-1;
			
			//printf("%s %d\n",a,ps);

		}
		else if(r1!=0 && r2!=0 && x==-1)
		{
			strcpy(arr[k].name,a);
			arr[k].scope=ps;
			arr[k].flag=0;
			int len=strlen(a);
			int z;
			for(z=len;z<8;z++)
				a[z]='\0';
			arr[k++].hash=(a[0]*27 + a[1]*53 + a[2]*11 + a[3]*23 + a[4]*31 + a[5]*7 + a[6]*29 + a[7]*13)%37;
			x=-1;
		}

		//else(r1!=0 && r2!=0 && x==1)
		if(r1==0)
			x=1;
		else if(r1==1)
			x=0;
		scanf("%s",a);
		}
		length=k;
	int i=0;
/*	for(i=0;i<k;i++)
		printf("......%s %d\n",arr[i].name,arr[i].scope);*/
        stud temp;
	int v;
	stud error[15];
	int p=0,j;

	for(i=0;i<length;i++)
	{
		temp=arr[i];
		for(j=0;j<length;j++)
		{
			v=strcmp(temp.name,arr[j].name);
			if(v==0 && temp.scope==arr[j].scope && j!=i && arr[j].flag!=1)
			{
				error[p++]=temp;
				arr[i].flag=1;
			}
		}
	}

/*for(i=0;i<p;i++)
		printf("** %s %d\n",error[i].name,error[i].scope);*/
	stud arr1[15];
	int q=0;
	for(i=0;i<k;i++)
	{
		if(arr[i].flag==0)
			arr1[q++]=arr[i];
	}
	/*for(i=0;i<q;i++)
	{
		printf("-- %s %d\n",arr1[i].name,arr1[i].scope);
	}*/
	int valid_count=q;
	int error_count=p;
	stud temp1,min;

	for(i=0;i<q;i++)
	{
		min=arr1[i];
		minid=i;
		for(j=i;j<q;j++)
		{
			if(arr1[j].scope<arr1[minid].scope)
			{
				minid=j;
			}
				temp1=arr1[i];
				arr1[i]=arr1[minid];
				arr1[minid]=temp1;
		
		}
	}

	for(i=0;i<p;i++)
	{
		min=error[i];
		minid=i;
		for(j=i;j<p;j++)
		{
			if(error[j].scope<error[minid].scope)
			{
				minid=j;
			}
				temp1=error[i];
				error[i]=error[minid];
				error[minid]=temp1;
		}       
	} 
/*	for(i=0;i<q;i++)
	{
		printf("-- %s %d hash=%d\n",arr1[i].name,arr1[i].scope,arr1[i].hash);
	}*/
	int count=0;
	arr1[q].scope=9999;
	for(k=0;k<q;k++)
	{
		if(arr1[k].scope==arr1[k+1].scope && k!=q-1)
		{
		//	printf("k %d\n",arr1[k].scope);
		//	printf("k+1 %d\n",arr1[k+1].scope);
			count++;
		//	printf("%d\n",count);
		}
		if(arr1[k].scope!=arr1[k+1].scope||k==q-1)
		{
			int start=k-count;
			int end=k;
			//printf("start=%d end=%d\n",start,end);
			count=0;
			for(i=start;i<=end;i++)
			{
				//min=arr1[i];
				minid=i;
				for(j=i+1;j<=end;j++)
				{
					if(arr1[j].hash <= arr1[minid].hash)
					{
						minid=j;
					}
				}
					temp1=arr1[i];
					arr1[i]=arr1[minid];
					arr1[minid]=temp1;

				       
			}

		}
	}
/*	for(i=0;i<q;i++)
	{
		printf("------- %s %d hash = %d\n",arr1[i].name,arr1[i].scope,arr1[i].hash);
	}*/
	error[p].scope=9999;
	count=0;
	// for(i=0;i<p;i++)
	  //          printf("** %s %d\n",error[i].name,error[i].scope);

	for(k=0;k<p;k++)
	{
		if(error[k].scope==error[k+1].scope && k!=p-1)
		{
			//printf("k %d\n",error[k].scope);
			//printf("k+1 %d\n",error[k+1].scope);
			count++;
			//printf("%d\n",count);
		}
		if(error[k].scope!=error[k+1].scope||k==p-1)
		{
		 int start=k-count;
		 int end=k;
		//	printf("start=%d end=%d\n",start,end);
			count=0;
			for(i=start;i<=end;i++)
			{
				min=error[i];
				minid=i;
				for(j=i;j<=end;j++)
				{
					if(error[j].hash<error[minid].hash)
					{
						minid=j;
					}
						temp1=error[i];
						error[i]=error[minid];
						error[minid]=temp1;
					
				}
			}
		}
	}
	printf("%d\n",valid_count);
	printf("%d\n",error_count);
	for(i=0;i<q;i++)
	{
		printf("%s,%d\n",arr1[i].name,arr1[i].scope);
	}
	for(i=0;i<p;i++)
	{
		printf("%s,%d\n",error[i].name,error[i].scope);
	}
	}
	return 0;
}

