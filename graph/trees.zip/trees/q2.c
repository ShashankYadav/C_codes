#include<stdio.h>
typedef struct student{
	int scope;
	int hash;
	int flag;
}stud;
int main()
{
	char a[10];
	char b[1000];
	int i=0;
	while(scanf("%c",&a)!=EOF)
	{
		b[i++]=a;
	}
	int j;
	//for(j=0;j<i;j++)
	//	printf("%c*",b[j]);
	int ds=-1,ms=-1,ps=-1;
	//printf("%d",strcmp("a","a"));
	for(j=0;j<i;j++)
	{
		if(b[j]=='{')
		{
			//ps=ms+1;
			ms=ms+1;
			ds++;
		//	printf("ms is %d\n",ms);
		}
		if(b[j]=='}')
		{
			ds--;
		}
		if(j!=0 && b[j]!='{' && b[j]!='}' && b[j-2]=='{' && b[j]!='\n')
		{
			ps=ms;
			printf("%c %d\n",b[j],ps);
		}
		else if(b[j]!='{' && b[j]!='}' && b[j]!='\n')
		{
			ps=ds;
			printf("%c %d\n",b[j],ps);

		}
	}




	return 0;
}

