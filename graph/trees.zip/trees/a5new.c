#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
void inprint(stud*,int,int);
void all(stud *,int [],int);
void preprint(stud *,int,int);
int a1[1000][2];
int b1[1000];
void create(stud **,int);
void insert1(stud *,int,int);
void insert2(stud *,int,int);
void depth(stud *,int ,int);
int fl=0;
void postprint(stud*,int,int);
void all(stud *,int [],int);
void search(stud *,int,int);
void splay(stud *,int);
stud *single1(stud *);
stud *single2(stud *);
stud *par,*child,*gpar;
stud *node;
int gd;
int main()
{
	int pc=0;
		fl=0;
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a1[i][0]);
	}
	for(i=0;i<n;i++)
	{
		scanf("%d",&b1[i]);
	} 
	int k=0;
	for(k=0;k<n;k++)
		a1[k][1]=0;
	stud *start1;
	start1=(stud*)malloc(sizeof(stud));
	start1->data=b1[0];
	start1->pre=NULL;
	start1->next=NULL;
	for(k=0;k<n;k++)
	{
		if(a1[k][0]==b1[0])
			a1[k][1]=1;
	}
	create(&start1,n);
//	printf("\n");
//	inprint(start1);
//	printf("\n");
//	all(start1,a,0);
//	printf("\n");
        int v;
	scanf("%d",&v);
	node=(stud*)malloc(sizeof(stud));
	node->next=start1;
//	postprint(start1);
//	printf("\n");
	int arr[n];
//	all(start1,arr,0);
	splay(start1,v);
//	printf("\n");
//	all(node->next,arr,0);
	inprint(node->next,0,n);
	printf("\n");
	preprint(node->next,0,n);
	printf("\n");
	postprint(node->next,0,n);
	printf("\n");
	return 0;
}






void depth(stud *start,int c1,int d)
{
	if(start)
	{
		c1++;
		depth(start->pre,c1,d);
		if(start->data==d)
			gd=c1;
		depth(start->next,c1,d);
	}
}

void splay(stud *start,int v)
{
	while(1)
	{
		if(gd==2)
			break;
		depth(start,0,v);
//		printf("depth is %d\n",gd);
//		if(gd==1)
//			break;
//	printf("bye\n");
		search(start,v,0);
//		printf("par=%d\n",par->data);
//		printf("child=%d\n",child->data);
		if(gd!=2)
		{
		search(start,par->data,1);
//	        printf("gpar=%d\n",gpar->data);
		}
		if(gd==2)
		{
//			printf("b\n");
		if(child->data==par->pre->data)
		{
			node->next=single1(par);
                //   	printf("hello\n");
			int b[1000];
//			all(node->next,b,0);
			break;
		}
		else
		{
//			printf("hihi\n");
			node->next=single2(par);
			int c[1000];
//			all(node->next,c,0);
		}
		}
		else
		{
		if(par->data==gpar->pre->data)
		{
		if(child->data==par->pre->data)
			gpar->pre=single1(par);
		else
			gpar->pre=single2(par);
		}
		else
		{
		if(child->data==par->pre->data)
			gpar->next=single1(par);
		else
			gpar->next=single2(par);
		}
		}

		int a[1000];
		//printf("start->pre=%d\n",start->pre->data);
//		all(start,a,0);
	//	break;
	}
}


stud *single1(stud *start)
{
	stud *k1,*k2,*x;
	x=child;
	k1=x->pre;
	k2=x->next;
//	printf("k1=%d\n",k1->data);
//	printf("k2=%d\n",k2->data);
	par->pre=NULL;
	x->next=par;
	par->pre=k2;
	return x;

}
stud *single2(stud *start)
{
	stud *k1,*k2,*x;
	x=child;
	k1=x->pre;
	k2=x->next;
//	printf("k1=%d\n",k1->data);
//	printf("k2=%d\n",k2->data);
	par->next=NULL;
	x->pre=par;
	par->next=k1;
//	printf("hello\n");
	return x;
}








void search(stud *start,int d,int index)
{
	if(start->data==d)
	{
		if(index==0)
		child=start;
		return;
	}
	else if(d<start->data)
	{
		if(index==0)
		par=start;
		else
			gpar=start;
		search(start->pre,d,index);
	}
	else
	{
		if(index==0)
		par=start;
		else
			gpar=start;
		search(start->next,d,index);
	}
}


void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}

void inprint(stud *start,int c1,int n)
{
	if(start)
	{
		c1++;
		inprint(start->pre,c1,n);
		if(c1==n)
		printf("%d\n",start->data);
		else
			printf("%d ",start->data);
		inprint(start->next,c1,n);
	}
}
void preprint(stud *start,int c1,int n)
{
	if(start)
	{
		c1++;
		if(c1==n)
		printf("%d\n",start->data);
		else
			printf("%d ",start->data);
		preprint(start->pre,c1,n);
		preprint(start->next,c1,n);
	}
}

void create(stud **start,int n)
{
	int i,j,k;
	int key,index;
	int left_id,right_id;
	int left,right;
	int left_flag,right_flag;
	for(i=1;i<n;i++)
	{
		left_flag=-1;
		right_flag=-1;
		key=b1[i];
		for(j=0;j<n;j++)
		{
			if(a1[j][0]==key)
			{
				index=j;
				break;
			}
		}
	//	printf("index of b1[%d] is %d\n",i,index);
		for(k=index+1;k<n;k++)
		{
			if(a1[k][1]==1)
			{
				right=a1[k][0];
				right_id=k;
				right_flag=a1[k][1];
				break;
			}
		}
		for(k=index-1;k>=0;k--)
		{
			if(a1[k][1]==1)
			{
				left=a1[k][0];
				left_id=k;
				left_flag=a1[k][1];
			        break;
			}
		}
	//	printf("left %d - %d......... right %d - %d\n",left_flag,left,right_flag,right);
		if(left_flag==-1 && right_flag==1)
		{

			insert1((*start),key,right);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==-1)
		{
			insert2((*start),key,left);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==1)
		{
			insert2((*start),key,left);
	//		printf("fl=%d\n",fl);
			if(fl==0)
			{
	//			printf("hello\n");
				insert1((*start),key,right);
			}
			a1[index][1]=1;
			fl=0;
		}
	}
}
void insert1(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			start->pre=(stud*)malloc(sizeof(stud));
			start->pre->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->pre->next=NULL;
			start->pre->pre=NULL;
			return;
		}
		insert1(start->pre,d,match);
		insert1(start->next,d,match);

	}
}
void insert2(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			if(start->next)
				return;
			start->next=(stud*)malloc(sizeof(stud));
			start->next->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->next->next=NULL;
			start->next->pre=NULL;
			fl=1;
			return;
		}
		insert2(start->pre,d,match);
		insert2(start->next,d,match);
	}
}
void postprint(stud *start,int c1,int n)
{
	if(start)
	{
		c1++;
		postprint(start->pre,c1,n);
		postprint(start->next,c1,n);
		if(c1==n)
		printf("%d\n",start->data);
		else
			printf("%d ",start->data);
	}
}

































