#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	char sign;
	int data;
	struct student *right;
	struct student *left;
	struct student *next;
	struct student *tree;
}stud;
void insert(stud *,stud *);
void createtree(stud **,int);
void jointree(stud *);

int main()
{
	char s[100];
	scanf("%s",s);
	int len;
	len=strlen(s);
	int i,j;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start->next=NULL;
	int num;
	stud *tr;
	tr=(stud*)malloc(sizeof(stud));
	tr=NULL;
	for(i=0;i<len;i++)
	{
		if(s[i]!='+'&&s[i]!='*'&&s[i]!='-'&&s[i]!='/')
		{ 
		        num=s[i]-48;
			createtree(&tr,num);
			insert(start,tr);
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/')
		{
			stud *signtr;
			signtr=(stud*)malloc(sizeof(stud));
			signtr->sign=s[i];
			signtr->data=99;
			signtr->left=NULL;
			signtr->right=NULL;
			insert(start,signtr);
			jointree(start);
		}
	}
	start=start->next;
	while(start)
	{
		printf("%d ",start->tree->data);
		printf("%d %d\n",start->tree->left->data,start->tree->right->data);

		start=start->next;
	}
	//printf("%d %d\n",start->tree->left->data,start->tree->right->data);
	return 0;
}
void insert(stud *start,stud *tr)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->tree=tr;
	start->next=NULL;
}
void createtree(stud **tr,int d)
{
   (*tr)=(stud*)malloc(sizeof(stud));
   (*tr)->data=d;
   (*tr)->sign='a';
   (*tr)->right=NULL;
   (*tr)->left=NULL;
}
void jointree(stud *start)
{
	stud *temp1;
	stud *temp2;
	stud *final;
	printf("ok\n");
	while(start->next->next->next)
	{
		printf("hello\n");
		if(start->next->next->next->tree->sign=='+'||start->next->next->next->tree->sign=='/'||start->next->next->next->tree->sign=='*'||start->next->next->next->tree->sign=='-')
		{
			//printf("temp1->data=%d\n",temp1->data);
			//printf("temp2->data=%d\n",temp2->data);
			//printf("final->sign=%d\n",final->sign);
			temp1=start->next;
			//temp1->next=NULL;
			temp2=start->next->next;
			//temp2->next=NULL;
			final=start->next->next->next;
			temp1->next=NULL;
			temp2->next=NULL;
			printf("temp1->data=%d\n",temp1->tree->data);
			printf("temp2->data=%d\n",temp2->tree->data);
			printf("final->sign=%d\n",final->tree->sign);

			final->tree->left=temp1->tree;
			final->tree->right=temp2->tree;
			start->next=final;
		}
		start=start->next;
		if(start->next==NULL)
			break;
		else if (start->next->next==NULL)
			break;
	}
}
