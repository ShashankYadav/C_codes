#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
int c1=0;
void insert(stud **,int);
void print(stud*);
void all(stud *,int [],int);
void search(stud *,int);
stud *single_rotate1(stud *);
stud *single_rotate2(stud *);
stud *t;
stud *start1;
stud *par;
stud *double_rotate1(stud*);
stud *double_rotate2(stud*);

int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	int var;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
	//	if(var==10)
	//		printf("\n\n");
		insert(&start,var);
			start1=start;
	}
	int ht=height(start);
	print(start);
	printf("\n\n");
	all(start,a,0);
	
	return 0;
}
void insert(stud **start,int d)
{
	if(*start==NULL)
	{
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=d;
		(*start)->next=NULL;
		(*start)->pre=NULL;
		return;
	}
	if(d<(*start)->data)
	{
		insert(&((*start)->pre),d);
		printf("<start = %d\n",(*start)->data);
		printf("<pre = %d\n",height((*start)->pre));
		printf("<next = %d\n",height((*start)->next));

		if(height((*start)->pre)-height((*start)->next)==2)
		{
		//	printf("hi\n");
		//	printf("start->data= %d\n",(*start)->data);

			if(d<(*start)->pre->data)
				(*start)=single_rotate1(*start);
			else
				(*start)=double_rotate1(*start);
			//	printf("start->left = %d\n",(*start)->pre->data);
			//	 printf("start->right = %d\n",(*start)->next->data);

		}
	}
	else
	{
		insert(&((*start)->next),d);
		printf(">start = %d\n",(*start)->data);
		printf(">pre = %d\n",height((*start)->pre));
		printf(">next = %d\n",height((*start)->next));
		if(height((*start)->next)-height((*start)->pre)==2)
		{
		//	printf("hi\n");
		//	printf("start->data= %d\n",(*start)->data);
		if(d>(*start)->next->data)
			(*start)=single_rotate2(*start);
		else
			(*start)=double_rotate2(*start);
			//      printf("start->left = %d\n",(*start)->pre->data);
			//       printf("start->right = %d\n",(*start)->next->data);
		}
	}

		return;
}


stud *single_rotate1(stud *start)
{
	stud *k2=start;
	stud *k1;
	k1=start->pre;
	k2->pre=k1->next;
	k1->next=k2;
	return k1;
}

stud *single_rotate2(stud *start)
{
	stud *k2=start;
	stud *k1;
	k1=start->next;
	k2->next=k1->pre;
	k1->pre=k2;
	return k1;
}

stud *double_rotate1(stud *start)
{
	stud *k1,*k2,*k3;
	k3=start;
	k1=k3->pre;
	k2=k1->next;
	k1->next=k2->pre;
	k2->pre=k1;
	k3->pre=k2->next;
	k2->next=k3;
	return k2;
}

stud *double_rotate2(stud *start)
{
	stud *k1,*k2,*k3;
	k3=start;
	k1=k3->next;
	k2=k1->pre;
	k1->pre=k2->next;
	k2->next=k1;
	k3->next=k2->pre;
	k2->pre=k3;
	printf("k2 %d \n",k2->data);
	printf("k2->pre %d\n",k2->pre->data);
	printf("k2->next %d\n",k2->next->data);
	return k2;
}

	






void search(stud *start,int d)
{
	if(start)
	{
		if(start->pre)
			if(start->pre->data==d)
			par=start;
		search(start->pre,d);
		if(start->next)
			if(start->next->data==d)
			par=start;
		search(start->next,d);
	}
}

void print(stud *start)
{
	if(start)
	{
		print(start->pre);
		printf("%d ",start->data);
		print(start->next);
	}
}
void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}
int height(stud *start)
{
	if(start==NULL)
		return 0;
	else
	{
		int l=height(start->pre);
		//if(start->pre)
			//start->pre->ht=l;
		//      printf("\n...pre %d....%d...\n",start->pre->data,l);
		int r=height(start->next);
		//if(start->next)
			//start->next->ht=r;
		//      printf("\n...next %d....%d...\n",start->next->data,r);
		//      return l+1;
		//      return r+1;
		if(l>r)
			return l+1;
		else
			return r+1;
	}
}







