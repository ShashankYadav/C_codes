#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
void depth(stud *,int,int)
void all(stud *,int ,int)
void inprint(stud*);
void all(stud *,int [],int);
void preprint(stud *);
int a1[1000][2];
int b1[1000];
void create(stud **,int);
void insert1(stud *,int,int);
void insert2(stud *,int,int);
void search(stud *,int);
stud *root,*tt;
int fl=0;
void postprint(stud*);
int main()
{
//	int var1,var2;
//	scanf("%d",&var2);
//	for(var1=0;var1<var2;var1++)
//	{
		fl=0;
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a1[i][0]);
	}
	for(i=0;i<n;i++)
	{
		scanf("%d",&b1[i]);
	} 
	int k=0;
	for(k=0;k<n;k++)
		a1[k][1]=0;
	stud *start1;
	start1=(stud*)malloc(sizeof(stud));
	start1->data=b1[0];
	start1->pre=NULL;
	start1->next=NULL;
	for(k=0;k<n;k++)
	{
		if(a1[k][0]==b1[0])
			a1[k][1]=1;
	}
	create(&start1,n);
//	printf("\n");
//	inprint(start1);
//	printf("\n");
//	all(start1,a,0);
//	printf("\n");
	postprint(start1);
	printf("\n");
	int v;
	scanf("%d",&v);
	search(start1,v);
	printf("par is %d\n",tt->data);
//	}
	
	return 0;
}
void search(stud *start,int d)
{
	if(start==NULL)
		return;
	else
	{
		tt=start;
		search(start->left,d);
		if(start->data==d)
			return;
		tt=start;
		search(start->right,d);
	}
}

void inprint(stud *start)
{
	if(start)
	{
		inprint(start->pre);
		printf("%d ",start->data);
		inprint(start->next);
	}
}
void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}
void preprint(stud *start)
{
	if(start)
	{
		printf("%d ",start->data);
		preprint(start->pre);
		preprint(start->next);
	}
}

void create(stud **start,int n)
{
	int i,j,k;
	int key,index;
	int left_id,right_id;
	int left,right;
	int left_flag,right_flag;
	for(i=1;i<n;i++)
	{
		left_flag=-1;
		right_flag=-1;
		key=b1[i];
		for(j=0;j<n;j++)
		{
			if(a1[j][0]==key)
			{
				index=j;
				break;
			}
		}
	//	printf("index of b1[%d] is %d\n",i,index);
		for(k=index+1;k<n;k++)
		{
			if(a1[k][1]==1)
			{
				right=a1[k][0];
				right_id=k;
				right_flag=a1[k][1];
				break;
			}
		}
		for(k=index-1;k>=0;k--)
		{
			if(a1[k][1]==1)
			{
				left=a1[k][0];
				left_id=k;
				left_flag=a1[k][1];
			        break;
			}
		}
	//	printf("left %d - %d......... right %d - %d\n",left_flag,left,right_flag,right);
		if(left_flag==-1 && right_flag==1)
		{

			insert1((*start),key,right);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==-1)
		{
			insert2((*start),key,left);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==1)
		{
			insert2((*start),key,left);
	//		printf("fl=%d\n",fl);
			if(fl==0)
			{
	//			printf("hello\n");
				insert1((*start),key,right);
			}
			a1[index][1]=1;
			fl=0;
		}
	}
}
void insert1(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			start->pre=(stud*)malloc(sizeof(stud));
			start->pre->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->pre->next=NULL;
			start->pre->pre=NULL;
			return;
		}
		insert1(start->pre,d,match);
		insert1(start->next,d,match);

	}
}
void insert2(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			if(start->next)
				return;
			start->next=(stud*)malloc(sizeof(stud));
			start->next->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->next->next=NULL;
			start->next->pre=NULL;
			fl=1;
			return;
		}
		insert2(start->pre,d,match);
		insert2(start->next,d,match);
	}
}
void postprint(stud *start)
{
	if(start)
	{
		postprint(start->pre);
		postprint(start->next);
		printf("%d ",start->data);
	}
}
/*

stud *single1(stud *start)
{
	stud *px,*x;
	px=start;
	x=start->pre;
	px->pre=x->next;
	x->next=px;
	px->par=x;
	if(px->pre)
	px->pre->par=px;
	if(px->next)
	px->next->par=px;
	return x;
}
stud *single2(stud *start)
{
	stud *px,*x;
	px=start;
	printf("px= %d\n",px->data);
	x=px->next;
	printf("x= %d\n",x->data);
	px->next=x->pre;
	x->pre=px;
	px->par=x;
	if(px->pre)
	px->pre->par=px;
	if(px->next)
	px->next->par=px;
	printf("hello\n");
	return x;
}




void splay(stud *root,stud *start)
{
	printf("splay %d\n",start->data);
	if(start->par)
		printf("splay->par %d\n",start->par->data);
	if(start->par->par)
		printf("splay->par->par %d\n",start->par->par->data);
	depth(root,-1,start->data);
	int dp=gd;
	printf("depth of %d is %d\n",start->data,dp);
	if(dp==1)
	{
		int c[10];
		all(start->par,c,0);
		stud *px;
		px=start->par;
		if(start->data<px->data)
		     px=single1(px);
		else
		     px=single2(px);
		return;
	}
}


void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}

*/
void depth(stud *start,int c1,int d)
{
	if(start)
	{
		c1++;
		depth(start->pre,c1,d);
		if(start->data==d)
			gd=c1;
		depth(start->next,c1,d);
	}
}























