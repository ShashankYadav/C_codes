#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	int ht;
	int flag;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void insert(stud **,int);
void print(stud*);
int height(stud *);
void all(stud *,int [],int);
void store(stud *);
void level(stud *);
void insert1(stud *,stud *);
void check(stud *);
int flag_bst=1;
int flag_avl=1;
int a=-99;
int h1,h2;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	int var;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	check(start);
	printf("%d\n",flag_bst);
	if(flag_bst==1)
	{
	//	printf("%d\n",flag_avl);
	int maxht;
	maxht=height(start);
	start->ht=maxht;
	store(start);
	printf("%d\n",flag_avl);
	int t1,t2;
	if (start->pre)
	 t1=start->pre->ht;
	else
		t1=0;
	if(start->next)
	    t2=start->next->ht;
	else
		t2=0;
	if(abs(t1-t2)>2)
		printf("%d ",start->data);
	level(start);
	if(flag_avl==0)
	      printf("\n");
	}
	else
		printf("0\n");

	return 0;
}
void check(stud *start)
{
	if(start)
	{
		check(start->pre);
		if(start->data<a)
		{
			flag_bst=0;
			a=start->data;
		}
		check(start->next);
	}
}



void insert(stud **start,int d)
{
	if(*start==NULL)
	{
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=d;
		(*start)->flag=0;
		(*start)->ht=0;
		(*start)->next=NULL;
		(*start)->pre=NULL;
		return;
	}
	if((*start)->data>d)
		insert(&((*start)->pre),d);
	else
		insert(&((*start)->next),d);
	return;
}
void store(stud *start)
{
	if(start)
	{
		store(start->pre);
		//printf("ht of %d is %d\n",start->data,start->ht);
		store(start->next);
		if(start->pre)
		      h1=start->pre->ht;
		else
		      h1=0;
		if(start->next)
		     h2=start->next->ht;
		else
		      h2=0;
		int diff=h1-h2;
		if(abs(diff)>2)
		{
			flag_avl=0;
			if(start->pre)
			{
			start->pre->flag=1;
			//printf("* %d   %d\n",start->pre->data,start->pre->flag);
			}
			if(start->next)
			{
				start->next->flag=1;
			//printf("* %d   %d\n",start->next->data,start->next->flag);

		}}
	}
}

void print(stud *start)
{
	if(start)
	{
		print(start->pre);
		printf("%d ",start->data);
		print(start->next);
	}
}
int height(stud *start)
{
	if(start==NULL)
		return 0;
	else
	{
		int l=height(start->pre);
		if(start->pre)
			start->pre->ht=l;
	//	printf("\n...pre %d....%d...\n",start->pre->data,l);
		int r=height(start->next);
		if(start->next)
			start->next->ht=r;
	//	printf("\n...next %d....%d...\n",start->next->data,r);
	//	return l+1;
	//	return r+1;
		if(l>r)
		return l+1;
		else
			return r+1;
	}
}
void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}


void level(stud* start)
{
	stud *q;
	//stud *point=start;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=start->data;
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	int i=1;
	while(q->next)
	{
		rem=q->next->extra;
		q->next=q->next->next;
		if(rem->flag==1)
		     printf("%d ",rem->data);
		//free(rem);
		//if(i==3)
		//break;
		if(rem->pre)
		{
			insert1(q,rem->pre);
			//      start=start->pre;
		}
		if(rem->next)
		{
			insert1(q,rem->next);
			//      start=start->next;
		}
		//printf("hello\n");
	}
}

void insert1(stud *start,stud *sample)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=sample->data;
	start->extra=sample;
	start->next=NULL;
}

