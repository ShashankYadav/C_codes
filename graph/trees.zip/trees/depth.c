#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
int c1=0;
void insert(stud **,int);
void print(stud*);
void max(stud*,int);
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int var;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	print(start);
	printf("\n");
	int num;
	max(start,0);
	printf("%d\n",c1);
	return 0;
}
void insert(stud **start,int d)
{
	if(*start==NULL)
	{
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=d;
		(*start)->next=NULL;
		(*start)->pre=NULL;
		return;
	}
	if((*start)->data>d)
		insert(&((*start)->pre),d);
	else
		insert(&((*start)->next),d);
	return;
}
void print(stud *start)
{
	if(start)
	{
		print(start->pre);
		printf("%d ",start->data);
		print(start->next);
	}
}
void max(stud *start,int c)
{
	if(start)
	{
		c++;
		if(start->pre==NULL && c>c1)
			c1=c;
		max(start->pre,c);
		max(start->next,c);
	}
	//return c1;
}
		


