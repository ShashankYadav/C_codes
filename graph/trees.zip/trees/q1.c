#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void insert(stud **,int);
void print_pre(stud *,int);
void print_level(stud*,int);
void insert1(stud*,stud *);
void print(stud *);
int depth;
int counter=0;
int flag=0;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j,var;
	stud *start;
	start=(stud*)malloc(sizeof(stud*));
	start=NULL;
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	stud *queue;
	queue=(stud *)malloc(sizeof(stud));
	queue->next=(stud *)malloc(sizeof(stud));
	queue->next->extra=start;
	queue->next->next=NULL;
	scanf("%d",&depth);
	void print(queue);
	//printf("\n");
	//void print(start,a,1);
	//print1(start,n);
	return 0;
}
void insert(stud **start,int d)
{
	if((*start)==NULL)
	{
		(*start)=(stud*)malloc(sizeof(stud));
		(*start)->next=NULL;
		(*start)->pre=NULL;
		(*start)->data=d;
		return;
	}
	else
	{
		if((*start)->data>d)
			insert(&((*start)->pre),d);
		else
			insert(&((*start)->next),d);
		return;
	}
	return;
}
void print_pre(stud *start,int c1)
{
//int i=1;
       if(flag==0)
       {
       stud *q;
       q=(stud*)malloc(sizeof(stud));
       q->next=NULL;
       flag++;
       }
	if(start!=NULL)
	{
		if(c1==depth)
		{
			q->next=(stud*)malloc(sizeof(stud));
			q->next->extra=start;
		}
	c1++;
	if(c1<=depth)
	{
//	counter++;
        printf("%d ",start->data);
	
	print_pre(start->pre,c1);
//	printf("%d ",start->data);
	print_pre(start->next,c1);
	}
	}
	queue(start);

}
void print_level(stud* start,int n)
{
	int counter1=0;
	stud *q;
	//stud *point=start;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=start->data;
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	int i=1;
	while(q->next)
	{

		rem=q->next->extra;
		q->next=q->next->next;
		counter1++;
		if(counter1>counter)
		{
			if(counter1==n)
			{
				printf("%d\n",rem->data);
				break;
			}
		 printf("%d ",rem->data);
		}
		
		//free(rem);
		//if(i==3)
		//break;
		if(rem->pre)
		{
			insert1(q,rem->pre);
		//	start=start->pre;
		}
		if(rem->next)
		{
			insert1(q,rem->next);
		//	start=start->next;
		}
		//printf("hello\n");
	}
}
void insert1(stud *start,stud *sample)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=sample->data;
	start->extra=sample;
	start->next=NULL;
}
void print(queue)
{
	queue=queue->next;
	while(queue)
	{
		print_pre(queue->extra,0);
		queue=queue->next;
	}
}
	
	


