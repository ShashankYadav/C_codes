#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	int ht;
	int flag;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void inprint(stud*);
void preprint(stud *);
int a1[1000][2];
int b1[1000];
void create(stud **,int);
void insert1(stud *,int,int);
void insert2(stud *,int,int);
int fl=0;
void postprint(stud*);
void print(stud*);
int height(stud *);
void all(stud *,int [],int);
void store(stud *);
void level(stud *);
void insert_level(stud *,stud *);
void check(stud *);
int flag_bst=1;
int flag_avl=1;
int cc=0,a;
int h1,h2;
int main()
{
	int var1,var2;
	scanf("%d",&var2);
	for(var1=0;var1<var2;var1++)
	{
		fl=0;
		cc=0;
		flag_bst=1;
		flag_avl=1;
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a1[i][0]);
	}
	for(i=0;i<n;i++)
	{
		scanf("%d",&b1[i]);
	} 
	int k=0;
	for(k=0;k<n;k++)
		a1[k][1]=0;
	stud *start1;
	start1=(stud*)malloc(sizeof(stud));
	start1->data=b1[0];
	start1->pre=NULL;
	start1->next=NULL;
	for(k=0;k<n;k++)
	{
		if(a1[k][0]==b1[0])
			a1[k][1]=1;
	}
	create(&start1,n);
	inprint(start1);
	printf("\n");
	check(start1);
	printf("%d\n",flag_bst);
	if(flag_bst==1)
	{
		//      printf("%d\n",flag_avl);
		int maxht;
		maxht=height(start1);
		start1->ht=maxht;
		store(start1);
		printf("%d\n",flag_avl);
		int t1,t2;
		if (start1->pre)
			t1=start1->pre->ht;
		else
			t1=0;
		if(start1->next)
			t2=start1->next->ht;
		else
			t2=0;
		if(abs(t1-t2)>2)
			printf("%d ",start1->data);
		level(start1);
		if(flag_avl==0)
			printf("\n");
	}
	else
		printf("0\n");
	}
	
	return 0;
}
void inprint(stud *start)
{
	if(start)
	{
		inprint(start->pre);
		printf("%d ",start->data);
		inprint(start->next);
	}
}
void preprint(stud *start)
{
	if(start)
	{
		printf("%d ",start->data);
		preprint(start->pre);
		preprint(start->next);
	}
}

void create(stud **start,int n)
{
	int i,j,k;
	int key,index;
	int left_id,right_id;
	int left,right;
	int left_flag,right_flag;
	for(i=1;i<n;i++)
	{
		left_flag=-1;
		right_flag=-1;
		key=b1[i];
		for(j=0;j<n;j++)
		{
			if(a1[j][0]==key)
			{
				index=j;
				break;
			}
		}
	//	printf("index of b1[%d] is %d\n",i,index);
		for(k=index+1;k<n;k++)
		{
			if(a1[k][1]==1)
			{
				right=a1[k][0];
				right_id=k;
				right_flag=a1[k][1];
				break;
			}
		}
		for(k=index-1;k>=0;k--)
		{
			if(a1[k][1]==1)
			{
				left=a1[k][0];
				left_id=k;
				left_flag=a1[k][1];
			        break;
			}
		}
	//	printf("left %d - %d......... right %d - %d\n",left_flag,left,right_flag,right);
		if(left_flag==-1 && right_flag==1)
		{

			insert1((*start),key,right);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==-1)
		{
			insert2((*start),key,left);
			a1[index][1]=1;
			fl=0;
		}
		if(left_flag==1 && right_flag==1)
		{
			insert2((*start),key,left);
	//		printf("fl=%d\n",fl);
			if(fl==0)
			{
	//			printf("hello\n");
				insert1((*start),key,right);
			}
			a1[index][1]=1;
			fl=0;
		}
	}
}
void insert1(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			start->pre=(stud*)malloc(sizeof(stud));
			start->pre->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->pre->next=NULL;
			start->pre->pre=NULL;
			return;
		}
		insert1(start->pre,d,match);
		insert1(start->next,d,match);

	}
}
void insert2(stud *start,int d,int match)
{
	if(start)
	{
		if(start->data==match)
		{
			if(start->next)
				return;
			start->next=(stud*)malloc(sizeof(stud));
			start->next->data=d;
		//	printf("\n start->data=%d\n",start->data);
			start->next->next=NULL;
			start->next->pre=NULL;
			fl=1;
			return;
		}
		insert2(start->pre,d,match);
		insert2(start->next,d,match);
	}
}
void postprint(stud *start)
{
	if(start)
	{
		postprint(start->pre);
		postprint(start->next);
		printf("%d ",start->data);
	}
}
void check(stud *start)
{
	if(start)
	{
		check(start->pre);
		if(cc==0)
		{
		    a=start->data;
		    cc++;
		}
		if(start->data<a)
		{
			//printf("hi");
			flag_bst=0;
		//	a=start->data;
		}
		a=start->data;
		check(start->next);
	}
}
void store(stud *start)
{
	if(start)
	{
		store(start->pre);
		//printf("ht of %d is %d\n",start->data,start->ht);
		store(start->next);
		if(start->pre)
		      h1=start->pre->ht;
		else
		      h1=0;
		if(start->next)
		     h2=start->next->ht;
		else
		      h2=0;
		int diff=h1-h2;
		if(abs(diff)>2)
		{
			flag_avl=0;
			if(start->pre)
			{
			start->pre->flag=1;
			//printf("* %d   %d\n",start->pre->data,start->pre->flag);
			}
			if(start->next)
			{
				start->next->flag=1;
			//printf("* %d   %d\n",start->next->data,start->next->flag);

		}}
	}
}
int height(stud *start)
{
	if(start==NULL)
		return 0;
	else
	{
		int l=height(start->pre);
		if(start->pre)
			start->pre->ht=l;
	//	printf("\n...pre %d....%d...\n",start->pre->data,l);
		int r=height(start->next);
		if(start->next)
			start->next->ht=r;
	//	printf("\n...next %d....%d...\n",start->next->data,r);
	//	return l+1;
	//	return r+1;
		if(l>r)
		return l+1;
		else
			return r+1;
	}
}
void level(stud* start)
{
	stud *q;
	//stud *point=start;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=start->data;
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	int i=1;
	while(q->next)
	{
		rem=q->next->extra;
		q->next=q->next->next;
		if(rem->flag==1)
		     printf("%d ",rem->data);
		//free(rem);
		//if(i==3)
		//break;
		if(rem->pre)
		{
			insert_level(q,rem->pre);
			//      start=start->pre;
		}
		if(rem->next)
		{
			insert_level(q,rem->next);
			//      start=start->next;
		}
		//printf("hello\n");
	}
}

void insert_level(stud *start,stud *sample)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=sample->data;
	start->extra=sample;
	start->next=NULL;
}
































