#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	int i,j;
	scanf("%d",&a[1]);
	int var;
	int parent;
	int k;
	int temp;
	int flag=0;
	for(i=2;i<n+1;i++)
	{
		flag=0;
		printf("hi\n");
		scanf("%d",&var);

		a[i]=var;
		k=i;
		while(k!=1 && flag==0)
		{

		parent=k/2;
		if(a[parent]>a[k])
		{
			temp=a[parent];
			a[parent]=a[k];
			a[k]=temp;
			
			k=parent;
		}
		else
			flag=1;

		}
	}

	for(j=1;j<i;j++)
		printf("%d ",a[j]);

	return 0;
}


