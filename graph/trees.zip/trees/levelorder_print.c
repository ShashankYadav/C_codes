#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void insert(stud **,int);
void print(stud *);
void print1(stud*);
void insert1(stud*,stud *);
void insert2(stud *,stud *);
void depth(stud *,int);
void l(stud *);
int max=-1;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j,var;
	stud *start;
	start=(stud*)malloc(sizeof(stud*));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	print(start);
	printf("\n");
	print1(start);
	depth(start,0);
	printf("max=%d\n",max);
	l(start);
	return 0;
}
void insert(stud **start,int d)
{
	if((*start)==NULL)
	{
		(*start)=(stud*)malloc(sizeof(stud));
		(*start)->next=NULL;
		(*start)->pre=NULL;
		(*start)->data=d;
		return;
	}
	else
	{
		if((*start)->data>d)
			insert(&((*start)->pre),d);
		else
			insert(&((*start)->next),d);
		return;
	}
	return;
}
void print(stud *start)
{
//int i=1;
	if(start!=NULL)
	{
	print(start->pre);
	printf("%d ",start->data);
	print(start->next);
	}
}
void print1(stud* start)
{
	stud *q;
	//stud *point=start;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=start->data;
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	int i=1;
	while(q->next)
	{
		rem=q->next->extra;
		q->next=q->next->next;
		printf("*%d* %d\n",i++,rem->data);
		//free(rem);
		//if(i==3)
		//break;
		if(rem->pre)
		{
			insert1(q,rem->pre);
		//	start=start->pre;
		}
		if(rem->next)
		{
			insert1(q,rem->next);
		//	start=start->next;
		}
		//printf("hello\n");
	}
}
void insert1(stud *start,stud *sample)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=sample->data;
	start->extra=sample;
	start->next=NULL;
}
void  depth(stud *start,int c1)
{
	if(start==NULL)
		return;
	else
	{
		c1++;
		if(c1>max)
			max=c1;
		depth(start->pre,c1);
		depth(start->next,c1);
	}
}

	
void l(stud *start)
{
	stud *q;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->extra=start;
	q->next->next=NULL;
	stud *rem;
	while(q->next)
	{
		rem=q->next->extra;
		q->next=q->next->next;
		printf("%d ",rem->data);
		if(rem->pre)
			insert2(q,rem->pre);
		if(rem->next)
			insert2(q,rem->next);
	}
}
void insert2(stud *q,stud *start)
{
	while(q->next)
		q=q->next;
	q->next=(stud *)malloc(sizeof(stud));
	q=q->next;
	q->extra=start;
	q->next=NULL;
}

