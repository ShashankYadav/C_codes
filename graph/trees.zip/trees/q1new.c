#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
	struct student *extra;
}stud;
void insert(stud **,int);
void pre(stud *,int);
int depth;
stud *q;
stud *copy;
void call(stud *,int);
void qinsert(stud *,int,int);
void qprint();
void maxdepth(stud *,int);
int max=0;
int main()
{
	int var1,var2;
	scanf("%d",&var2);
	for(var1=0;var1<var2;var1++)
	{
		if(var1==0)
		{
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
		}
	copy=q;
	int n;
	scanf("%d",&n);
	int i,j,var;
	stud *start;
	start=(stud*)malloc(sizeof(stud*));
	start=NULL;
	
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	scanf("%d",&depth);
	maxdepth(start,0);
	call(start,1);
	printf("\n");
	}
	return 0;
}
void maxdepth(stud *start,int c1)
{
	if(start)
	{
		c1++;
		if(c1>max)
			max=c1;
		maxdepth(start->pre,c1);
		maxdepth(start->next,c1);
	}
}

void insert(stud **start,int d)
{
	if((*start)==NULL)
	{
		(*start)=(stud*)malloc(sizeof(stud));
		(*start)->next=NULL;
		(*start)->pre=NULL;
		(*start)->data=d;
		return;
	}
	else
	{
		if((*start)->data>d)
			insert(&((*start)->pre),d);
		else
			insert(&((*start)->next),d);
		return;
	}
	return;
}

void call(stud *start,int x)
{
	if(x<=max)
	{
		qinsert(start,x,0);
		q=copy;
		qprint();
		x=x+depth;
		call(start,x);
	}
}
void qinsert(stud *start,int x,int c1)
{
	if(start)
	{
	c1++;
	if(c1==x)
	{
		q->next=(stud*)malloc(sizeof(stud));
		q->next->extra=start;
		q->next->next=NULL;
		q=q->next;
	}
	qinsert(start->pre,x,c1);
	qinsert(start->next,x,c1);
	}
}

void qprint()
{
	stud *temp;
	while(q->next)
	{
		pre(q->next->extra,0);
		temp=q->next;
		q->next=q->next->next;
		free(temp);
	}
}
void pre(stud *start,int c1)
{
	if(start)
	{
		c1++;
		if(c1<=depth)
			printf("%d ",start->data);
		pre(start->pre,c1);
		pre(start->next,c1);
	}
}
	
	


