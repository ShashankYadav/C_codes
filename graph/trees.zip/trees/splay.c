#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
	struct student *par;
}stud;
stud *insert(stud **,int);
void print(stud*);
void all(stud *,int [],int);
void splay(stud *,stud *);
void depth(stud *,int,int);
stud *single1(stud *);
stud *single2(stud *);
stud *double1(stud *);
stud *double2(stud *);
stud *double3(stud *);
stud *double4(stud *);
stud *px;
int gd;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	int var;
	stud *start;
	stud *start1,*start2;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	stud *root,*root1;
	for(i=0;i<n;i++)
	{
		//start2=start1;
		scanf("%d",&var);
		if(i==0)
		{
		start=insert(&start,var);
		root=start;
		root1=start;
		//printf("start1 %d\n",start1->data);
		}
		else
		{
			printf("no inserted=  %d\n",var);
			start=insert(&root,var);
			printf("start = %d\n",start->data);
			printf("start->par = %d\n",start->par->data);
			if(start->par->par)
			printf("start->par->par = %d\n",start->par->par->data);

			//printf("\n");
			//print(start1);
			//printf("\n");
			splay(root,start);
			root=start;
			print(root);
			printf(".......\n");
			all(root,a,0);
			printf(".......\n");
		}
	}
	//printf("start1 %d\n",start1->data);
	print(root);
	printf("\n\n");
	all(root,a,0);
	printf("\n\n");
	print(root1);
	all(root1,a,0);
	return 0;
}
stud *insert(stud **start,int d)
{
	if(*start==NULL)
	{
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=d;
		(*start)->next=NULL;
		(*start)->pre=NULL;
		(*start)->par=px;
		return (*start);
	}
	if((*start)->data>d)
	{
		px=(*start);
		insert(&((*start)->pre),d);
	}

	else
	{
		px=(*start);
		insert(&((*start)->next),d);
	}
}
void print(stud *start)
{
	if(start)
	{
		print(start->pre);
		printf("%d ",start->data);
		print(start->next);
	}
}
void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}
void depth(stud *start,int c1,int d)
{
	if(start)
	{
		c1++;
		depth(start->pre,c1,d);
		if(start->data==d)
			gd=c1;
		depth(start->next,c1,d);
	}
}
void splay(stud *root,stud *start)
{
	printf("splay %d\n",start->data);
	if(start->par)
		printf("splay->par %d\n",start->par->data);
	if(start->par->par)
		printf("splay->par->par %d\n",start->par->par->data);
	depth(root,-1,start->data);
	int dp=gd;
	printf("depth of %d is %d\n",start->data,dp);
	if(dp==1)
	{
		int c[10];
		all(start->par,c,0);
		stud *px;
		px=start->par;
		if(start->data<px->data)
		     px=single1(px);
		else
		     px=single2(px);
		return;
	}
	else if(dp>=2)
	{
		printf("enter\n");
		stud *gx,*px,*x,*ggx;
		x=start;
		px=start->par;
		gx=px->par;
		if(gx->par)
		ggx=gx->par;
		printf("x=%d\n",x->data);
		printf("px=%d\n",px->data);
		printf("gx=%d\n",gx->data);

		if(px->data<gx->data)
		{
			if(x->data<px->data)
			{
			//	printf("hi\n");
				gx=double1(gx);
				gx->par=ggx;
				ggx->pre=gx;
				int b[10];
				all(gx,b,0);
				printf("\n");
				all(root,b,0);
				print(root);
				splay(root,gx);
			}
			else
			{
				printf("hi2\n");
				gx=double2(gx);
				splay(root,gx);
			}
		}
		else
		{
			if(x->data<px->data)
			{
				gx=double3(gx);
				splay(root,gx);
			}
			else
			{
				gx=double4(gx);
				splay(root,gx);
			}
		}
	}
}


stud *single1(stud *start)
{
	stud *px,*x;
	px=start;
	x=start->pre;
	px->pre=x->next;
	x->next=px;
	px->par=x;
	if(px->pre)
	px->pre->par=px;
	if(px->next)
	px->next->par=px;
	return x;
}
stud *single2(stud *start)
{
	stud *px,*x;
	px=start;
	printf("px= %d\n",px->data);
	x=px->next;
	printf("x= %d\n",x->data);
	px->next=x->pre;
	x->pre=px;
	px->par=x;
	if(px->pre)
	px->pre->par=px;
	if(px->next)
	px->next->par=px;
	printf("hello\n");
	return x;
}
stud *double1(stud *start)
{
	stud *gx,*px,*x;
	gx=start;
	px=start->pre;
	x=px->pre;
	px->pre=x->next;
	gx->pre=px->next;
	px->next=gx;
	x->next=px;
	gx->par=px;
	px->par=x;
	if(gx->pre)
		gx->pre->par=gx;
	if(gx->next)
		gx->next->par=gx;
	if(px->pre)
		px->pre->par=px;
	if(x->pre)
		x->pre->par=x;
	return x;
}
stud *double4(stud *start)
{
	stud *gx,*px,*x;
	gx=start;
	px=start->next;
	x=px->next;
	px->next=x->pre;
	gx->next=px->pre;
	px->pre=gx;
	x->pre=px;
	gx->par=px;
	px->par=x;
	if(gx->pre)
		gx->pre->par=gx;
	if(gx->next)
		gx->next->par=gx;
	if(px->next)
		px->next->par=px;
	if(x->next)
		x->next->par=x;

	return x;
}
stud *double2(stud *start)
{
	stud *gx,*px,*x;
	gx=start;
	px=start->pre;
	x=px->next;
	px->next=x->pre;
	gx->pre=x->next;
	x->pre=px;
	x->next=gx;
	px->par=x;
	gx->par=x;
	if(gx->pre)
		gx->pre->par=gx;
	if(gx->next)
		gx->next->par=gx;
	if(px->next)
		px->next->par=px;
	if(px->pre)
		px->pre->par=x;


	return x;
}

stud *double3(stud *start)
{
	stud *gx,*px,*x;
	gx=start;
	px=start->next;
	x=px->pre;
	px->pre=x->next;
	gx->next=x->pre;
	x->next=px;
	x->pre=gx;
	px->par=x;
	gx->par=x;
	if(gx->pre)
		gx->pre->par=gx;
	if(gx->next)
		gx->next->par=gx;
	if(px->next)
		px->next->par=px;
	if(px->pre)
		px->pre->par=x;

	return x;
}








