#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
int c1=0;
void insert(stud **,int);
void print(stud*);
void max(stud*,int);
void sum(stud *,int);
int size(stud *);
int max1(stud *);
int has(stud *,int);
void dob(stud *start);
void all(stud *,int [],int);
//int x=0;
void preprint(stud *start,int);
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	int var;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&var);
		insert(&start,var);
	}
	print(start);
	printf("******\n");
	all(start,a,0);
	printf("******\n");
	printf("\n");
	int num;
	printf("\n^^");
	preprint(start,0);
	printf("^^\n");



	max(start,0);
	printf("%d\n",c1);
	sum(start,0);
	printf("\n size = %d\n",size(start));
	printf("maxx=%d\n",max1(start));
	int r;
	scanf("%d",&r);
	printf("%d\n",has(start,r));
	dob(start);
	print(start);
	all(start,a,0);
	
	return 0;
}
void insert(stud **start,int d)
{
	if(*start==NULL)
	{
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=d;
		(*start)->next=NULL;
		(*start)->pre=NULL;
		return;
	}
	if((*start)->data>d)
		insert(&((*start)->pre),d);
	else
		insert(&((*start)->next),d);
	return;
}
void print(stud *start)
{
	if(start)
	{
		print(start->pre);
		printf("%d ",start->data);
		print(start->next);
	}
}
void max(stud *start,int c)
{
	if(start)
	{
		c++;
		if(start->pre==NULL && c>c1)
			c1=c;
		max(start->pre,c);
		max(start->next,c);
	}
	//return c1;
}

void sum(stud *start,int x)
{
	if(start)
	{
		x=x+start->data;
		if(start->pre==NULL && start->next==NULL)
			printf("x = %d\n",x);
		sum(start->pre,x);
		sum(start->next,x);
	}
}
int size(stud *start)
{
	if(start==NULL)
		return 0;
	else
		return size(start->pre)+1+size(start->next);
}
int max1(stud *start)
{
	if(start==NULL)
		return 0;
	else
	{
		int l=max1(start->pre);
		if(start->pre)
		printf("\n...pre %d....%d...\n",start->pre->data,l);
		int r=max1(start->next);
		if(start->next)
		printf("\n...next %d....%d...\n",start->next->data,r);
		if(l>r)
			return l+1;
		else
			return r+1;
	}
}
int has(stud *start,int sum)
{
	if(start==NULL)
	{
	//	return;
		return(sum==0);
	}
	else
	{
		int sub=sum-start->data;
		return(has(start->pre,sub)||has(start->next,sub));
	}
}
void dob(stud *start)
{
	if(start==NULL)
		return;
	else
	{
		dob(start->pre);
		stud *temp;
		temp=(stud*)malloc(sizeof(stud));
		temp->data=start->data;
		stud *temp1;
		temp1=start->pre;
		start->pre=temp;
		temp->pre=temp1;
		dob(start->next);
	}
}
void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}
void preprint(stud *start,int c2)
{
	if(start==NULL)
		return;
	else
	{
		c2++;
		preprint(start->pre,c2);
		if(c2<=3)
		printf("%d ",start->data);
		preprint(start->next,c2);
	}
}







