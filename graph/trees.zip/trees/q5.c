#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
	int data;
	struct student *next;
	struct student *pre;
}stud;
void insert(stud **,int [],int,int);
void preprint(stud*);
void postprint(stud*);
void all(stud *,int [],int);
int findmin(int [],int,int);
int main()
{
	int var1,var2;
	scanf("%d",&var2);
	for(var1=0;var1<var2;var1++)
	{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n];
	int var;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start=NULL;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	insert(&start,a,0,n-1);
	//printf("\n");
	preprint(start);
	printf("\n");
	postprint(start);
	printf("\n");

	//all(start,a,0);
	}
	
	return 0;
}
void insert(stud **start,int a[],int p,int q)
{
	if(p<=q && *start==NULL)
	{
		int idx=findmin(a,p,q);
		int min=a[idx];
		*start=(stud*)malloc(sizeof(stud));
		(*start)->data=min;
		(*start)->next=NULL;
		(*start)->pre=NULL;

	insert(&((*start)->pre),a,p,idx-1);
	insert(&((*start)->next),a,idx+1,q);
	}
}


void preprint(stud *start)
{
	if(start)
	{
		printf("%d ",start->data);
		preprint(start->pre);
		preprint(start->next);
	}
}
void postprint(stud *start)
{
	if(start)
	{
		postprint(start->pre);
		postprint(start->next);
		printf("%d ",start->data);
	}       
}   


void all(stud *start,int a[],int i)
{
	if(start==NULL)
		return;
	else
	{
		a[i++]=start->data;
		all(start->pre,a,i);
		if(start->pre==NULL && start->next==NULL)
		{
		int k;
		for(k=0;k<i;k++)
			printf("%d ",a[k]);
		printf("\n");
		}
		all(start->next,a,i);
	}
}

int findmin(int a[],int p,int q)
{
	int i,min=99999,minidx;
	for(i=p;i<=q;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			minidx=i;
		}
	}
	return minidx;
}







