#include<stdio.h>

int main()
{
	int i,j,x,a[1000][1000],que[1000];
	int z,y,u,m,n,st=0,sq=0,b[1000];
	int d[1000];
	scanf("%d",&x);
	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++)
		{
			scanf("%d",&a[i][j]);
		}
		b[i]=0;
		d[i]=0;
	}
	scanf("%d",&n);
	que[st]=n-1;st++;
	b[n-1]=1;
	while(sq<x){
		m=que[sq];
	printf("%d %d\n",m+1,d[m]);
		sq++;
		for(i=0;i<x;i++)
		{
			if(a[m][i]==1&&b[i]==0)
			{
				que[st]=i;
				d[i]=d[m]+1;
				st++;
				b[i]=1;
			}
		}
	
	}
	
}
