#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct data{
	int ver;
	int known;
	int des;
	int pre;
	struct data *next;
};
typedef struct data da;
/*int global;
da* insert(da *st,int m)
{
	da *temp,*odd=st;
	temp=(da*)malloc(sizeof(da));
	temp->ver=m;
	temp->next=NULL;
	if(st==NULL)
	{
		st=temp;
		return st;
	}
	else
	{
		while(st->next)
			st=st->next;
		st->next=temp;
	}
	return odd;
}
da* delete(da *st)
{
	global=st->ver;
	st=st->next;
	return st;
}*/
int main()
{
	int i,m,j,e1,n,e2,le,src;
	int min,m1;
	scanf("%d",&m);
	da st[m],*qu;
	qu=NULL;
	int grap[m][m],dis[m][m];
	for(i=0;i<m;i++)
		for(j=0;j<m;j++)
			grap[i][j]=0;

	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d%d%d",&e1,&e2,&le);
		grap[e1][e2]=le;
	}
	for(i=0;i<m;i++)
	{
	st[i].des=9999;
	st[i].pre=9999;
	st[i].known=0;
	st[i].ver=i;
	}
	scanf("%d",&src);
	st[src].des=0;
	st[src].pre=99;
	st[src].known=1;
	st[src].ver=src;
	int src1=src;
	for(i=0;;i++)
	{
	for(j=0;j<m;j++)
	{
		if(grap[src][j]>0&&(grap[src][j]+st[src].des)<st[j].des&&st[j].known!=1)
		{
			st[j].des=st[src].des+grap[src][j];
			st[j].pre=st[src].ver;
			st[j].ver=j;
			st[j].known=0;
		
		}

	
	}
	min=999,m1=-1;
	for(j=0;j<m;j++)
	{
	
		if(st[j].known!=1&&st[j].des<min)
		{

			min=st[j].des;
			m1=j;
		}
	}
	if (m1==-1)
		break;
	st[m1].known=1;
	src=m1;
	}
	for(i=0;i<m;i++)
	{
		printf("ver=%d pre=%d dis=%d known=%d\n",st[i].ver,st[i].pre,st[i].des,st[i].known);
	}
}
