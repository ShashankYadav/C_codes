#include<stdio.h>
#include<stdlib.h>
void insert(int a[],int n,int k)
{
	int i,j;
	a[k+1]=n;
	i=k+1;
	int fl=0,par;
	while(i!=1&&fl!=1)
	{
		par=i/2;
		if(a[par]>a[i])
		{
			j=a[par];
			a[par]=a[i];
			a[i]=j;
			i=par;
		}
		else
			fl=1;
	}
}
int mini(int a[],int i)
{
	if(a[2*i]>a[(2*i)+1])
		return (2*i)+1;
	else
		return 2*i;
}
void shdo(int a[],int m)
{
	int min,i=1,j;
	while(i<=m/2&&(a[i]>a[2*i]||a[i]>a[(2*i)+1]))
	{
		min=mini(a,i);
		j=a[min];
		a[min]=a[i];
		a[i]=j;
		i=min;
	}
}

int delmin(int a[],int m)
{
	int min=a[1];
	a[1]=a[m];
		m--;
	shdo(a,m);
	return min;
}

int main()
{
	int a[1000];
	int m,i,j,n;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	{
		scanf("%d",&n);
		insert(a,n,i);
	}
	delmin(a,m);
	for(i=0;i<m-1;i++)
	{
		printf("%d\n",a[i+1]);
	}
	
}
