#include<stdio.h>
#include<stdlib.h>
int a[1000][1000]={{0}},d[1000]={0},n,pre[1000]={0};
void dfs(int i)
{
	int j,k,l;
	d[i]=1;
	for(j=0;j<n;j++)
	{
		if(a[i][j]==1&&d[j]==0)
		{
			pre[j]=i;
			dfs(j);
		}
	}
	printf("%d %d\n",pre[i]+1,i+1);
}

int main()
{
	int i,j,k,l;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
		d[i]=0;
		pre[i]=-1;
	}
	pre[0]=-2;
	dfs(0);
}
