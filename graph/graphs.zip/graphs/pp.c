#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int k1,m1,n1,wt;
	scanf("%d",&k1);
	for(i=0;i<k1;i++)
	{
		scanf("%d %d %d",&m1,&n1,&wt);
		a[m1][n1]=wt;
		a[n1][m1]=wt;
	}
	int flag[n+1];
	for(i=0;i<=n;i++)
		flag[i]=0;
	int s=2;
	int d[n+1];
	for(i=0;i<=n;i++)
		d[i]=99;
	d[s]=0;
	int k=0;
        int set[n+1];
	int min=99,minv;
	for(i=1;i<=n;i++)
	{
		min=99;
		for(j=1;j<=n;j++)
		{
			if(d[j]<min && flag[j]==0)
			{
				min=d[j];
				minv=j;
			}
		}
		set[k++]=j;
		flag[minv]=1;
		printf("min = %d\n",minv);
		for(j=1;j<=n;j++)
		{
			if(a[minv][j]!=0 && flag[j]==0)
			{
				if(d[j]>d[minv]+a[minv][j])
					d[j]=d[minv]+a[minv][j];
			}
		//	printf("d[j] is %d\n",d[j]);
		}
	}
	for(i=1;i<=n;i++)
		printf("%d = %d\n",i,d[i]);
	return 0;
}


