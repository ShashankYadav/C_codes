#include<stdio.h>
typedef struct student{
	int data[100];
	int len;
}stud;
int x,y;
int z=0;
int glen=0;
int n;
int num[100];
int jj=0;
int lt=0;
stud arr[50];
void dfs(int [][n+1],int,int,int,int,int [],int [],int []);
int main()
{
	int t1,t2;
	scanf("%d",&t2);
	for(t1=0;t1<t2;t1++)
	{
	//int n;
	scanf("%d",&n);
	int a[n+1][n+1];
	int i,j;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	//int m1,n1;
	int edge;
	int tot,cases;
	//scanf("%d",&edge);
	//printf("enter u and v:\n");
	scanf("%d",&cases);
	int h=0;
	for(h=0;h<cases;h++)
	{
		glen=0;
		lt=0;
		z=0;
	scanf("%d %d %d",&x,&y,&tot);
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;
	int pt=1;
	int store[n+1];
	store[0]=x;

	dfs(a,0,1,n,x,p,state,store);
	if (glen==0)
		printf("-1\n");

//	for(i=1;i<=n;i++)
//		printf("parent of %d is %d\n",i,p[i]);
	int id,min;
	stud temp;
	int aj,oj;
/*	for(aj=0;aj<lt;aj++)
	{
		for(oj=0;oj<arr[aj].len;oj++)
			printf("%d ",arr[aj].data[oj]);
		printf("\n");
	}*/
	for(i=0;i<lt;i++)
	{
		id=i;
		min=arr[i].len;
		for(j=i+1;j<lt;j++)
		{
			if(arr[j].len<min)
			{
				min=arr[j].len;
	                   	id=j;
			}
		}
		temp=arr[i];
		arr[i]=arr[id];
		arr[id]=temp;
	}
//	int aj,oj;
	for(aj=0;aj<lt && aj<tot;aj++)
	{
		for(oj=0;oj<arr[aj].len-1;oj++)
			printf("%d ",arr[aj].data[oj]);
		printf("%d\n",arr[aj].data[oj]);
	}
		
	//int a1,b,c=0;
	}
	}
	return 0;
}


void dfs(int a[][n+1],int flag,int pt,int n,int v,int p[],int state[],int store[])
{
	int i=0;
	int flag1=flag;
	for(i=1;i<=n;i++)
	{
		//printf("flag= %d\n",flag);
		if (flag==flag1)
		{
		//	printf("hello\n");
		int f=0;
		for(f=0;f<=n;f++)
			state[f]=0;
		}
		if(a[v][i]==1)
		{
			//printf("i= %d\n",i);
			//printf("a[v][i] is %d %d\n",v,i);
			//printf("state = %d\n",state[i]);
			if(state[i]==0)
			{

				state[i]=1;
				store[pt]=i;
				p[i]=v;
				if (i==y)
				{
					int k;
				//	for(k=0;k<=pt;k++)
				//		printf("%d ",store[k]);
					for(k=0;k<=pt;k++)
						arr[lt].data[k]=store[k];
					arr[lt].len=pt+1;
				//	for(k=0;k<=pt;k++)
				//		printf("%d ",arr[lt].data[k]);
					lt++;
					glen=pt;
				//	printf("\n");
					state[i]=0;
					//return;
				}
				//flag++;
				dfs(a,flag+1,pt+1,n,i,p,state,store);
			}
		}
	}
}


