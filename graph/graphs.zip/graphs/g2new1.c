#include<stdio.h>
void dfs(int,int,int []);
int state[1000];
int color[1000];
int a[1000][1000];
int flag=0;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);

	int m1,n1;
	int edge;
	//scanf("%d",&edge);
	int p[n];
//	int color[n+1];
	for(i=0;i<n;i++)
		color[i]=0;
	for (i=0;i<n;i++)
		p[i]=0;
//	int state[n+1];
	for(i=0;i<n;i++)
		state[i]=0;
        state[0]=1;
	color[0]=1;
//	for(i=1;i<=n;i++)
//	{
		dfs(n,0,p);
//	}
//
	//for(i=1;i<=n;i++)
	//	printf("parent of %d is %d\n",i,p[i]);
	int p1[1000];
	int q1[1000];
	int h=0,k=0;
	for(i=0;i<n;i++)
	{
		if(color[i]==1)
			p1[h++]=i+1;
		else
			q1[k++]=i+1;
	}
	if (flag==0)
	{
		printf("YES\n");
		if(p1[0]<q1[0])
		{
		for(i=0;i<h-1;i++)
			printf("%d ",p1[i]);
		printf("%d \n",p1[h-1]);
		for(i=0;i<k-1;i++)
			printf("%d ",q1[i]);
		printf("%d \n",q1[k-1]);
		}
		else
		{
		for(i=0;i<k-1;i++)
			printf("%d ",q1[i]);
		printf("%d\n",q1[k-1]);
		for(i=0;i<h-1;i++)
			printf("%d ",p1[i]);
		printf("%d\n",p1[h-1]);
		}

	}
	else
		printf("NO\n");
	return 0;
}


void dfs(int n,int v,int p[])
{
	int i=0;
	for(i=0;i<n;i++)
	{
		//color[v]=1;
		if(a[v][i]==1 && v!=i)
		{
			if(state[i]==0)
			{
				if (color[v]==1)
				        color[i]=2;
				else
					color[i]=1;
				state[i]=1;
				p[i]=v;
				dfs(n,i,p);
			}
			else if(color[v]==color[i])
			{
				flag=1;
				return;
			}
		}
	}
}


