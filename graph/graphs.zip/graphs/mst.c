#include<stdio.h>
int delete(int [],int []);
int num;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int k1,m1,n1,wt,k;
	scanf("%d",&k1);
	for(i=0;i<k1;i++)
	{
		scanf("%d %d %d",&m1,&n1,&wt);
		a[m1][n1]=wt;
		a[n1][m1]=wt;
	}
	int key[n+1];
	for(i=0;i<=n;i++)
		key[i]=99;
	key[1]=0;
	int heap[n+1];
	heap[1]=1;
	int parent;
	int b[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			b[i][j]=0;
	num=n;
	for(i=2;i<=n;i++)
	{
		int flag=0;
		heap[i]=i;
		k=i;
		while(k!=1 && flag==0)
		{
			parent=k/2;
			if(key[heap[parent]]>key[heap[k]])
			{
				int temp;
				temp=heap[parent];
				heap[parent]=heap[k];
				heap[k]=temp;
				parent=k;
			}
			else
				flag=1;
		}
	}
	printf("%d\n",heap[1]);
	int x=0,min;
	for(x=0;x<n;x++)
	{
		min=delete(heap,key);

	}
        return 0;
}

int delete(int heap[],int key[])
{
	int x=heap[1];
	heap[1]=heap[num];
	num=num-1;
	i=1;
	int min;
	int flag=0;
	while(i<=num/2)
	{
		if((flag==0)&&(key[heap[i]]>key[heap[2*i]]||key[heap[i]]>key[heap[2*i+1]]))
		{
			int temp;
			if(key[heap[2*i]]>key[heap[2*i+1]])
				min=2*i+1;
			else
				min=2*i;
			temp=heap[min];
			heap[min]=heap[i];
			heap[i]=temp;
			i=min;
		}
		else
			flag=1;
	}
}















