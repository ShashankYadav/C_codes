#include<stdio.h>
void dfs(int,int,int []);
int a[20][20];
int state[20];
int color[20];
int flag=0;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m1,n1;
	int edge;
	scanf("%d",&edge);
	for(i=0;i<edge;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
		a[n1][m1]=1;
	}
	int p[n+1];
//	int color[n+1];
	for(i=0;i<=n;i++)
		color[i]=0;
	for (i=0;i<=n;i++)
		p[i]=0;
//	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;
        state[1]=1;
	color[1]=1;
//	for(i=1;i<=n;i++)
//	{
		dfs(n,1,p);
//	}
//
	//for(i=1;i<=n;i++)
	//	printf("parent of %d is %d\n",i,p[i]);
	if (flag==0)
	{
		for(i=1;i<=n;i++)
		{
			printf("color of %d is %d\n",i,color[i]);
		}
	}
	else
		printf("Not a bipartite\n");
	return 0;
}


void dfs(int n,int v,int p[])
{
	int i=0;
	for(i=1;i<=n;i++)
	{
		//color[v]=1;
		if(a[v][i]==1)
		{
			if(state[i]==0)
			{
				if (color[v]==1)
				        color[i]=2;
				else
					color[i]=1;
				state[i]=1;
				p[i]=v;
				dfs(n,i,p);
			}
			else if(color[v]==color[i])
			{
				flag=1;
				return;
			}
		}
	}
}


