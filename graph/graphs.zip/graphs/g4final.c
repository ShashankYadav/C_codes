#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	int ht;
	struct student *next;
}stud;
void insert(stud *,int);
int main()
{
	stud *q;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	stud *start=q;
	int n;
	scanf("%d",&n);
	int a[n][n];
	int i,j;
	int m1,n1;
	int k;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;

	int pi[n];
	for(i=0;i<n;i++)
		pi[i]=0;
	int d[n];
	for(i=0;i<n;i++)
		d[i]=0;
	int s=2;
	int count=0;
	int max=0;
	for(s=0;s<n;s++)
	{
		for(i=0;i<n;i++)
			state[i]=0;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=s;
	q->next->next=NULL;
	int v;
	count=0;
	state[s]=1;
	while(q->next)
	{
		v=q->next->data;
		q->next=q->next->next;
		for(j=0;j<n;j++)
		{
			if(a[v][j]==1)
			{
				if(state[j]==0)
				{
					state[j]=1;
					d[j]=d[v]+1;
					pi[j]=v;
					insert(q,j);
				}
			}
		//	state[v]=2;
		//	count++;
		}
		state[v]=2;
		count++;
	}
	if(count>max)
		max=count;
	//printf("count = %d\n",count);
	}
	printf("%d\n",max);
/*	for(i=1;i<=n;i++)
	{
		printf("pi of %d is %d\n",i,pi[i]);
		printf("d= %d\n",d[i]);
	}
	*/
	return 0;
}
void insert(stud *start,int d)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start->next->data=d;
	start->next->next=NULL;
}
