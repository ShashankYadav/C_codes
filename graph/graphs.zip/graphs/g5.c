#include<stdio.h>
void dfs(int,int,int,int,int [],int [],int []);
int a[20][20];
int x,y;
int z;
int num[20];
int jj=0;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m1,n1;
	int edge;
	scanf("%d",&edge);
	for(i=0;i<edge;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
	}
	printf("enter u and v:\n");
	scanf("%d %d",&x,&y);
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;
	int pt=1;
	int store[20];
	store[0]=x;

	dfs(0,1,n,x,p,state,store);

	for(i=1;i<=n;i++)
		printf("parent of %d is %d\n",i,p[i]);
	return 0;
}


void dfs(int flag,int pt,int n,int v,int p[],int state[],int store[])
{
	int i=0;
	int flag1=flag;
	for(i=1;i<=n;i++)
	{
		//printf("flag= %d\n",flag);
		if (flag==flag1)
		{
		//	printf("hello\n");
		int f=0;
		for(f=0;f<=n;f++)
		{
			state[f]=0;
			state[v]=1;
		}
		}
		if(a[v][i]==1)
		{
			//printf("i= %d\n",i);
			//printf("a[v][i] is %d %d\n",v,i);
			//printf("state = %d\n",state[i]);
			if(state[i]==0)
			{

				state[i]=1;
				store[pt]=i;
				p[i]=v;
				if (i==y)
				{
					int k;
					for(k=0;k<=pt;k++)
						printf("%d ",store[k]);
					printf("\n");
					state[i]=0;
					//return;
				}
				//flag++;
				dfs(flag+1,pt+1,n,i,p,state,store);
			}
		}
	}
}


