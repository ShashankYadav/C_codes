#include<stdio.h>
void dfs(int,int,int [],int []);
int a[20][20];
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m1,n1;
	int edge;
	scanf("%d",&edge);
	for(i=0;i<edge;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
	}
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;

	for(i=1;i<=n;i++)
	{
		dfs(n,i,p,state);
	}

	for(i=1;i<=n;i++)
		printf("parent of %d is %d\n",i,p[i]);
	return 0;
}


void dfs(int n,int v,int p[],int state[])
{
	int i=0;
	for(i=1;i<=n;i++)
	{
		if(a[v][i]==1)
		{
			if(state[i]==0)
			{
				state[i]=1;
				p[i]=v;
				dfs(n,i,p,state);
			}
		}
	}
}


