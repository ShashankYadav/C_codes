#include<stdio.h>
typedef struct student{
	int id;
	int finish;
}stud;
void dfs(int,int,int [],int []);
int a[20][20];
int time=0;
int d[20];
int f[20];
int max1=1;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m1,n1;
	int edge;
	scanf("%d",&edge);
	for(i=0;i<edge;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
	}
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;

	for(i=1;i<=n;i++)
	{
		dfs(n,i,p,state);
	}
	d[1]=1;

	for(i=1;i<=n;i++)
	{
		printf("parent of %d is %d\n",i,p[i]);
		printf("d[%d] = %d f[%d] = %d\n",i,d[i],i,f[i]);
	}
	stud sort[n+1];
	for (i=0;i<=n;i++)
	{
		sort[i].id=i;
		sort[i].finish=f[i];
	}
	int id1;
	int min,temp,temp1;
	for(i=1;i<=n;i++)
	{
		id1=i;
		min=sort[i].finish;
		for(j=i+1;j<=n;j++)
		{
			if (sort[j].finish<min)
			{
				id1=j;
				min=sort[j].finish;
			}
		}
		temp=sort[id1].id;
		sort[id1].id=sort[i].id;
		sort[i].id=temp;
		sort[id1].finish=sort[i].finish;
		sort[i].finish=min;
	}
	for(i=1;i<=n;i++)
	{
		printf("f %d f[%d] %d\n",sort[i].id,sort[i].id,sort[i].finish);
	}
	int p1[n+1];
	int state1[n+1];
	for(i=0;i<=n;i++)
		state1[i]=0;
	int max=0;

	for(i=1;i<=n;i++)
	{
		dfs(n,sort[i].id,p1,state1);
		printf("max1=%d\n",max1);
	}


	return 0;
}


void dfs(int n,int v,int p[],int state[])
{
	int i=0;
	if (state[v]==0)
		d[v]=++time;
	for(i=1;i<=n;i++)
	{
		if(a[v][i]==1)
		{
			if(state[i]==0)
			{
				max1++;
				d[i]=++time;
				state[i]=1;
				p[i]=v;
			//	f[v]=time++;
				dfs(n,i,p,state);
				f[i]=++time;
			}
		}
	}
	if(state[v]==0)
		f[v]=++time;
}


