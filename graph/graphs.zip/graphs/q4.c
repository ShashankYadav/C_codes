#include<stdio.h>
#include<stdlib.h>
int n;
typedef struct student{
	int data;
	struct student *next;
}stud;
void insert(stud *,int);
int main()
{
	scanf("%d",&n);
	int a[n+1][n+1];
	int b[n+1][n+1];
	int i,j;
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start->data=99;
	start->next=NULL;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			if (j%i==0 && i!=j)
			{
				a[j][i]=1;
				b[j][i]=1;
			}
			else
			{
				b[j][i]=0;
				a[j][i]=0;
			}
		}
/*	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			printf("%d ",a[i][j]);
		printf("\n");
	}*/
	int k;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(a[j][i]==1)
			{
				for(k=1;k<=n;k++)
				{
					if (a[k][j]==1)
					{
						a[k][i]=0;
					}
				}
			}
		}
	}
	printf("\n");
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			printf("%d ",a[i][j]);
		printf("\n");
	}
	int m,c,d;
	scanf("%d",&m);
	int g1[n],g2[n];
	for(k=0;k<m;k++)
	{
		int l1=0;
		int l2=0;
		scanf("%d %d",&c,&d);
		for(i=1;i<=n;i++)
			if(b[c][i]==1)
				g1[l1++]=i;
		g1[l1]=c;
		for(i=1;i<=n;i++)
			if(b[d][i]==1)
				g2[l2++]=i;
		g2[l2]=d;
	/*	for(i=0;i<=l1;i++)
			printf("%d ",g1[i]);
		printf("\n");
		for(i=0;i<=l2;i++)
			printf("%d ",g2[i]);
		printf("\n");*/
		for(i=0;i<=l1;i++)
			for(j=0;j<=l2;j++)
				if(g1[i]==g2[j])
					insert(start,g1[i]);
		while(start->next)
			start=start->next;
		printf("%d\n",start->data);
		start->next=NULL;

	}
	return 0;
}

void insert(stud *start,int d)
{
	while(start->next && start->next->data<d)
		start=start->next;
	stud *temp;
	temp=(stud *)malloc(sizeof(stud));
	temp->data=d;
	temp->next=start->next;
	start->next=temp;
}
