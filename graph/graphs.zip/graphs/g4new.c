#include<stdio.h>
void dfs(int,int,int,int,int,int [],int [],int []);
int a[20][20];
int size=1;
int max=0;
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m1,n1;
	int edge;
	scanf("%d",&edge);
	for(i=0;i<edge;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
	}
	printf("enter u and v:\n");
	//scanf("%d %d",&x,&y);
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;
	int pt=1;
	int store[20];
	int k;
	for(i=1;i<=n;i++)
	{
		store[0]=i;
		for(j=1;j<=n;j++)
		{
	          dfs(i,j,0,1,n,p,state,store);
		  size=1;
		  for(k=0;k<=n;k++)
			  state[i]=0;
		}
	}

	printf("max=%d\n",max);

	//for(i=1;i<=n;i++)
	//	printf("parent of %d is %d\n",i,p[i]);
	return 0;
}


void dfs(int v,int y,int flag,int pt,int n,int p[],int state[],int store[])
{
	int i=0;
	for(i=1;i<=n;i++)
	{
		//printf("flag= %d\n",flag);
		if (flag==0)
		{
		//	printf("hello\n");
		int f=0;
		for(f=0;f<=n;f++)
			state[f]=0;
		}
		if(a[v][i]==1)
		{
			printf("a[v][i] is %d %d\n",v,i);
			if(state[i]==0)
			{

				state[i]=1;
				store[pt]=i;
				p[i]=v;
				size++;
				if (i==y)
				{
					int k;
					for(k=0;k<=pt;k++)
						printf("%d ",store[k]);
					printf("size = %d\n",size);
					if (size>max)
						max=size;
					size=0;
					printf("\n");
					state[i]=0;
					return;
				}
				//flag++;
				dfs(i,y,flag+1,pt+1,n,p,state,store);
			}
		}
	}
}


