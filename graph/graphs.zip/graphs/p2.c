#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
}stud;
void insert(stud *,int);
int main()
{
	int n;
	scanf("%d",&n);
	int d1;
	scanf("%d",&d1);
	int i,j,m1,n1;
	int a[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	for(i=0;i<d1;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
		a[n1][m1]=1;
	}
	int p[n+1],state[n+1],d[n+1];
	for(i=0;i<=n;i++)
	{
		state[i]=0;
		p[i]=0;
		d[i]=0;
	}
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start->next=NULL;
	stud *q=start;
	int s=1,v;
	state[s]=1;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=s;
	start->next=NULL;
	while(q->next)
	{
		v=q->next->data;
		q->next=q->next->next;
		for(i=1;i<=n;i++)
		{
			if(a[v][i]==1 && state[i]==0)
			{
				state[i]=1;
				insert(q,i);
				p[i]=v;
				d[i]=d[v]+1;
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		printf("p[%d] is %d\n",i,p[i]);
		printf("d[%d] is %d\n",i,d[i]);
	}
	return 0;
}
void insert(stud *start,int d)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=d;
	start->next=NULL;
}


