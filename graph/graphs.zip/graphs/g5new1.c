#include<stdio.h>
int x,y;
int z=0;
int n;
int num[100];
int jj=0;
void dfs(int [][n+1],int,int,int,int,int [],int [],int []);
//int a[10000][10000];
int main()
{
	//int n;
	scanf("%d",&n);
	int a[n+1][n+1];
	int i,j;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	//int m1,n1;
	int edge;
	int tot,cases;
	//scanf("%d",&edge);
	//printf("enter u and v:\n");
	scanf("%d",&cases);
	int h=0;
	for(h=0;h<cases;h++)
	{
		jj=0;
		z=0;
	scanf("%d %d %d",&x,&y,&tot);
	int p[n+1];
	for (i=0;i<=n;i++)
		p[i]=0;
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;
	int pt=1;
	int store[n+1];
	store[0]=x;

	dfs(a,0,1,n,x,p,state,store);
	if (jj==0)
		printf("-1\n");

//	for(i=1;i<=n;i++)
//		printf("parent of %d is %d\n",i,p[i]);
	int id,min=999,temp;
	for(i=0;i<jj;i++)
	{
		id=i;
		min=num[id];
		for(j=i+1;j<jj;j++)
		{
			if(num[j]<min)
			{
				min=num[j];
	                   	id=j;
			}
		}
		temp=num[i];
		num[id]=temp;
		num[i]=min;
	}
	int a1,b,c=0;
	for(i=0;i<tot && i<jj;i++)
	{
		//printf("x=%d\n",x);
		int x=num[i];
		while(x>0)
		{
			b=x%10;
			x=x/10;
			c=c*10+b;
		}
		while (c>0)
		{
			printf("%d ",c%10);
			c=c/10;
		}
		if(jj!=0)
		printf("\n");
	}
	}
	return 0;
}


void dfs(int a[][n+1],int flag,int pt,int n,int v,int p[],int state[],int store[])
{
	int i=0;
	int flag1=flag;
	for(i=1;i<=n;i++)
	{
		//printf("flag= %d\n",flag);
		if (flag==flag1)
		{
		//	printf("hello\n");
		int f=0;
		for(f=0;f<=n;f++)
			state[f]=0;
		}
		if(a[v][i]==1)
		{
			//printf("i= %d\n",i);
			//printf("a[v][i] is %d %d\n",v,i);
			//printf("state = %d\n",state[i]);
			if(state[i]==0)
			{

				state[i]=1;
				store[pt]=i;
				p[i]=v;
				if (i==y)
				{
					int k;
					for(k=pt;k>=0;k--)
					{
						z=z*10+store[k];
						//printf("%d ",store[k]);
					}
					int b=0,c=0;
					while(z>0)
					{
						b=z%10;
						z=z/10;
						c=c*10+b;
					}
					num[jj++]=c;
					z=0;
					//printf("\n");
					state[i]=0;
					//return;
				}
				//flag++;
				dfs(a,flag+1,pt+1,n,i,p,state,store);
			}
		}
	}
}


