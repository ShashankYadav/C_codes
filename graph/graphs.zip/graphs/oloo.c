#include<stdio.h>
int n;
int time=0;
int fg=0;
void visit_dfs(int [],int,int [][n+1],int,int [],int [],int [],int []);
int main()
{
int b1[n+1];
	scanf("%d",&n);
	printf("n=%d\n",n);
	int a[n+1][n+1];
	int d1;
	scanf("%d",&d1);
	int i,j,m1,n1;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	for(i=0;i<d1;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=1;
		a[n1][m1]=1;
	}
	int p[n+1],state[n+1],d[n+1],f[n+1];
	for(i=0;i<=n;i++)
	{
		p[i]=0;
		state[i]=0;
		d[i]=0;
		f[i]=0;
	}

	state[1]=1;
	//for(i=1;i<=n && state[i]==0;i++)
		visit_dfs(b1,1,a,1,p,state,d,f);
/*	for(i=1;i<n+1;i++)
	{
		printf("p[%d] is %d\n",i,p[i]);
		printf("d[%d] is %d\n",i,d[i]);
		printf("f[%d] is %d\n",i,f[i]);
	}*/
	return 0;
}/*
void visit_dfs(int a[][n+1],int v,int p[],int state[],int d[],int f[])
{
	int i;
	d[v]=++time;
	for(i=1;i<=n;i++)
	{
		if (a[v][i]==1 && state[i]==0)
		{
			p[i]=v;
			state[i]=1;
			visit_dfs(a,i,p,state,d,f);
		}
	}
	f[v]=++time;
}
*/
void visit_dfs(int b1[],int k,int a[][n+1],int v,int p[],int state[],int d[],int f[])
{
	int i,j;
	int flag=0;
	for(i=1;i<k;i++)
	{
		if(b1[i]==v)
		{
			flag=1;
			if(k>3 && i<k-2)
			{
				printf("cycle\n");
			}
			else
				return;
		}
	}



	if(flag==0)
		b1[k++]=v;
	for(i=1;i<=n;i++)
		if(a[v][i]==1)
			visit_dfs(b1,k,a,i,p,state,d,f);


/*	int i,j,flag=1;
	for(i=0;i<c;i++)
	{
		if(path[i]==s)
		{
			flag=0;
			if(c>=3 && i<c-2)
			{
				printf("cycle");
				for(j to i)
					print...
			}
			else
				return;
		}
	}
	if(flag==1)
		path[c++]=s;
	for(i=1;i<=n;i++)
		if(a[s][i]==1)
			dfs(...);
*/
}

