#include<stdio.h>
int n;
int flag=0;
void visit_dfs(int a[][n+1],int,int [],int);
int main()
{
	scanf("%d",&n);
	int d1;
	scanf("%d",&d1);
	int i,j,m1,n1,wt;
	int edge[n*n];
	int e1[n*n],e2[n*n];
	int k=0;
	for(i=0;i<d1;i++)
	{
		scanf("%d %d %d",&m1,&n1,&wt);
		edge[k]=wt;
		e1[k]=m1;
		e2[k++]=n1;
	}
	int min,minid;
	for(i=0;i<k;i++)
	{
		min=edge[i];
		minid=i;
		for(j=i+1;j<k;j++)
		{
			if(edge[j]<min)
			{
				min=edge[j];
				minid=j;
			}
		}
	        int temp=edge[i];
		edge[i]=edge[minid];
		edge[minid]=temp;
		temp=e1[i];
		e1[i]=e1[minid];
		e1[minid]=temp;
		temp=e2[i];
		e2[i]=e2[minid];
		e2[minid]=temp;
	}
	for(i=0;i<k;i++)
	{
		printf("%d ",e1[i]);
		printf("%d ",e2[i]);
		printf("%d\n",edge[i]);
	}
	int a[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int z=1;
	int x=0;
	int y=0;
	int v=e1[0];
	int state[n+1];

	while(y<k)
	{
	for(i=0;i<=n;i++)
		state[i]=0;
	state[e1[0]]=1;
	y++;
	flag=0;
	a[e1[x]][e2[x]]=1;
	a[e2[x]][e1[x]]=1;;
	visit_dfs(a,v,state,99);
	printf("break\n");
	if (flag==1)
	{
		printf("e1 is %d e2 is %d wt is %d\n",e1[x],e2[x],edge[x]);
	a[e1[x]][e2[x]]=0;
	a[e2[x]][e1[x]]=0;
	}
	else
		z++;
	x++;
	}
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			if(a[i][j]==1)
				printf("edge is %d %d\n",i,j);
	return 0;
}
		

void visit_dfs(int a[][n+1],int v,int state[],int prev)
{
	//printf("hello\n");
	int i;
	for(i=1;i<=n;i++)
	{
		if (i!=prev && a[v][i]==1 && state[i]==0)
		{
			printf("v is %d i is %d\n",v,i);
			state[i]=1;
			visit_dfs(a,i,state,v);
		}
		else if (i!=prev && state[i]==1 && a[v][i]==1)
		{
			flag=1;
			return;
		}
	}
}
