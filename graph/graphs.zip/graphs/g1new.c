#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	int ht;
	struct student *next;
}stud;
void insert(stud *,int);
//void insert1(stud *,int);
//void print(stud *);
int main()
{
	stud *q;
	q=(stud*)malloc(sizeof(stud));
	q->next=NULL;
	stud *start=q;
	int n;
	scanf("%d",&n);
	int a[n+1][n+1];
	int i,j;
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int m[n+1];
	stud *list;
	list=(stud*)malloc(sizeof(stud));
	list->next=NULL;
	int n1,k=0;
	scanf("%d",&n1);
	for(i=0;i<n1;i++)
	{
		k=0;
		while (1)
		{
			scanf("%d",&m[k]);
			if (m[k]==-1)
				break;
			k++;
		}
		int p,q;
		for(p=0;p<k;p++)
			for(q=0;q<k;q++)
			{
				if(p!=q)
				{
				a[m[p]][m[q]]=1;
		                a[m[q]][m[p]]=1;
				}
			}

	}
	int state[n+1];
	for(i=0;i<=n;i++)
		state[i]=0;

	int pi[n+1];
	for(i=0;i<=n;i++)
		pi[i]=0;
	int d[n+1];
	for(i=0;i<=n;i++)
		d[i]=0;
	int s=1;
	state[s]=1;
	q->next=(stud*)malloc(sizeof(stud));
	q->next->data=s;
	q->next->next=NULL;
	int v;
	while(q->next)
	{
		v=q->next->data;
		q->next=q->next->next;
		for(j=0;j<=n;j++)
		{
			if(a[v][j]==1)
			{
				if(state[j]==0)
				{
					state[j]=1;
					d[j]=d[v]+1;
					pi[j]=v;
					insert(q,j);
				}
			}
			//state[v]=2;
		}
	}
	/*for(i=1;i<=n;i++)
	{
	//	printf("state of %d is %d\n",i,state[i]);
		if(state[i]!=0)
		{
		printf("pi of %d is %d\n",i,pi[i]);
		printf("d= %d\n",d[i]);
		}
	}*/
	int min,minid;
	/*for(i=1;i<=n;i++)
	{
		minid=i;
		min=d[i];
		for(j=i+1;j<=n;j++)
		{
			if (d[j]<min)
			{
				min=d[j];
				minid=j;
			}
		}
		int temp=d[i];
		d[i]=min;
		d[minid]=temp;
	}*/
	for(i=1;i<n;i++)
		printf("%d ",d[i]);
	printf("%d\n",d[n]);
	
	return 0;
}
void insert(stud *start,int d)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start->next->data=d;
	start->next->next=NULL;
}
/*void insert1(stud *start,int d)
{
	while(start->next && start->next->data<d)
		start=start->next;
	int flag=0;
	if(start->next && d!=start->next->data)
	{
		flag=1;
	}
	if(start->next==NULL)
		flag=1;
	if (flag==1)
	{
	stud *temp;
	temp=(stud*)malloc(sizeof(stud));
	temp->data=d;
	temp->next=start->next;
	start->next=temp;
	}
}
void print(stud *start)
{
	while(start->next)
	{
		printf("%d ",start->next->data);
		start=start->next;
	}
}*/


