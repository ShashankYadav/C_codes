#include<stdio.h>
#include<stdlib.h>
typedef struct student{
	int data;
	struct student *next;
}stud;
void insert(stud *,int);
void insert1(stud *,int);
void print(stud*);
int main()
{
	int n;
	scanf("%d",&n);
	int d1;
	//scanf("%d",&d1);
	int i,j,m1,n1;
	int a[n+1][n+1];
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
//	for(i=0;i<d1;i++)
//	{
//		scanf("%d %d",&m1,&n1);
//		a[m1][n1]=1;
//		a[n1][m1]=1;
//	}
	int p[n+1],state[n+1],d[n+1];
	for(i=0;i<=n;i++)
	{
		state[i]=0;
		p[i]=0;
		d[i]=0;
	}
	stud *start;
	start=(stud*)malloc(sizeof(stud));
	start->next=NULL;
	stud *q=start;
	int s=0,v;
	state[s]=1;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=s;
	start->next=NULL;
	stud *list;
	list=(stud *)malloc(sizeof(stud));
	list->data=9999;
	list->next=NULL;
	int count1=0;
	int count=1;
	int level=0;
//	printf("0\n");
	stud *l1;
	int x=0;
	int c[n+1][n+1];
	while(q->next)
	{
		count1=0;
		while(count>0)
		{
		v=q->next->data;
		q->next=q->next->next;
		for(i=0;i<n;i++)
		{
			if(a[v][i]==1 && state[i]==0)
			{
				int y=0;
				l1=list;
				insert1(list,i);
				while(list->next)
				{
					c[x][y]=list->next->data;
					y++;
					list=list->next;
				}
				list=l1;
				c[x][y]=-1;
				state[i]=1;
				insert(q,i);
				p[i]=v;
				d[i]=d[v]+1;
				count1++;
			}
		}
		count--;
		}
		count=count1;
	//	print(list);
		level++;
		x++;
		list->next=NULL;
	}
	printf("%d\n",level);
	printf("0 \n");
	for(i=0;i<x-1;i++)
	{
		for(j=0;j<n;j++)
		{
			if(c[i][j]==-1)
				break;
			printf("%d ",c[i][j]);
		}
		printf("\n");
	}

/*	for(i=0;i<=n;i++)
	{
		printf("p[%d] is %d\n",i,p[i]);
		printf("d[%d] is %d\n",i,d[i]);
	}*/
	return 0;
}
void insert(stud *start,int d)
{
	while(start->next)
		start=start->next;
	start->next=(stud*)malloc(sizeof(stud));
	start=start->next;
	start->data=d;
	start->next=NULL;
}

void print(stud *start)
{
	while (start->next)
	{
		if (start->data!=9999)
		printf("%d ",start->data);
		start=start->next;
	}
	if (start->data!=9999)
	printf("%d\n",start->data);

}

void insert1(stud *start,int d)
{
	while(start->next && start->next->data<d)
		start=start->next;
	stud *temp;
	temp=(stud *)malloc(sizeof(stud));
	temp->data=d;
	temp->next=start->next;
	start->next=temp;
}

