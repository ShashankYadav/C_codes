#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int i,j;
	int a[n+1][n+1];
	for(i=0;i<=n;i++)
		for(j=0;j<=n;j++)
			a[i][j]=0;
	int k,m1,n1,wt;
	scanf("%d",&k);
	for(i=0;i<k;i++)
	{
		scanf("%d %d",&m1,&n1);
		a[m1][n1]=wt;
		a[n1][m1]=wt;
	}
	int s=2;
	int d[n+1];
	for(i=0;i<=n;i++)
		d[i]=-9;
	d[s]=0;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(a[i][j]!=0)
			{
				if (d[j]<d[i]+1)
					d[j]=d[i]+1;
			}
		}
	}
	for(i=1;i<=n;i++)
		printf("%d = %d\n",i,d[i]);
	return 0;
}






































