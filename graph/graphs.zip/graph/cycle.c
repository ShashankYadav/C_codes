#include<stdio.h>
#include<string.h>
int v;
void process(int [],int,int [],int [],int);
void dfs(int [][v+1],int,int,int,int []);
int max=-1;
int main()
{
   scanf("%d",&v);
   int arr[v+1][v+1];
   int i,j;
   for(i=0;i<v+1;i++)
   {
	   for(j=0;j<v+1;j++)
			arr[i][j]=0;
   }
	int e,t1,t2;
	scanf("%d",&e);
	for(i=0;i<e;i++)
	{
		scanf("%d%d",&t1,&t2);
		arr[t1][t2]=1;
		arr[t2][t1]=1;
	}
	int path[100];
	dfs(arr,v,1,0,path);
	return 0;
}
void dfs(int arr[][v+1],int v,int s,int c,int path[])
{
	//printf("num is %d\n",s);
	arr[s][0]=-1;
	int i,j,flag=1;
	for(i=0;i<c;i++)
	{
		if(path[i]==s)
		{
			flag=0;
			if(c>=3 && i<c-2)
			{
				printf("cycle found\n");
				goto label;
			}
			else
				return;
		}
	}
	if(flag==1)
		path[c++]=s;
	for(i=1;i<v+1;i++)
		if(arr[s][i]!=0)
				dfs(arr,v,i,c,path);
	return;	
label:
	for(j=i;j<c;j++)
		printf("%d ",path[j]);
	printf("%d\n",s);
	return;
}
	
		
		
		
		
