#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void process(int [],int,int [],int [],int);
int main()
{
	int v;
	scanf("%d",&v);
	int a[v+1][v+1];
	int i,j,l;
	for(i=0;i<v+1;i++)
	{
		for(j=0;j<v+1;j++)
			a[i][j]=0;
	}
	int e,t1,t2,w;
	scanf("%d",&e);
	for(i=0;i<e;i++)
	{
		scanf("%d%d%d",&t1,&t2,&w);
		a[t1][t2]=w;
		a[t2][t1]=w;
	}
	int s[v+1],d[v+1];
	for(i=1;i<v+1;i++)
	{
		s[i]=0;
		d[i]=999;
	}
	d[1]=0;
	s[1]=1;
	process(a[1],1,d,s,v+1);
	/*for(i=1;i<v+1;i++)
	  {
	  printf("s[%d]=%d\n",i,s[i]);
	  printf("d[%d]=%d\n",i,d[i]);
	  }printf("\n\n");*/
	int k,min,index;
	for(j=2;j<v+1;j++)
	{
		min=999,index=j;
		for(i=1;i<v+1;i++)
		{
			if(d[i]<min)
			{
				if(s[i]==0)
				{min=d[i];
					index=i;}
			}
		}
		if(min==999)
			continue;
		s[index]=1;
		process(a[index],index,d,s,v);
	}
	for(i=1;i<v+1;i++)
	{
		printf("s[%d]=%d ",i,s[i]);
		printf("d[%d]=%d\n",i,d[i]);
	}
	return 0;
}
void process(int a[],int r,int d[],int s[],int v)
{
	printf("min is %d\n",r);
	int i;
	for(i=1;i<v+1;i++)
	{
		if(a[i]!=0)
		{
			if(s[i]==0)
			{
				if(d[i]>d[r]+a[i])
					d[i]=d[r]+a[i];
			}
		}
	}
}
	
