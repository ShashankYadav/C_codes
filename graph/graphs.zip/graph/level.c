#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct nod
{
	int n;
	struct nod* next;
}node;
void process(int [],int,int [],int [],int);
int rem(node *);
void add(node *,int);
void sort(int [],int);
int main()
{
	int v;
	scanf("%d",&v);
	int a[v+1][v+1];
	int i,j,k,l;
	for(i=0;i<v+1;i++)
	{
		for(j=0;j<v+1;j++)
			a[i][j]=0;
	}
	int e,t1,t2,w;
	scanf("%d",&e);
	for(i=0;i<e;i++)
	{
		scanf("%d%d",&t1,&t2);
		a[t1][t2]=1;
		//	a[t2][t1]=1;
	}
	int s[v+1];
	for(i=0;i<v+1;i++)
		s[i]=0;
	node *start;
	start=(node *)malloc(sizeof(node));
	start->next=NULL;
	start->next=(node *)malloc(sizeof(node));
	start->next->n=1;
	s[1]=1;
	//printf("2 added\n");
	int temp,num,count=1,count1=1;
	int arr[50],h=0;
	while(start->next)
	{
		count1=0,h=0;
		while(count>0)
		{
			temp=rem(start);
			arr[h++]=temp;
			//printf("%d removed\n",temp);
			count--;
			for(i=1;i<v+1;i++)
			{
				if(a[temp][i]==1 && s[i]==0)
				{
					add(start,i);
					count1++;
					//printf("%d added\n",i);
					s[i]=1;
				}
			}
		}
		sort(arr,h);
		for(i=0;i<h;i++)
			printf("%d ",arr[i]);
		count=count1;
		printf("\n");
	}
	return 0;
}
int rem(node *start)
{
	int temp=start->next->n;
	node *tmp;
	tmp=start->next;
	start->next=start->next->next;
	free(tmp);
	return temp;
}
void add(node *start,int n)
{
	while(start->next)
		start=start->next;
	start->next=(node *)malloc(sizeof(node));
	start->next->n=n;
	start->next->next=NULL;
}

void sort(int a[],int n)
{
	int i,j,k,index,min;
	for(i=0;i<n;i++)
	{
		min=a[i];
		index=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j]<min)
			{
				min=a[j];
				index=j;
			}
		}
		int temp=a[i];
		a[i]=a[index];
		a[index]=temp;
	}
}






