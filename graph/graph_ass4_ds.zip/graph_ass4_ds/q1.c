#include<stdio.h>
int main()
{
	int x,i,j,k,n,inp,num,top;
	scanf("%d",&n);
	int a[n][n], arr[n],q[n],d[n],v[n],front=0,rear=0;
	scanf("%d",&inp);
	for(i=0;i<n;i++)
	{
		v[i]=0;
		q[i]=0;
		d[i]=1234567;
		for(j=0;j<n;j++)
			a[i][j]=0;
	}
	for(i=0;i<inp;i++)
	{
		//printf("inp number:%d\n",i);
		top=0;
		//while(scanf("%d",&num)!=-1)
		while(1)
		{	
			scanf("%d",&num);
			if(num==-1)
				break;
			//printf("num : %d\n",num);
			arr[top++]=num;
		}
	//	for(j=0;j<top;j++)
	//		printf("%d ",arr[j]);
	//	printf("\n");
		//printf("out of while(1)\n");
		for(j=0;j<top;j++)
		{
			for(k=j+1;k<top;k++)
			{
				a[arr[j]-1][arr[k]-1]=1;
				a[arr[k]-1][arr[j]-1]=1;
			}
		}
	}
	/*for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
			printf("%d ",a[i][j]);
		printf("\n");
	}*/
	x=0;
	//start bfs
	q[rear++]=x;
	v[x]=1;
	d[x]=0;
	int temp;
	while(front!=rear)
	{
		temp=q[front++];
		//printf("node: %d\n",temp);
		for(i=0;i<n;i++)
		{
			if(a[temp][i]==1&&v[i]==0)
			{
				q[rear++]=i;
				v[i]=1;
				d[i]=d[temp]+1;
				//p[i]=temp;
			}
		}
		v[temp]=2;
	}
	for(i=0;i<n-1;i++)
	{
		printf("%d ",d[i]);
	}
	printf("%d\n",d[n-1]);
	return 0;
}
