#include<stdio.h>
int v[10000],color[10000],p[10000],flag=0,n;
void bipart(int a[][n],int n,int num)
{
	if(flag==1)
		return;
	if(color[num]==0)
		color[num]=1;
	v[num]=1;
	int i;
	for(i=0;i<n;i++)
	{
		if(a[num][i]==1&&v[i]==0&&color[i]==0)
		{
			p[i]=num;
			if(color[num]==1)
				color[i]=2;
			else
				color[i]=1;
			bipart(a,n,i);
		}
		else if(a[num][i]==1&&v[i]==1&&color[num]==color[i])
		{
			flag=1;
			return;
		}
	}
	return;
}
int main()
{
	int i,j;
	scanf("%d",&n);
	int a[n][n];
	for(i=0;i<n;i++)
	{
		v[i]=0;
		color[i]=0;
		for(j=0;j<n;j++)
			a[i][j]=0;
	}
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
	for(i=0;i<n;i++)
	{
		if(v[i]==0)
		{
			bipart(a,n,i);
		}
	}
	int c=color[0];
	if(flag==0)
	{
		printf("YES\n");
		for(i=0;i<n;i++)
			if(color[i]==c)
				printf("%d ",i+1);
		printf("\n");
		for(i=0;i<n;i++)
			if(color[i]!=c)
				printf("%d ",i+1);
		printf("\n");
	}
	else
		printf("NO\n");
	return 0;
}
