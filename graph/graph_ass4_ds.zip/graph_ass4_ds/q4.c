#include<stdio.h>
int n,maxlen=-20000,v[10000],time=0;
void visitdfs(int a[][n],int n,int num)
{
	++time;
	//printf("number: %d time : %d\n",num,time);
	if(maxlen<time)
		maxlen=time;
	int i;
	for(i=0;i<n;i++){
		if(v[i]==0&&a[num][i]==1){
			v[i]=1;
			visitdfs(a,n,i);
		}
	}
}
int main()
{
	int i,j;
	scanf("%d",&n);
	int a[n][n];
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		time=0;
		if(v[i]==0)
		{
			v[i]=1;
			visitdfs(a,n,i);
		}
	}
	printf("%d\n",maxlen);
	return 0;
}
