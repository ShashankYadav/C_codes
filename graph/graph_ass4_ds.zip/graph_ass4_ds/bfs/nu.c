#include<stdio.h>
int main()
{
	int i,j,n,x,y;
	char ch;
	scanf("%d",&n);
	int a[n][n],p[n],d[n],q[n],v[n],front=0,rear=0;
	for(i=0;i<n;i++)
	{
		d[i]=1234567;
		v[i]=0;
		for(j=0;j<n;j++)
		{
			a[i][j]=0;
		}
	}
	int wei;
	while(1)
	{
//		printf("enter the edge\n");
		scanf("%d%d%d",&x,&y,&wei);
		scanf("%c",&ch);
		a[x][y]=wei;
//		printf("do u wanna enter another edge: ");
		scanf("%c",&ch);
		if(ch=='n')
		{
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
//	printf("enter source vertex\n");
	scanf("%d",&x);
	//start bfs
	q[rear++]=x;
	v[x]=1;
	d[x]=0;
	p[x]=0;
	int temp,f;
	for(f=0;f<n-1;f++)
	{
		for(j=0;j<n;j++)
		{
			v[j]=0;
			q[j]=0;
		}
		front=0;rear=1;
		q[front]=x;
		v[x]=1;
		while(front!=rear)
		{
			temp=q[front++];
//			printf("node: %d\n",temp);
			for(i=0;i<n;i++)
			{
				if(a[temp][i]!=0)
				{
					q[rear++]=i;
					v[i]=1;
				//	printf("d[i]: %d d[temp]: %d a[i][j]: %d\n",d[i],d[temp],a[temp][i]);
					if(d[i]>d[temp]+a[temp][i])
					{
				//		printf("a[%d][%d]: %d path: %d parent: %d\n",temp,i,a[temp][i],d[i],p[i]); 
						d[i]=d[temp]+a[temp][i];
						p[i]=temp;
					}
				}
			}
			v[temp]=2;
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d : parent= %d dist : %d\n",i,p[i],d[i]);
	}
	return 0;
}
