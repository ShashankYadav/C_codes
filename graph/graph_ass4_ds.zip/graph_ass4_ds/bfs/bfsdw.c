#include<stdio.h>
int main()
{
	int i,j,n,x,y;
	char ch;
	scanf("%d",&n);
	int a[n][n],p[n],d[n],v[n];
	for(i=0;i<n;i++)
	{
		d[i]=1234567;
		v[i]=0;
		for(j=0;j<n;j++)
		{
			a[i][j]=0;
		}
	}
	int wei;
	while(1)
	{
		printf("enter the edge\n");
		scanf("%d%d",&x,&y);
		printf("enter weight:\n");
		scanf("%d",&wei);
		scanf("%c",&ch);
		a[x][y]=wei;
		printf("do u wanna enter another edge: ");
		scanf("%c",&ch);
		if(ch=='n')
		{
			break;
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	printf("enter source vertex\n");
	scanf("%d",&x);
	p[x]=-1;
	for(i=0;i<n;i++)
	{
		if(a[x][i]!=0)
		{
			d[i]=a[x][i];
			p[i]=x;
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{

			if(d[j]>a[i][j]+d[i])
			{
				d[j]=d[i]+a[i][j];
				p[j]=i;
			}

		}
	}
	for(i=0;i<n;i++)
	{
		printf("node: %d shortest path: %d parent: %d\n",i,d[i],p[i]);
	}
	return 0;
}	
