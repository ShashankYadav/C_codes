#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int stack[10000],v[10000],top,k,en,n;
char string [1000],temp[5];
typedef struct node
{
	char s[1000];
	int len;
	struct node *next;
}no;
no ans[1000];
int nex;
void visitdfs(int a[][n],int n,int num)
{
	int i,j;
	//printf("num: %d\n",num);
	for(i=0;i<n;i++){
		if(v[i]==0&&a[num][i]==1){
			//v[i]=1;
			//printf("top: %d\n",top);
			stack[top++]=i+1;
			//printf("number entered in stack: %d\n",i+1);
			//printf("destination : %d\n",en);
			int z;
			/*for(z=0;z<n;z++)
			{
				for(j=0;j<n;j++)
					printf("%d ",a[z][j]);
				printf("\n");
			}*/
			if(i==en-1)
			{
				int j=0;
				for(j=0;j<top;j++)
				{
					//printf("%d ",stack[j]);
					sprintf(temp,"%d ",stack[j]);
					//printf("number found: %s",temp);
					strcat(string,temp);
				}
				//printf("\n");
				//printf("path found\n");
				//printf("%s\n",string);
				//insert(string,start);0
				strcpy(ans[nex].s,string);
				ans[nex++].len=strlen(string);
				for(z=0;z<100;z++)
					string[z]='\0';
			}
			visitdfs(a,n,i);
			//printf("fhqeuhdr7n438 \n");
			stack[top--];
		}
	}
}
int main()
{
	int x,times,k,i,j,st,q,f;
	scanf("%d",&times);
	no *start=(no*)malloc(sizeof(no));
	for(f=0;f<times;f++)
	{
		scanf("%d",&n);
		k=0;
		int a[n][n];
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
				a[i][j]=0;
		}
		for(i=0;i<n;i++)
		{
			v[i]=0;
			stack[i]=0;
			for(j=0;j<n;j++)
				scanf("%d",&a[i][j]);
		}
		scanf("%d",&q);
		for(x=0;x<q;x++)
		{
			nex=0;
			start->next=NULL;
			for(i=0;i<n;i++)
				v[i]=0;
			top=1;
			scanf("%d%d%d",&st,&en,&k);
			/*for(i=0;i<n;i++)
			{
				for(j=0;j<n;j++)
					printf("%d ",a[i][j]);
				printf("\n");
			}*/
			v[st-1]=1;
			stack[0]=st;
			visitdfs(a,n,st-1);
			//printf("printing all ans in order\n");
			int min,pos,tlen,z;
			char tstr[1000];
			for(i=0;i<nex;i++)
			{
				min=ans[i].len;
				pos=i;
				for(z=i+1;z<nex;z++)
					if(ans[z].len<min)
					{	
						pos=z;
						min=ans[z].len;
					}
				strcpy(tstr,ans[i].s);
				strcpy(ans[i].s,ans[pos].s);
				strcpy(ans[pos].s,tstr);
				tlen=ans[i].len;
				ans[i].len=ans[pos].len;
				ans[pos].len=tlen;
			}
			//for(i=0;i<nex;i++)
			//	printf("path: %s len :%d\n",ans[i].s,ans[i].len);
			//print(start->next);
			int cntr=1;
			cntr=1;
			if(nex==0)
				printf("-1\n");
			for(i=0;i<nex;i++)
			{
				if(cntr>k)
					break;
				for(z=0;z<strlen(ans[i].s)-1;z++)
					printf("%c",ans[i].s[z]);
				printf("\n");
				cntr++;
			}
		}
	}
	return 0;
}
