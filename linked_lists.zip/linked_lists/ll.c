#include<stdio.h>
#include<stdlib.h>
struct stud
{
	int data;
	struct stud *next;
};
typedef struct stud s;
void print(s*);
s* merge(s *s1,s *s2)
{
	s *t,*m;
	m=(s*)malloc(sizeof(s));
	m->next=NULL;
	t=m;
	while(s1!=NULL&&s2!=NULL)
	{
		if(s1->data<s2->data)
		{
			m->next=s1;
			s1=s1->next;
		}
		else
		{
			m->next=s2;
			s2=s2->next;
		}
		m=m->next;
	}
	if(s1==NULL)
	{
		m->next=s2;
	}
	else
	{
		m->next=s1;
	}
//	if(t==NULL)
	t=t->next;
print(t);

	return t;
}
s* insert(s *start,int dat)
{
	s *temp,*new;
	new=(s*)malloc(sizeof(s));
	new->data=dat;
	new->next=NULL;
	if(start==NULL)
	{
		start=new;
		return start;
	}
	temp=start;
	while(start->next!=NULL)
	{
		start=start->next;
	}
	start->next=new;
	return temp;
}
s* delete(s *start,int dat)
{
	s *temp,*new;
	new=start;
	if(start->data==dat)
	{
		temp=start;
		start=start->next;
		free(temp);
		return start;
	}
	while(start->next!=NULL&&start->next->data!=dat)
	{
		temp=start;
		start=start->next;
	}
	if(start->next==NULL)
	{
		return;
	}
	temp=start->next;
	start->next=temp->next;
	temp->next=NULL;
	free(temp);
	return new;
	
}
void print(s *start)
{
	while(start!=NULL)
	{
		printf("%d\n",start->data);
		start=start->next;
	}
	return;
}
s* reverse(s *start)
{
	s *back,*cur,*forw;
	forw=start;
	cur=NULL;
	back=NULL;
	while(forw!=NULL)
	{
		back=cur;
		cur=forw;
		forw=forw->next;
		cur->next=back;
	}	
	return cur;
}
s* insertmid(s* s1,int d)
{
	s *new,*temp,*back;
	new=(s*)malloc(sizeof(s));
	new->next=NULL;
	new->data=d;
	temp=s1;
	back=NULL;
	if(s1==NULL)
	{
		return new;
	}
	if(s1->next==NULL)
	{
		if(s1->data<d)
		{
			s1->next==new;
			return temp;
		}
		else
		{
			new->next=s1;
			return new;
		}
	}
	while(s1->next!=NULL&&s1->next->data<d)
	{
		back=s1;
		s1=s1->next;
	}
	back->next=new;
	new->next=s1;
	return temp;
}
int main()
{
	s *st,*st1,*m;
	st=NULL;
	char c='y';
	int ch,d,num;
	while(c=='y'||c=='Y')
	{
		printf("1.insert 2.delete 3.print 4:reverse 5:merge in order 6:print merged list 7.insert in inc\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter data to be inserted\n");
			       scanf("%d",&d);
			       printf("enter linked list number\n");
			       scanf("%d",&num);
			       if(num==1)
			       {
			       		st=insert(st,d);
			       }
			       else
			       {
				       st1=insert(st1,d);
			       }
			       break;
			case 2:printf("enter data to be deleted\n");
			       scanf("%d",&d);
			       printf("enter linked list number\n");
			       scanf("%d",&num);
			       if(num==1)
			       {
			       		st=delete(st,d);
			       }
			       else
			       {
				       st1=delete(st1,d);
				  
			       }
			       	break;
			case 3:printf("enter linked list number\n");
			       scanf("%d",&num);
			       if(num==1)
			       {
			       		print(st);
			       }
			       else
			       {
				       print(st1);
				  
			       }
			       break;
			case 4:printf("enter linked list number\n");
			       scanf("%d",&num);
			       if(num==1)
			       {
			       		reverse(st);
			       }
			       else
			       {
				       reverse(st1);
				  
			       }
			       break;
			case 5:m=merge(st,st1);
			       break;
			case 6:print(m);
			       break;
			case 7:printf("enter data\n");
			       scanf("%d",&d);
			       printf("enter linked list number\n");
			       scanf("%d",&num);
			       if(num==1)
			       {
				       st=insertmid(st,d);
			       }
			       else
			       {
				       st1=insertmid(st1,d);
			       }
			       break;
		}
		printf("do you want to it again(y/n)\n");
		getchar();
		scanf("%c",&c);
	}
	return 0;
}
