#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *next;
	//struct node *prev;
}node;
//Signature of the method
node * merge (node *start1, node *start2)
{

	return sorted;
}
void insert(node *start,int data)
{
	while(start->next)start = start -> next;
	start -> next =(node *)malloc(sizeof(node));
//	start -> next -> prev = start ;    //This is the only Extra step
	start = start -> next;
	start -> next = NULL;
	start -> data = data;
	return;
}
void printReverse(node *start)
{
	if(start==NULL)return;
	printReverse(start->next);
	printf("%d ",start->data);
}
void printlist(node *start)
{
	if(start==NULL)return;
	printf("%d ",start->data);
	printlist(start->next);
}
int main()
{
	node *start;
	start = (node *)malloc(sizeof(node)); //Dummy Node
	start -> next = NULL;
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		int temp;
		scanf("%d",&temp);
		insert(start,temp);
	}
	node *start1;
	start1 = (node *)malloc(sizeof(node)); //Dummy Node
	start1 -> next = NULL;
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		int temp;
		scanf("%d",&temp);
		insert(start1,temp);
	}
	node * sorted = merge(start,start1);
	printlist(sorted);
	return 0;
}




