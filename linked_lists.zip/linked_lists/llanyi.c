#include<stdio.h>
#include<stdlib.h>
struct stud
{
	int data;
	struct stud *next;
};
typedef struct stud s;
void print(s *start)
{
	while(start!=NULL)
	{
		printf("%d ",start->data);
		start=start->next;
	}
	printf("\n");
	return;
}
s* insany(s* start,int d)
{
	s *new,*pre,*temp;
	new=(s*)malloc(sizeof(s));
	new->next=NULL;
	pre=NULL;
	new->data=d;
	temp=start;
	if(start==NULL)
	{
		start=new;
		printf("new list\n");
		print(start->next);
		return start;
	}
	while(start!=NULL&&start->data<d)
	{
		pre=start;
		start=start->next;
	}
	if(pre==NULL)
	{
		new->next=start;
		printf("new list\n");
		print(new->next);
		return new;
	}
	else
	{
		pre->next=new;
		new->next=start;
	}
	printf("new list\n");
	print(temp->next);
	return temp;
	
}
int main()
{
	s *st;
	st->next=NULL;
	int da;
	char c='y';
	while(c=='y'||c=='Y')
	{
		scanf("%d",&da);
		st=insany(st,da);
		printf("wanna continue(y/n)\n");
		getchar();
		scanf("%c",&c);
	}
	return 0;
}
