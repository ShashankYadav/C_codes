#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int num;
	struct node *next;
}node;


void insert(node *start, int num)
{
	node *nptr;
	nptr = (node *)malloc(sizeof(node));

	while(start->next!=NULL && (start->next)->num < num)
		start = start->next;
	
	if(start->next == NULL)
	{
		start->next = nptr;
		nptr->next = NULL;
		nptr->num = num;
		return;
	}
	node *temp;
	temp = start;
	start = start->next;
	temp->next = nptr;
	nptr->next = start;
	nptr->num = num;
}

void delete(node *start, int num)
{
	while(start && (start->next)->num != num)
		start = start->next;

	if(!start)
	{
		printf("number not found\n");
		return;
	}

	node *tmp = start->next;
	start->next = (start->next)->next;
	free(tmp);
}

void print_list(node *start)
{
	start = start->next;
	while(start)
	{
		printf("%d ", start->num);
		start = start->next;
	}
	printf("NULL\n");
}

node* reverse(node *start)
{
	node *tmp;
	if((start->next) == NULL)
	{
		tmp = start;
		start->next = (node *)malloc(sizeof(node));
		start = start->next;
		start->next = tmp;
		return start;
	}
	node *nstart = reverse(start->next);
	tmp = start;
	(start->next)->next = tmp;
	return nstart;
}

int main()
{
	node *start, *start2;
	start = (node *)malloc(sizeof(node));
	start2 = (node *)malloc(sizeof(node));
	start2->next = NULL;
	start->next = NULL;

	int n;
	scanf("%d", &n);
	while(n--)
	{
		int x;
		scanf("%d", &x);
		insert(start, x);
		print_list(start);
	}

	printf("\nFinal List is:\n");
	print_list(start);
	printf("\n\n");
	/*
	printf("\n\n");
	scanf("%d", &n);
	while(n--)
	{
		int x;
		scanf("%d", &x);
		delete(start, x);
		print_list(start);
	}*/
	
	
	printf("\nReversed List is: \n");
	start2 = reverse(start);
	start->next->next = NULL;
	start->next =  NULL;
	free(start);
	print_list(start2);
	return 0;
}

