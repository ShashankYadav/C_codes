#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int num;
	struct node *next;
}node;

node *search(node *head, int num)
{
	while(head!=NULL && head->num != num)
		head = head->next;
	if(head == NULL)
		return NULL;
	return head;
}

void insert(node **head, int data1, int data2)
{
	if(*head == NULL)
	{
		*head = (node *)malloc(sizeof(node));
		(*head)->num = data1;
		(*head)->next = (node *)malloc(sizeof(node));
		(*head)->next->num = data2;
		(*head)->next->next = NULL;
		return;
	}
	node *location = search(*head, data2);
	node *curr = *head;
	while(curr->num != data1)
		curr = curr->next;
	if(location == NULL)
	{
		curr->next = (node *)malloc(sizeof(node));
		curr->next->num = data2;
		curr->next->next = NULL;
		return;
	}
	curr->next = location;	
}

int LoopDetect(node *head)
{
	node *slow = head;
	node *fast = head;
	while(fast!=NULL && slow!=NULL)
	{
		slow = slow->next;
		fast = fast->next ? fast->next->next : fast->next;
		if(slow == fast)
			return 1;
	}
	return 0;
}

int main()
{
	node *head = NULL;
	int n, k, data1, data2;
	scanf("%d", &n);
	scanf("%d", &k);
	while(k--)
	{
		scanf("%d %d", &data1, &data2);
		insert(&head, data1, data2);
	}
	printf(LoopDetect(head) ? "YES\n" : "NO\n");
	return 0;
}
