#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int num;
	struct node *next;
}node;

void insert(node *start, int num)
{
	while(start->next != NULL)
		start = start->next;
	start->next = (node *)malloc(sizeof(node));
	start = start->next;
	start->num = num;
	start->next = NULL;
}

struct node* merge(node *aRef, node *bRef)
{
	node *dest = (node *)malloc(sizeof(node));
	dest->next = NULL;
	node *curr = dest;

	aRef = aRef->next;
	bRef = bRef->next;

	while(aRef!=NULL && bRef!=NULL)
	{
		curr->next = (node *)malloc(sizeof(node));
		curr = curr->next;
		curr->next = NULL;

		if(aRef->num < bRef->num)
		{
			curr->num = aRef->num;
			aRef = aRef->next;
		}
		else 
		{
			curr->num = bRef->num;
			insert(dest, bRef->num);
			bRef = bRef->next;
		}

	}

	if(aRef!=NULL)
		while(aRef!=NULL)
		{
			curr->next = (node *)malloc(sizeof(node));
			curr = curr->next;
			curr->next = NULL;
			curr->num = aRef->num;
			aRef = aRef->next;
		}
	else if(bRef!=NULL)
		while(bRef!=NULL)
		{
			curr->next = (node *)malloc(sizeof(node));
			curr = curr->next;
			curr->next = NULL;
			curr->num = bRef->num;
			bRef = bRef->next;
		}
	return dest;
}

void print(node *start)
{
	start = start->next;
	while(start)
	{
		printf("%d ", start->num);
		start = start->next;
	}
	printf("\n");
}

void DeleteList(node *start)
{
	node *tmp;
	while(start!=NULL)
	{
		tmp = start;
		start = start->next;
		free(tmp);
	}
}

int main()
{
	node *aRef, *bRef, *dest;
	aRef = (node *)malloc(sizeof(node));
	bRef = (node *)malloc(sizeof(node));

	aRef->next = NULL;
	bRef->next = NULL;

	insert(aRef, 1);
	insert(aRef, 5);
	insert(aRef, 7);
	insert(aRef, 11);
	insert(aRef, 18);
	print(aRef);

	insert(bRef, 2);
	insert(bRef, 6);
	insert(bRef, 8);
	insert(bRef, 31);
	insert(bRef, 78);
	print(bRef);

	dest = merge(aRef, bRef);
	print(dest);

	DeleteList(aRef);
	DeleteList(bRef);
	DeleteList(dest);
	return 0;
}

