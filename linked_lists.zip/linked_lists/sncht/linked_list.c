#include<stdio.h>
#include<stdlib.h>

typedef struct data
{
	int num;
	struct data *next;
}data;

/*insert at the end of the data*/
void insert(data *start, int n)
{
	while(start->next!=NULL)
		start = start->next;
	start->next=(data*)malloc(sizeof(data));
	start = start->next;
	start->next = NULL;
	start->num = n;
	return;
}

/*delete the node with value n*/
void delete(data *start, int n)
{
	while(((start->next)!=NULL) && (start->next)->num!=n)
		start = start->next;
	if((start->next)==NULL)
		return;
	data *tmp;
	tmp = start->next;
	start->next = (start->next)->next;
	free(tmp);
}


void display(data *start)
{
	start = start->next;
	while(start)
	{
		printf("%d ", start->num);
		start = start->next;
	}
	printf("\n");
}

int main()
{
	data *start;
	int no, i;
	start = (data *)malloc(sizeof(data));
	scanf("%d", &no);

	for(i=0; i<no; i++)
	{
		int x;
		scanf("%d", &x);
		insert(start,x);
	}
	display(start);

	scanf("%d", &no);
	for(i=0; i<no; i++)
	{
		int x;
		scanf("%d", &x);
		delete(start, x);
	}
	display(start);
	
	return 0;
}
