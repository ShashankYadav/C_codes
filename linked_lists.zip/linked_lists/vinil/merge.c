#include<stdio.h>
#include<stdlib.h>
struct nn 
{
	int data;
	struct nn *next;
};
typedef struct nn node;
void insert(node *start,int x)
{
	node *t,*temp;
	t=malloc(sizeof(node));
	temp=malloc(sizeof(node));
	temp->data=x;
	temp->next=NULL;
xy:	if(start->next==NULL || ((start->next)->data)>x)
	{
		t=start->next;
		start->next=temp;
		temp->next=t;
	}
	else
	{
		start=start->next;
		goto xy;
	}
	return ;
}
void print(node *start)
{
	while(start->next!=NULL)
	{
		printf("%d ",(start->next)->data);
		start=start->next;
	}
	return ;
}
int main()
{
	node *h,*k,*j;
	int n,x,m;
	h=malloc(sizeof(node));
	k=malloc(sizeof(node));
	h->next=NULL;
	k->next=NULL;
	scanf("%d",&n);
	scanf("%d",&m);
	while(n!=0)
	{
		scanf("%d",&x);
		insert(h,x);
		n--;
	}
//	printf("linked list one is\n");
//	print(h);
//	printf("\n");
	while(m!=0)
	{
		scanf("%d",&x);
		insert(h,x);
		m--;
	}
	printf("final list is \n");
	print(h);
	printf("\n");
	return 0;
}

