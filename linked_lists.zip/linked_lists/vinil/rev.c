#include<stdio.h>
#include<stdlib.h>
typedef struct nn
{
	int data;
	struct nn *next;
}node;
void insert(node *start,int x)
{
	node *temp,*t;
	temp=malloc(sizeof(node));
	t=malloc(sizeof(node));
	temp->data=x;
	temp->next=NULL;
	t=start->next;
	start->next=temp;
	temp->next=t;
}
void reverse(node *start)
{
	node *tempo;
	tempo=malloc(sizeof(node));
	tempo=start->next;
	start->next=start;
	if(tempo->next!=NULL)
	reverse(tempo);
	return;
}
void print(node *start)
{
	while(start->next!=NULL)
	{
		printf("%d ",(start->next)->data);
		start=start->next;
	}
}
int main()
{
	int n,i,x;
	node *h,*he;
	h=malloc(sizeof(node));
	h->next=NULL;
	scanf("%d",&n);
	while(n!=0)
	{
		scanf("%d",&x);
		insert(h,x);
		print(h);
		printf("\n");
		n--;
	}
	he=malloc(sizeof(node));
	he=h->next;
	reverse(he);
	print(h);
	return 0;
}





