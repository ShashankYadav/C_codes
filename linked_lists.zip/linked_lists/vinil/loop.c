#include<stdio.h>
#include<stdlib.h>
typedef struct nn 
{
	int data;
	struct nn *next;
}node;
int loopdetect(node *h)
{
	node *t1=h->next;
	if(t1==NULL)
		return 0;
	node *t2=(h->next)->next;
	while(t1!=NULL && t2!=NULL)
	{
		if(t2==t1)
			return 1;
		t1=t1->next;
		if((t2->next)==NULL)
			return 0;
		else
			t2=(t2->next)->next;
	}
	return 0;
}
void insert(node *h,int x)
{
	node *temp;
	temp=malloc(sizeof(node));
	temp->data=x;
	temp->next=NULL;
	while(h->next!=NULL)
	{
		h=h->next;
	}
	h->next=temp;
}
void print(node *h)
{
	while(h->next!=NULL)
	{
		printf("%d ",(h->next)->data);
		h=h->next;
	}
	return ;
}
int main()
{
	int x,a,n,i,l,b;
	scanf("%d",&n);
	scanf("%d",&l);
	node *h,*start,*rg;
	h=malloc(sizeof(node));
	rg=malloc(sizeof(node));
	start=malloc(sizeof(node));
	h->next=NULL;
	start=h;
	rg=h;
	scanf("%d",&x);
	insert(h,x);
	h=h->next;
	for(i=0;i<l;i++)
	{
		rg=start;
		if(i!=0)
		scanf("%d",&a);
		scanf("%d",&b);
		while(((rg->next)->data)!=b)
		{
			rg=rg->next;
			if(rg->next==NULL)
				break;
		}
		if(rg->next==NULL)
		{
			insert(h,b);
			h=h->next;
		}
		else
		h->next=rg;	
	}
//	print(start);
//	fprintf(stderr,"HBK");
	printf("%s",loopdetect(start)?"YES\n":"NO\n");
	return 0;
}
