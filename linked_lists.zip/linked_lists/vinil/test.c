#include<stdio.h>
#include<stdlib.h>
struct nn 
{
	int data;
	struct nn *next;
};
typedef struct nn node;
void insert(node *start,int x)
{
	node *temp,*t;
	temp=(node *)malloc(sizeof(node));
	t=(node *)malloc(sizeof(node));
	//assigning a temp pointer to thing to be inserted
	temp->data=x;
	temp->next=NULL;
	// data is the thing to be inserted ..
	// start is the place where we want to insert it
	t=start->next;
	start->next=temp;
	temp->next=t;
	printf("after unsertung value is %d\n",(start->next)->data);
}
void print(node * start)
{
	// here start denotes th place from where we want to print the list....
	while(start->next!=NULL)
	{
		printf("%d ",(start->next)->data);
		start=start->next;
	}
}
int main()
{
	int x,y,n,i=0;
	node *h,*start,*tem;
	h=(node *)malloc(sizeof(node));
	start=(node *)malloc(sizeof(node));
	printf("number of elements in the ll to be formed\n");
	scanf("%d",&n);
	h->next=NULL; // (*h).next=NULL it represents that at this time we have only one element in list which is *h 
	// and its next poins to null...... A kind of a dummy node.
	while(1)
	{
		printf("enter num to be inserted\n");
		scanf("%d",&x);
		insert(h,x);
		printf("printinf\n");
		print(h);
		printf("dwqwq\n");
		n--;
		printf("n is %d\n",n);
		if(n == 0)
		{
			break;
		}
	}
	fprintf(stderr, "HBK");
	start=h;
	while(1)
	{
		if(start->next==NULL)
			break;
		else
			continue;
	}
	h->next=start;
	start=h;
	while(start->next!=NULL)
	{
		tem=(start->next)->next;
		(start->next)->next=start;
		start=tem;
	}
	print(h);
	printf("\n");
	/*printf("enter the num to be inserted\n");
	scanf("%d",&x);
	printf("enter the pos on which elelment to be inserted\n");
	scanf("%d",&n);
	start=h;
	while(i!=n)
	{
		start=start->next;
		i++;
	}
	insert(start,x);
	print(h);
	printf("\n");*/
	return 0;
}
