#include<stdio.h>
#include<stdlib.h>
struct nn 
{
	int data;
	struct nn *next;
};
typedef struct nn node;
void insert(node *start,int x)
{
	node *temp,*t;
	temp=(node *)malloc(sizeof(node));
	t=(node *)malloc(sizeof(node));
	//assigning a temp pointer to thing to be inserted
	temp->data=x;
	temp->next=NULL;
	// data is the thing to be inserted ..
xy:	// start is the place where we want to insert it
	if(start->next==NULL || ((start->next)->data)>(temp->data))
	{
	t=start->next;
	start->next=temp;
	temp->next=t;
	}
	else
	{
		start=start->next;
		goto xy;
	}
}
void print(node * start)
{
	// here start denotes th place from where we want to print the list....
	while(start->next!=NULL)
	{
		printf("%d ",(start->next)->data);
		start=start->next;
	}
}
void delete(node *start)
{
	start->next=(start->next)->next;
}
void printreverse(node *start)
{
	if(start->next==NULL)
		return;
	printreverse(start->next);
	printf("%d ",(start->next)->data);
}	
int main()
{
	int x,y,n,i;
	node *h,*start;
	h=(node *)malloc(sizeof(node));
	start=(node *)malloc(sizeof(node));
	scanf("%d",&n);
	h->next=NULL; // (*h).next=NULL it represents that at this time we have only one element in list which is *h 
	// and its next poins to null...... A kind of a dummy node.
	while(n!=0)
	{
		scanf("%d",&x);
		insert(h,x);
		print(h);
		printf("\n");
		n--;
	}
	printf("\n\n");
	printf("enter the num to be inserted at any position\n");
	scanf("%d",&x);
	printf("enter the pos on which elelment to be inserted\n");
	scanf("%d",&n);
	start=h;
	i=1;
	while(i!=n)
	{
		start=start->next;
		i++;
	}
	insert(start,x);
	print(h);
	printf("\n");
	printf("\n\n");
	printf("enter the pos from where element is to be deleted\n");
	scanf("%d",&n);
	start=h;
	i=1;
	while(i!=n)
	{
		start=start->next;
		i++;
	}
	delete(start);
	print(h);
	printf("\n");
	printf("\n\n\n\n");
	printreverse(h);
	printf("\n");
	return 0;
}
