#include<stdio.h>
int main()

{
	enum days
	{sun=0,mon=1,tue=2,wed=3,thur=4,fri=5,sat=6};
	enum days DAY;
	int j=0;
	scanf("%d",&j);
	DAY=j;
	if(DAY==sun || DAY==sat)
		printf("BETA MAZE KARO\n");
	else
		printf("BETA KAAM KARO KAAMM\n");
	return 0;
}

