#include<stdio.h>
#include<stdlib.h>
struct nn 
{
	int data;
	struct nn *next;
};
typedef struct nn node;
void insert(node *start,int x)
{
	node *temp,*t;
	temp=(node *)malloc(sizeof(node));
	t=(node *)malloc(sizeof(node));
	//assigning a temp pointer to thing to be inserted
	temp->data=x;
	temp->next=NULL;
	// data is the thing to be inserted ..
	// start is the place where we want to insert it
	t=start->next;
	start->next=temp;
	temp->next=t;
	printf("after unsertung value is %d\n",(start->next)->data);
}
void print(node * start)
{
	// here start denotes th place from where we want to print the list....
	while(start->next!=NULL)
	{
		printf("%d ",(start->next)->data);
		start=start->next;
	}
}
int cmp(int data1,int data2)
{
	if(data1>data2)
		return 0;
	else
		return 1;
}
void merge(node *start1,node *start2)
{
	int z;
	node *j;
	j=malloc(sizeof(node));
	j=j->next;
	while(j!=NULL)
	{
	z=cmp((start1->next)->data,(start2->next)->data);
	if(z==1)
	{
		insert(j,(start1->next)->data);
		start1=start1->next;
		j=j->next;
	}
	else
	{
		insert(j,(start2->next)->data);
		start2=start2->next;
		j=j->next;
	}
	}
	print(j);
}
int main()
{
	int x,y,n,i=0,m;
	node *h,*start,*k;
	h=(node *)malloc(sizeof(node));
	k=(node *)malloc(sizeof(node));
	start=(node *)malloc(sizeof(node));
	printf("number of elements in the ll to be formed\n");
	scanf("%d",&n);
	scanf("%d",&m);
	h->next=NULL; // (*h).next=NULL it represents that at this time we have only one element in list which is *h 
	// and its next poins to null...... A kind of a dummy node.
	k->next=NULL;
	while(n!=0)
	{
		printf("enter num to be inserted\n");
		scanf("%d",&x);
		insert(h,x);
		printf("printinf\n");
		print(h);
		printf("\n");
		n--;
	}
	while(m!=0)
	{
		printf("enter num to be inserted\n");
		scanf("%d",&x);
		insert(k,x);
		printf("printinf\n");
		print(k);
		printf("\n");
		m--;
	}
	merge(h,k);
	print(h);
/*	printf("enter the num to be inserted\n");
	scanf("%d",&x);
	printf("enter the pos on which elelment to be inserted\n");
	scanf("%d",&n);
	start=h;
	while(i!=n)
	{
		start=start->next;
		i++;
	}
	insert(start,x);
	print(h);
	printf("\n");*/
	return 0;
}
