#include<stdio.h>
int main()
{
	int times,k;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int n,num,m,diff,close,i,j,min,l,temp,counter=0,d;
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=n-1;i>=0;i--)
		{
			if(a[i]>a[i-1]) 
			{
				if(counter==0)
				{
					temp=a[i];
					a[i]=a[i-1];
					a[i-1]=temp;
					break;
				}
				num=a[i-1];
				if(a[i]>num)
					diff=a[i]-num;
				else
					diff=num-a[i];
				close=i;
				for(m=i+1;m<n;m++)
				{
					if(a[m]>num)
						d=a[m]-num;
					else
						d=num-a[m];
					if(d<diff)
						close=m;
				}
				temp=a[i-1];
				a[i-1]=a[close];
				a[close]=temp;


				for(j=i;j<n;j++)
				{
					min=j;
					for(l=j+1;l<n;l++)
					{
						if(a[l]<a[min])
						{
							min=l;
							//printf("new min at %d",min);
						}
					}
						temp=a[j];
						a[j]=a[min];
						a[min]=temp;
				}
				break;
			}
			else 
			{
				counter++;
				continue;
			}
		}
		for(i=0;i<n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}

