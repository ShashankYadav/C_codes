#include<stdio.h>
int check(int a[],int size)
{
	//printf("a in check\n");
	int t,i,flag1[size];
	//for(i=0;i<size;i++)
	//{
	//	printf("%d ",a[i]);
	//}
	//printf("\n");
	for(i=0;i<size;i++)
	{
		flag1[i]=0;
	}
	for(i=0;i<size;i++)
	{
		t=a[i];
		//printf("%d %d %d\n",i,a[i],a[i+t]);
		if(flag1[i]==0&&i+a[i]+1<size)
		{
			//printf("entered if flagi=0 and i+a[i]<size\n");
			if(a[i]==a[i+t+1])
			{
				//printf("a[i]=a[i+a[i]]\n");
				flag1[i]=1;
				flag1[i+t+1]=1;
			}
			/*else
			{
				return 0;
			}*/
		}
	}
	for(i=0;i<size;i++)
	{
		if(flag1[i]!=1)
		{
			return 0;
		}
	}
	return 1;
}
int main()
{
	int i,ans=0,n;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	ans=check(a,n);
	if(ans==1)
	{
		printf("yes\n");
	}
	else
	{
		printf("no\n");
	}
	return 0;
}

