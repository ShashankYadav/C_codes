#include<stdio.h>
int flag=0;
int check(int a[],int size)
{
	int t,i,flag1[size];
	for(i=0;i<size;i++)
	{
		flag1[i]=0;
	}
	for(i=0;i<size;i++)
	{
		t=a[i];
		//printf("%d %d %d\n",i,a[i],a[i+t]);
		if(flag1[i]==0&&i+a[i]+1<size)
		{
			//printf("entered if flagi=0 and i+a[i]<size\n");
			if(a[i]==a[i+t+1])
			{
				//printf("a[i]=a[i+a[i]]\n");
				flag1[i]=1;
				flag1[i+t+1]=1;
			}
			/*else
			{
				return 0;
			}*/
		}
	}
	for(i=0;i<size;i++)
	{
		if(flag1[i]!=1)
		{
			return 0;
		}
	}
	return 1;
}
void sort(int a[],int index,int size)
{
	int i,j,temp;
	for(i=index+1; i<size; i++)
	{
		temp = a[i];
		j = i-1;
		while(temp<a[j] && j>=index)
		{
			a[j+1] = a[j];
			j = j-1;
		}
		a[j+1] = temp;
	}
	return ;
}
int next(int a[],int size)
{
	if(check(a,size)==1)
	{
		flag=1;
		printf("flag=1\n");
		return ;
	}
	int i,index,j;
	for(i=0;i<size;i++)
	{
		if(a[i-1]<a[i])
		{
			index=i;
			break;
		}
	}
	sort(a,index,size);
	int temp;
	for(i=index;i<size;i++)
	{
		if(a[i]>a[index-1])
		{
			temp=a[i];
			a[i]=a[index-1];
			a[index-1]=temp;
			break;
		}
	}
}

int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int i,n;
		flag=0;
		scanf("%d",&n);
		int b[n],a[2*n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&b[i]);
			a[2*i]=b[i];
			a[(2*i)+1]=b[i];
		}
		sort(a,0,2*n);
		/*for(i=0;i<2*n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");*/
		while(flag==0)
		{
			next(a,2*n);
		}
	}
	return 0;
}	
