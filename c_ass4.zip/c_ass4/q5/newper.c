#include<stdio.h>
void print(const int *v, const int size)
{
	int i;
  if (v != 0) {
    for (i = 0; i < size; i++) {
      printf("%d ", v[i] );
    }
    printf("\n");
  }
} // print


void permute(int *v, const int start, const int n)
{  
	int i;

  if (start == n-1) 
	{
		print(v,n);
		/*if(v!=0)
		{
			for(i=0;i<n;i++)
	  		{
	  			printf("%d ",v[i]);
    	 		}
  			printf("\n");
			*/
	}
 		else 
		{
    			for (i = start; i < n; i++) 
			{
    				int tmp = v[i];
      				v[i] = v[start];
      				v[start] = tmp;
      				permute(v, start+1, n);
      				v[start] = v[i];
      				v[i] = tmp;
    			}
  		}
		return ;
	}
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	permute(a,0,n);
	return 0;
}


