#include<stdio.h>
int flag=0;
int check(int a[],int size)
{
	int t,i,flag1[size];
	for(i=0;i<size;i++)
	{
		flag1[i]=0;
	}
	for(i=0;i<size;i++)
	{
		t=a[i];
		//printf("%d %d %d\n",i,a[i],a[i+t]);
		if(flag1[i]==0&&i+a[i]+1<size)
		{
			//printf("entered if flagi=0 and i+a[i]<size\n");
			if(a[i]==a[i+t+1])
			{
				//printf("a[i]=a[i+a[i]]\n");
				flag1[i]=1;
				flag1[i+t+1]=1;
			}
			/*else
			{
				return 0;
			}*/
		}
	}
	for(i=0;i<size;i++)
	{
		if(flag1[i]!=1)
		{
			return 0;
		}
	}
	return 1;
}
void print(const int *v, const int size)
{
	int i;
  if (v != 0) {
    for (i = 0; i < size; i++) {
      printf("%d ", v[i] );
    }
    printf("\n");
  }
} // print


void permute(int *v, const int start, const int n)
{  
	int i;
	if(start==n-1)
	{
		print(v,n);
	}
	
  if (start == n-1&&flag!=1) 
	{
		if(check(v,n)==1)
	{
		flag=1;
		printf("flag=1\n");
		print(v,n);
		return ;
	}
		/*if(v!=0)
		{
			for(i=0;i<n;i++)
	  		{
	  			printf("%d ",v[i]);
    	 		}
  			printf("\n");
			*/
	}
 		else 
		{
    			for (i = start; i < n; i++) 
			{
    				int tmp = v[i];
      				v[i] = v[start];
      				v[start] = tmp;
      				permute(v, start+1, n);
      				v[start] = v[i];
      				v[i] = tmp;
    			}
  		}
		return ;
	}
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int i,n;
		flag=0;
		scanf("%d",&n);
		int b[n],a[2*n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&b[i]);
			a[2*i]=b[i];
			a[(2*i)+1]=b[i];
		}
		/*for(i=0;i<2*n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");*/
		while(flag==0)
		{
			permute(a,0,2*n);
		}
	}
	return 0;
}	
