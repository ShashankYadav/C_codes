#include<stdio.h>
int flag=0;
int check(int a[],int size)
{
	int t,i,flag1[size];
	for(i=0;i<size;i++)
	{
		flag1[i]=0;
	}
	for(i=0;i<size;i++)
	{
		t=a[i];
		//printf("%d %d %d\n",i,a[i],a[i+t]);
		if(flag1[i]==0&&i+a[i]+1<size)
		{
			//printf("entered if flagi=0 and i+a[i]<size\n");
			if(a[i]==a[i+t+1])
			{
				//printf("a[i]=a[i+a[i]]\n");
				flag1[i]=1;
				flag1[i+t+1]=1;
			}
			/*else
			{
				return 0;
			}*/
		}
	}
	for(i=0;i<size;i++)
	{
		if(flag1[i]!=1)
		{
			return 0;
		}
	}
	return 1;
}
void next( int a[], int n)
{
	int i;
	for(i=0;i<2*n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");

	if(check(a,n)==1)
	{
		flag=1;
		printf("flag=1\n");
		return ;
	}

	int num,m,diff,close,j,min,l,temp,counter=0,d;
		for(i=n-1;i>=0;i--)
		{
			if(a[i]>a[i-1]) 
			{
				if(counter==0)
				{
					temp=a[i];
					a[i]=a[i-1];
					a[i-1]=temp;
					break;
				}
				num=a[i-1];
				if(a[i]>num)
					diff=a[i]-num;
				else
					diff=num-a[i];
				close=i;
				for(m=i+1;m<n;m++)
				{
					if(a[m]>num)
						d=a[m]-num;
					else
						d=num-a[m];
					if(d<diff)
						close=m;
				}
				temp=a[i-1];
				a[i-1]=a[close];
				a[close]=temp;
				for(j=i;j<n;j++)
				{
					min=j;
					for(l=j+1;l<n;l++)
					{
						if(a[l]<a[min])
						{
							min=l;
						}
					}
					temp=a[j];
					a[j]=a[min];
					a[min]=temp;
				}
				break;
			}
			else 
			{
				counter++;
				continue;
			}
		}
}
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int i,n;
		scanf("%d",&n);
		int b[n],a[2*n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&b[i]);
			a[2*i]=b[i];
			a[(2*i)+1]=b[i];
		}
		/*for(i=0;i<2*n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");*/
		while(flag==0)
		{
			next(a,2*n);
		}
			for(i=0;i<2*n;i++)
		{
			printf("%d ",b[i]);
		}
		printf("\n");
	}
	return 0;
}	
