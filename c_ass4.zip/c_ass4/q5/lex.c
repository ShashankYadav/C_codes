#include<stdio.h>
void sort(int a[],int index,int size)
{
	int i,j,temp;
	for(i=index+1; i<size; i++)
	{
		temp = a[i];
		j = i-1;
		while(temp<a[j] && j>=index)
		{
			a[j+1] = a[j];
			j = j-1;
		}
		a[j+1] = temp;
	}
	return ;
}
int next(int a[],int size)
{
	/*if(check(a,size)==1)
	{
		flag=1;
		printf("flag=1\n");
		return ;
	}*/
	
	int i,index,j;
	for(i=0;i<size;i++)
	{
		if(a[i-1]<a[i])
		{
			index=i;
			break;
		}
	}
	sort(a,index,size);
	int temp;
	for(i=index;i<size;i++)
	{
		if(a[i]>a[index-1])
		{
			temp=a[i];
			a[i]=a[index-1];
			a[index-1]=temp;
			break;
		}
	}
}
int main()
{
	int i,n;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[n]);
	}
	next(a,n);
	for(i=0;i<n;i++)
	{
		printf("%d ",a[n]);
	}
	printf("\n");
	return ;
}
