#include<stdio.h>
void place(int a[],int start,int size)
{
	int i,temp;
	for(i=0;i<size;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
	/*if(check(a)==1)
	{
		flag=1;
		return ;
	}*/

	if(start==size)
	{
		return ;
	}
	for(i=start;i<size;i++)
	{
		temp=a[start];
		a[start]=a[i];
		a[i]=temp;
		if(a[size]!=a[i+1])
		{
			place(a,start+1,size);
			temp=a[start];
			a[start]=a[i];
			a[i]=temp;
		}
	}
	return ;
}
int main()
{
	int n,i;
	scanf("%d",&n);
	int a[n],b[2*n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		b[2*i]=a[i];
		b[(2*i)+1]=a[i];
	}
	place(b,0,2*n);
	return 0;
}
