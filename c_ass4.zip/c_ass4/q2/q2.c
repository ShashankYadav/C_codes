#include<stdio.h>
#include<math.h>
int count=0;
//int counter=0;
int check(int a[],int size)
{
	int n=sqrt(size);
	int i,count=0;
	int s[n],c[n];
	for(i=0;i<n;i++)
	{
		s[i]=0;
		c[i]=0;
	}
	for(i=0;i<size;i++)
	{
		s[i/n]+=a[n*(i/n)+(i%n)];
		c[i/n]+=a[n*(i%n)+(i/n)];
	}
	if(s[0]!=c[0])
	{
		return 0;
	}
	for(i=1;i<n;i++)
	{
		if(s[i]!=s[i-1]||c[i]!=c[i-1]||s[i]!=c[i])
		{
			return 0;
		}
	}
	return 1;
}
	

void sort(int a[],int index,int size)
{
	
	int p,q,temp;
	for(p=index+1;p<size;p++)
	{
		temp=a[p];
		q=p-1;
		while(q>=index && a[q]>temp)
		{
			a[q+1]=a[q];
			q--;
		}
		a[q+1]=temp;
	}
}
void next(int a[],int size)
{
	//counter++;
	//if(counter<300)
	//{
	int i;
	/*for(i=0;i<size;i++)
	{
		printf("%d ",a[i]);
	}*/
	//printf("\n");
	
	//printf("flag=%d\n",flag);
	//if(flag!=size-1)
	//{
		/*if(check(a,size)==1)
		{
			count++;
			printf("count:%d",count);
			return ;
		}*/

		int index,temp;
		for(i=size-1;i>0;i--)
		{
			if(a[i-1]<a[i])
			{
				index=i;
				break;
			}
		}
		sort(a,index,size);
		for(i=index;i<size;i++)
		{	
			if(a[i]>a[index-1])
			{
				temp=a[i];
				a[i]=a[index-1];
				a[index-1]=temp;
				break;
			}
		}	
		//for(i=0;i<size;i++)
		//{
		//	printf("%d ",a[i]);
		//}
		//printf("\n");
	//	char ch='\n';
		//while(ch=='\n')
		//{
			//next(a,size);
		//	scanf("%c",&ch);
	//	}
	//}
	//else
	//{
	//	return ;
	//}
}
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int i,n;
		count=0;
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a,0,n);
		/*for(i=0;i<n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");*/
		while(1)
		{
			if(check(a,n)==1)
			{
				count++;
			}
			int flag=0;
			for(i=0;i<n-1;i++)
			{
				if(a[i+1]<=a[i])
				{
					flag++;
				}
				else
				{
					break;
				}
			}
			if(flag==n-1)
			break;
			next(a,n);
		}
		printf("%d\n",count);
	}
	return 0;
}
