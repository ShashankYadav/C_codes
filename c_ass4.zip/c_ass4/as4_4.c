#include<stdio.h>
#include<string.h>
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		char a[10000],b[10000],comp[10000],ans[10000];
		int flag=0,start=0,lena,lenc,i,j,p=0,counter=0;
		scanf("%s%s",a,comp);
		lena=strlen(a);
		lenc=strlen(comp);
		for(i=0;i<lena;i++)
		{
			b[i]=a[i];
		}
		for(i=0;i<lena;i++)
		{
			if(a[i]==comp[p])
			{
				start=i;
				//printf("start=%d\n",i);
				flag=1;
			}
			if(flag==1)
			{
				for(j=0;j<lenc;j++)
				{
					//printf("a[start+%d]=%c comf[%d]%c ",j,a[start+j],j,comp[j]);
					if(a[start+j]!=comp[j]||(start+j>lena))
					{
						flag=0;
						//printf("flag=0 and broken\n");
						break;
					}
				}
				//printf("\n");
				if(flag==1)
				{
					for(j=0;j<lenc;j++)
					{
						b[start+j]='*';
					}
				}
				//puts(b);
			}
			p=0;
		}
		j=0;
		for(i=0;i<lena;i++)
		{
			if(b[i]!='*')
			{
				ans[j++]=b[i];
				counter++;
			}
		}
		for(i=0;i<counter;i++)
		{
			printf("%c",ans[i]);
		}
		printf("\n");
	}
	return 0;
}
