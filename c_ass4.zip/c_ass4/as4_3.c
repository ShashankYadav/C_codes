#include<stdio.h>
int counter=0;
int split(int n1,int n2)
{
	if(n1<=n2)
	{
		return 1;
	}
	if(n1%2==0)
	{
		counter=split(n1/2,n2)+split(n1/2,n2);
	}
	if(n1%2!=0)
	{
		counter=split(n1/2,n2)+split((n1/2)+1,n2);
	}
	return counter;
}
	
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		int ans,n1=0,n2=0;
		counter=0;
		scanf("%d%d",&n1,&n2);
		ans=split(n1,n2);
		printf("%d\n",ans);
	}
	return 0;
}
