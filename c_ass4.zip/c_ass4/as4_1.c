#include<stdio.h>
int main()
{
	int k,times;
	scanf("%d",&times);
	for(k=0;k<times;k++)
	{
		char a[10000];
		int i,flag=0,counter=0;
		scanf("%s",a);
		for(i=0;a[i]!='\0';i++)
		{
			if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
			{
				if(flag==0)
				{
					flag=1;
					counter++;
				}
			}
			else
			{
				flag=0;
			}
		}
		printf("%d\n",counter);
	}
	return 0;
}
