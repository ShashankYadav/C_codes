#include<stdio.h>
int main()
{
	//int t,k;
	//scanf("%d",&t);
	//for(k=0;k<t;k++)
	//{
		char a[100],b[100];
		scanf("%s %s",a,b);
		int len1=0,len2=0,i,j,num[1000][1000],n=0,n1,n2,posi=999,posj=999;
		for(i=0;a[i]!='\0';i++)
		{
			len1++;
		}
		for(i=0;b[i]!='\0';i++)
		{
			len2++;
		}
		//printf("%d %d\n",len1,len2);

		for(i=0;i<1000;i++)
		{
			for(j=0;j<1000;j++)
			{
				num[i][j]=0;
			}
		}
		/*for(i=0;i<1000;i++)
		{
			for(j=0;j<1000;j++)
			{
				printf("%d ",num[i][j]);
			}
			printf("\n");
		}*/

		for(i=len1-1;i>=0;i--)
		{
			for(j=len2-1;j>=0;j--)
			{
				n1=(int)a[i]-48;
				//printf("%d ",n1);
				n2=(int)b[j]-48;
				//printf("%d ",n2);
				//printf("\n");
				//printf("%d\n",n+n1*n2);
				if((n+n1*n2)>9)
				{
					num[posi][posj--]=(n+n1*n2)%10;
					//printf("if >9 act\n");
				}
				else
				{
					num[posi][posj--]=n+n1*n2;
				}
				//printf("%d %d\n",posi,posj);
				//printf("%d\n",num[posi][posj+1]);
				n=(n1*n2)/10;
				//printf("%d\n",n);
			}
			posi--;
			posj=999;
		}
		for(i=999;i>999-len1;i--)
		{
			for(j=999;j>999-len2;j--)
			{
				printf("%d ",num[i][j]);
			}
			printf("\n");
		}
	//}
	return 0;
}

