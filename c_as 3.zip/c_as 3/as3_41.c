#include<stdio.h>
int main()
{
	 int times,k;
	 scanf("%d",&times);
	 for(k=0;k<times;k++)
	 {
	 	int pos,i,j,l,n,counter=1,max=0,min=1000000,shift=0,prev;
		scanf("%d",&n);
	 	int a[n];
		 for(i=0;i<n;i++)
		 {
			 scanf("%d",&a[i]);
			 /*if(a[i]<min)
			 {
				 min=a[i];
				 pos=i;
			 }*/
		 }
	 
		 for(l=0;l<n;l++)
		 {
		 	i=l;
			counter=1;
		 	while(i<n)
		 	{
				 prev=a[l];
				 //prev2=a[i];
				 shift=0;
				 for(j=i;j<n;j++)
				 {
					 if(a[j]>prev)
					 {
						 counter++;
						 prev=a[j];
						 shift=j;
					 }
					 if(counter>max)
					 {
						 max=counter;
					 }
				 }
				 i=shift+1;
		 	 	 counter=2;
		 	}
		 }
		 printf("%d\n",max);
	 }
	 return 0;
}
