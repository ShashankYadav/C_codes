#include<stdio.h>
int main()
{
	int k,n;
	scanf("%d",&n);
	for(k=0;k<n;k++)
	{
		double a[3][3],b[3][3],c[3][3],d[3][3],det,det1,det2,det3;
		float x[3],y[3],z[3],w[3],l=0,u=0,v=0;
		int i,j;
		for(i=0;i<3;i++)
		{
			scanf("%f %f %f %f\n",&x[i],&y[i],&z[i],&w[i]);
		}
		/*for(i=0;i<3;i++)
		{
			printf("%f %f %f %f\n",x[i],y[i],z[i],w[i]);
		}*/
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{
				if(j==0)
				{
					a[i][j]=x[i];
				}
				if(j==1)
				{
					a[i][j]=y[i];
				}
				if(j==2)
				{
					a[i][j]=z[i];
				}
			}
		}
		/*for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				printf("%f ",a[i][j]);
			}
			printf("\n");
		}*/
		det=a[0][0]*((a[1][1]*a[2][2])-(a[1][2]*a[2][1]))-a[0][1]*((a[1][0]*a[2][2])-(a[1][2]*a[2][0]))+a[0][2]*((a[1][0]*a[2][1])-(a[1][1]*a[2][0]));
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{
				if(j==0)
				{
					b[i][j]=w[i];
				}
				else
				{
					b[i][j]=a[i][j];
				}
				if(j==1)
				{
					c[i][j]=w[i];
				}
				else
				{
					c[i][j]=a[i][j];
				}
				if(j==2)
				{
					d[i][j]=w[i];
				}
				else
				{
					d[i][j]=a[i][j];
				}
			}
		}
		det1=b[0][0]*((b[1][1]*b[2][2])-(b[1][2]*b[2][1]))-b[0][1]*((b[1][0]*b[2][2])-(b[1][2]*b[2][0]))+b[0][2]*((b[1][0]*b[2][1])-(b[1][1]*b[2][0]));
		det2=c[0][0]*((c[1][1]*c[2][2])-(c[1][2]*c[2][1]))-c[0][1]*((c[1][0]*c[2][2])-(c[1][2]*c[2][0]))+c[0][2]*((c[1][0]*c[2][1])-(c[1][1]*c[2][0]));
		det3=d[0][0]*((d[1][1]*d[2][2])-(d[1][2]*d[2][1]))-d[0][1]*((d[1][0]*d[2][2])-(d[1][2]*d[2][0]))+d[0][2]*((d[1][0]*d[2][1])-(d[1][1]*d[2][0]));
		
		/*for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				printf("%f ",b[i][j]);
			}
			printf("\n");
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				printf("%f ",c[i][j]);
			}
			printf("\n");
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				printf("%f ",d[i][j]);
			}
			printf("\n");
		}*/
		if((det==0)&&(det1!=0&&det2!=0&&det3!=0))
		{
			printf("Sorry,You are banished\n");
		}
		else if((det==0)&&(det1==0&&det2==0&&det3==0))
		{
			printf("%f %f %f\n",0,0,0);
		}
		else
		{
			l=det1/det;
			u=det2/det;
			v=det3/det;
			printf("%f %f %f\n",l,u,v);
		}
	}
	return 0;
}


					
