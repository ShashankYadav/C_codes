#include<stdio.h>
int main()
{
	int t,k,i,j;
	scanf("%d",&t);
	for(k=0;k<t;k++)
	{
		char x[100],y[100];
		scanf("%s %s",x,y);
		int lena=0,lenb=0,n1,n2,csum=0,c[200],counter=0;
		int a[200][200],l1=0,l2=199;
		for(i=0;i<200;i++)
		{
			for(j=0;j<200;j++)
			{
				a[i][j]=0;
			}
		}
		for(i=0;x[i]!='\0';i++)
		{
			lena++;
		}
		for(i=0;y[i]!='\0';i++)
		{
			lenb++;
		}
		int carry=0;
		for(i=lena-1;i>=0;i--,l1++)
		{
			l2=199-counter;
			n1=(int)x[i]-48;
			for(j=lenb-1;j>=0;j--,l2--)
			{
				n2=(int)y[j]-48;
					a[l1][l2]=(carry+n1*n2);
			}
			counter++;
		}
		for(i=0;i<200;i++)
		{
			csum=0;
			for(j=0;j<200;j++)
			{
				csum+=a[j][i];
				c[i]=csum;
			}
		}
		int temp=0;
		carry=0;
		for(i=199;i>=0;i--)
		{
			
				c[i]=carry+c[i];
				temp=c[i];
				c[i]=(c[i])%10;
				carry=temp/10;
		}
		int pos=0,flag=0;
		for(i=0;i<200;i++)
		{
			if(c[i]!=0)
			{
				pos=i;
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			printf("0");
		}
		else
		{
			for(i=pos;i<200;i++)
			{
				printf("%d",c[i]);
			}
		}
		printf("\n");

	}
	return 0;
}
