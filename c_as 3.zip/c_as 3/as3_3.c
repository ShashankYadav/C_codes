#include<stdio.h>
int main()
{
	int k,n;
	scanf("%d",&n);
	for(k=0;k<n;k++)
	{
		int a[100][101],x,y,i,j,counter=0;
		scanf("%d %d",&x,&y);
		for(i=0;i<100;i++)
		{
			for(j=0;j<100;j++)
			{
				a[i][j]=0;
			}
		}
		a[0][0]=1;
		a[0][1]=1;
		a[99][0]=1;
		/*for(i=0;i<100;i++)
		{
			for(j=0;j<100;j++)
			{
				printf("%d ",a[i][j]);
			}
			printf("\n");
		}*/
		for(i=1;i<100;i++)
		{
			//counter=0;
			for(j=0;j<101;j++)
				{
					if(j==0)
					{
						a[i][j]=1;
						//counter++;
					}
					else //if(counter<i+2)
					{
						a[i][j]=(a[i-1][j]+a[i-1][j-1])%1000000007;
						//printf("%d ",a[i][j]);
						//counter++;
					}
				}
		}
		a[99][100]=1;
		/*for(i=0;i<100;i++)
		{
			for(j=0;j<100;j++)
			{
				printf("%d ",a[i][j]);
			}
			printf("\n");
		}*/
		printf("%d\n",a[x-1][y]);
	}
	return 0;
}
