#include<stdio.h>
int main()
{
	int t,k;
	scanf("%d",&t);
	for(k=0;k<t;k++)
	{
		int r,c,i,j,n1,n2,n3,max;
		scanf("%d %d",&r,&c);
		int a[r+2][c];
		for(i=0;i<(r+2);i++)
		{
			for(j=0;j<c;j++)
			{
				if(i==0||i==r+1)
				{
					a[i][j]=-100000;
				}
				else
				{
					scanf("%d",&a[i][j]);
				}
			}
		}
		for(j=1;j<c;j++)
		{
			for(i=1;i<(r+1);i++)
			{
				n1=a[i][j]+a[i-1][j-1];
				n2=a[i][j]+a[i][j-1];
				n3=a[i][j]+a[i+1][j-1];
				if(n1>n2&&n1>n3)
				{
					a[i][j]=n1;
				}
				else if(n2>n3&&n2>n1)
				{
					a[i][j]=n2;
				}
				else if(n3>=n1&&n3>=n2)
				{
					a[i][j]=n3;
				}
			}
		}
		max=a[0][c-1];
		for(i=1;i<(r+1);i++)
		{
			if(a[i][c-1]>max)
				max=a[i][c-1];
		}
		printf("%d\n",max);
	}
	return 0;
}
