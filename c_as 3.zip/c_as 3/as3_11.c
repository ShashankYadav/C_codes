#include<stdio.h>
int main()
{
	int n,k;
	scanf("%d",&n);
	for(k=0;k<n;k++)
	{
		long double a1,b1,c1,d1,a2,b2,c2,d2,a3,b3,c3,d3,det1,det2,det3,det;
		scanf("%Lf %Lf %Lf %Lf",&a1,&b1,&c1,&d1);
		scanf("%Lf %Lf %Lf %Lf",&a2,&b2,&c2,&d2);
		scanf("%Lf %Lf %Lf %Lf",&a3,&b3,&c3,&d3);
		det=a1*((b2*c3)-(c2*b3))-b1*((a2*c3)-(c2*a3))+c1*((a2*b3)-(b2*a3));
		det1=d1*((b2*c3)-(c2*b3))-b1*((d2*c3)-(c2*d3))+c1*((d2*b3)-(b2*d3));
		det2=a1*((d2*c3)-(c2*d3))-d1*((a2*c3)-(c2*a3))+c1*((a2*d3)-(d2*a3));
		det3=a1*((b2*d3)-(d2*b3))-b1*((a2*d3)-(d2*a3))+d1*((a2*b3)-(b2*a3));
		//printf("%Lf %Lf %Lf %Lf\n",det,det1,det2,det3);
		if(det==0&&(det1!=0||det2!=0||det3!=0))
		{
			printf("Sorry,You are banished\n");
		}
		else if(det==0&&det1==0&&det2==0&&det3==0)
		{
			printf("%f %f %f\n",0,0,0);
		}
		else
		{
			det1=det1/det;
			det2=det2/det;
			det3=det3/det;
			printf("%Lf %Lf %Lf\n",det1,det2,det3);
		}	
	}
	return 0;
}
